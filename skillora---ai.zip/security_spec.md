# Security Specification: Skillora - AI Firestore Rules

## 1. Data Invariants
1. Every document under `/users/{userId}` and its subcollections (`assessments`, `roadmaps`, `activities`, `agentDecisions`, `mentorMessages`) belongs strictly to the authenticated user whose `request.auth.uid == userId`.
2. PII (`email`, `fullName`) resides exclusively inside owner-gated `/users/{userId}` documents; no blanket signed-in reads exist anywhere.
3. Immutable identity and temporal fields (`uid`, `createdAt`) cannot be altered after creation.
4. All string fields enforce strict `.size()` upper bounds, all arrays enforce `.size() <= MAX` bounds, and all IDs match `^[a-zA-Z0-9_\-]+$`.
5. Terminal assessment records (`assessments`) and audit traces (`agentDecisions`) are immutable once created.

## 2. Adversarial "Dirty Dozen" Payloads Tested
1. Unauthenticated read on `/users/user_1` -> PERMISSION_DENIED
2. Cross-user read on `/users/user_2` by `user_1` -> PERMISSION_DENIED
3. Cross-user write on `/users/user_2/roadmaps/rm_1` by `user_1` -> PERMISSION_DENIED
4. Shadow field injection (`isAdmin: true`) on `/users/user_1` create -> PERMISSION_DENIED
5. Shadow field injection (`role: "admin"`) on `/users/user_1` update -> PERMISSION_DENIED
6. Oversized `fullName` (200 chars > 120) on `/users/user_1` -> PERMISSION_DENIED
7. Invalid `targetCareer` enum (`"Astronaut"`) -> PERMISSION_DENIED
8. Client-spoofed `uid` mismatch (`data.uid != userId`) -> PERMISSION_DENIED
9. Altering immutable `createdAt` on `/users/user_1` update -> PERMISSION_DENIED
10. Unbounded array (> 50 skills) -> PERMISSION_DENIED
11. Malformed path ID (`bad$id!`) -> PERMISSION_DENIED
12. Modifying immutable `assessments` record after creation -> PERMISSION_DENIED
