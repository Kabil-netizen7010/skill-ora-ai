import React, { useState } from 'react';
import { Award, CheckCircle2, FolderGit2, Plus, Save, Trash2 } from 'lucide-react';
import { ALL_CAREERS, COMMON_SKILLS_SUGGESTIONS } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';
import type {
  CareerId,
  CertificationEntry,
  ProficiencyLevel,
  ProjectEntry,
  SkillEntry,
} from '../types/skillora.ts';

export function ProfilePage() {
  const { profile, updateProfile, busyAction, navigate } = useSkillora();

  const [fullName, setFullName] = useState(profile?.fullName || '');
  const [education, setEducation] = useState(profile?.education || '');
  const [department, setDepartment] = useState(profile?.department || '');
  const [yearOfStudy, setYearOfStudy] = useState(profile?.yearOfStudy || '');
  const [targetCareer, setTargetCareer] = useState<CareerId>(
    profile?.targetCareer || 'Full Stack Developer'
  );
  const [careerInterests, setCareerInterests] = useState<string[]>(profile?.careerInterests || []);
  const [pace, setPace] = useState(profile?.learningPreferences.pace || 'Structured Weekly');
  const [style, setStyle] = useState(profile?.learningPreferences.style || 'Hands-on Projects');
  const [weeklyHours, setWeeklyHours] = useState(profile?.learningPreferences.weeklyHours || 10);

  const [skills, setSkills] = useState<SkillEntry[]>(profile?.skills || []);
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillCategory, setNewSkillCategory] = useState<'Technical' | 'Non-Technical'>('Technical');
  const [newSkillLevel, setNewSkillLevel] = useState<ProficiencyLevel>('Beginner');

  const [certs, setCerts] = useState<CertificationEntry[]>(profile?.certifications || []);
  const [certTitle, setCertTitle] = useState('');
  const [certIssuer, setCertIssuer] = useState('');
  const [certYear, setCertYear] = useState('2026');

  const [projects, setProjects] = useState<ProjectEntry[]>(profile?.projects || []);
  const [projTitle, setProjTitle] = useState('');
  const [projSummary, setProjSummary] = useState('');
  const [projSkills, setProjSkills] = useState('');

  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  if (!profile) return null;

  const toggleInterest = (career: CareerId) => {
    setCareerInterests((prev) =>
      prev.includes(career) ? prev.filter((c) => c !== career) : [...prev, career]
    );
  };

  const addSkill = () => {
    const trimmed = newSkillName.trim();
    if (!trimmed) return;
    if (skills.some((s) => s.name.toLowerCase() === trimmed.toLowerCase())) return;
    setSkills([
      ...skills,
      { name: trimmed, category: newSkillCategory, selfReportedLevel: newSkillLevel },
    ]);
    setNewSkillName('');
  };

  const updateSkillLevel = (name: string, level: ProficiencyLevel) => {
    setSkills(skills.map((s) => (s.name === name ? { ...s, selfReportedLevel: level } : s)));
  };

  const removeSkill = (name: string) => {
    setSkills(skills.filter((s) => s.name !== name));
  };

  const addCert = () => {
    if (!certTitle.trim() || !certIssuer.trim()) return;
    setCerts([
      ...certs,
      { id: `cert-${Date.now()}`, title: certTitle.trim(), issuer: certIssuer.trim(), year: certYear },
    ]);
    setCertTitle('');
    setCertIssuer('');
  };

  const addProject = () => {
    if (!projTitle.trim() || !projSummary.trim()) return;
    setProjects([
      ...projects,
      {
        id: `proj-${Date.now()}`,
        title: projTitle.trim(),
        summary: projSummary.trim(),
        skillsUsed: projSkills
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
      },
    ]);
    setProjTitle('');
    setProjSummary('');
    setProjSkills('');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavedNotice(null);
    await updateProfile({
      fullName,
      education,
      department,
      yearOfStudy,
      targetCareer,
      careerInterests,
      learningPreferences: { pace, style, weeklyHours },
      skills,
      certifications: certs,
      projects,
    });
    setSavedNotice('Student profile saved and career compatibility recalculated.');
  };

  return (
    <form onSubmit={handleSave} className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Student Profile</h1>
          <p className="mt-1 text-sm text-slate-400">
            Maintain your academic background, technical & non-technical skills, certifications, and projects.
          </p>
        </div>
        <button
          type="submit"
          disabled={Boolean(busyAction)}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>Save Profile</span>
        </button>
      </div>

      {savedNotice && (
        <div className="px-4 py-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-sm text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{savedNotice}</span>
        </div>
      )}

      {/* Academic & Career Basics */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-5">
        <h2 className="text-lg font-semibold text-white">Academic & Career Foundation</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Full Name</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Education</label>
            <input
              type="text"
              value={education}
              onChange={(e) => setEducation(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Department</label>
            <input
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Year of Study</label>
            <input
              type="text"
              value={yearOfStudy}
              onChange={(e) => setYearOfStudy(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 pt-2">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Primary Target Career</label>
            <select
              value={targetCareer}
              onChange={(e) => setTargetCareer(e.target.value as CareerId)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            >
              {ALL_CAREERS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Learning Pace</label>
            <select
              value={pace}
              onChange={(e) => setPace(e.target.value as typeof pace)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="Self-paced">Self-paced</option>
              <option value="Structured Weekly">Structured Weekly</option>
              <option value="Intensive">Intensive</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Weekly Commitment ({weeklyHours} hrs/wk)
            </label>
            <input
              type="range"
              min={2}
              max={40}
              value={weeklyHours}
              onChange={(e) => setWeeklyHours(Number(e.target.value))}
              className="w-full accent-indigo-500 mt-2"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Learning Style</label>
            <select
              value={style}
              onChange={(e) => setStyle(e.target.value as typeof style)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="Hands-on Projects">Hands-on Projects</option>
              <option value="Conceptual + Theory">Conceptual + Theory</option>
              <option value="Balanced">Balanced</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Career Interests</label>
            <div className="flex flex-wrap gap-2">
              {ALL_CAREERS.map((c) => {
                const selected = careerInterests.includes(c);
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => toggleInterest(c)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      selected
                        ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-200'
                        : 'bg-[#070B14] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {c}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Skills Inventory: Self-Reported vs Assessment-Verified */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold text-white">Skills Inventory</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Self-reported skills carry preliminary weight until verified by a Skillora diagnostic assessment.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('assessments')}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
          >
            Verify a skill now →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-xs text-slate-400">
                <th className="py-2.5 pr-4 font-medium">Skill</th>
                <th className="py-2.5 pr-4 font-medium">Category</th>
                <th className="py-2.5 pr-4 font-medium">Self-Reported</th>
                <th className="py-2.5 pr-4 font-medium">Assessment Status</th>
                <th className="py-2.5 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {skills.map((s) => (
                <tr key={s.name}>
                  <td className="py-3 pr-4 font-medium text-white">{s.name}</td>
                  <td className="py-3 pr-4 text-xs text-slate-400">{s.category}</td>
                  <td className="py-3 pr-4">
                    <select
                      value={s.selfReportedLevel}
                      onChange={(e) => updateSkillLevel(s.name, e.target.value as ProficiencyLevel)}
                      className="px-2.5 py-1 text-xs bg-[#070B14] border border-slate-700 rounded text-slate-200"
                    >
                      <option value="Beginner">Beginner</option>
                      <option value="Intermediate">Intermediate</option>
                      <option value="Advanced">Advanced</option>
                      <option value="Expert">Expert</option>
                    </select>
                  </td>
                  <td className="py-3 pr-4 text-xs tabular-nums">
                    {s.verifiedLevel ? (
                      <span className="text-emerald-400">
                        Verified: {s.verifiedLevel} ({s.verifiedScore}%)
                      </span>
                    ) : (
                      <span className="text-amber-300">Unverified self-report</span>
                    )}
                  </td>
                  <td className="py-3 text-right">
                    <button
                      type="button"
                      onClick={() => removeSkill(s.name)}
                      className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                      aria-label={`Delete ${s.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="pt-3 border-t border-slate-800 flex flex-wrap gap-2">
          <input
            type="text"
            list="profile-skill-suggestions"
            value={newSkillName}
            onChange={(e) => setNewSkillName(e.target.value)}
            placeholder="Add skill name..."
            className="flex-1 min-w-[180px] px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
          />
          <datalist id="profile-skill-suggestions">
            {COMMON_SKILLS_SUGGESTIONS.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
          <select
            value={newSkillCategory}
            onChange={(e) => setNewSkillCategory(e.target.value as 'Technical' | 'Non-Technical')}
            className="px-3 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
          >
            <option value="Technical">Technical</option>
            <option value="Non-Technical">Non-Technical</option>
          </select>
          <select
            value={newSkillLevel}
            onChange={(e) => setNewSkillLevel(e.target.value as ProficiencyLevel)}
            className="px-3 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
          >
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
            <option value="Expert">Expert</option>
          </select>
          <button
            type="button"
            onClick={addSkill}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Skill</span>
          </button>
        </div>
      </section>

      {/* Certifications & Completed Projects */}
      <div className="grid lg:grid-cols-2 gap-6">
        <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-indigo-400" />
            <h2 className="text-lg font-semibold text-white">Certifications</h2>
          </div>

          {certs.length === 0 ? (
            <p className="text-xs text-slate-400">No certifications added yet.</p>
          ) : (
            <ul className="divide-y divide-slate-800/80">
              {certs.map((c) => (
                <li key={c.id} className="py-2.5 flex items-center justify-between gap-3 text-sm">
                  <div>
                    <p className="text-slate-100 font-medium">{c.title}</p>
                    <p className="text-xs text-slate-400">
                      {c.issuer} · {c.year}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCerts(certs.filter((x) => x.id !== c.id))}
                    className="text-slate-500 hover:text-rose-400 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-800">
            <input
              type="text"
              value={certTitle}
              onChange={(e) => setCertTitle(e.target.value)}
              placeholder="Certificate title"
              className="px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
            />
            <input
              type="text"
              value={certIssuer}
              onChange={(e) => setCertIssuer(e.target.value)}
              placeholder="Issuer (e.g. AWS, Coursera)"
              className="px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
            />
            <div className="flex gap-2">
              <input
                type="text"
                value={certYear}
                onChange={(e) => setCertYear(e.target.value)}
                placeholder="Year"
                className="w-20 px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
              />
              <button
                type="button"
                onClick={addCert}
                className="flex-1 px-3 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg cursor-pointer"
              >
                Add
              </button>
            </div>
          </div>
        </section>

        <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4">
          <div className="flex items-center gap-2">
            <FolderGit2 className="w-4 h-4 text-sky-400" />
            <h2 className="text-lg font-semibold text-white">Completed Projects</h2>
          </div>

          {projects.length === 0 ? (
            <p className="text-xs text-slate-400">No projects logged yet.</p>
          ) : (
            <ul className="divide-y divide-slate-800/80">
              {projects.map((p) => (
                <li key={p.id} className="py-2.5 flex items-start justify-between gap-3 text-sm">
                  <div>
                    <p className="text-slate-100 font-medium">{p.title}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{p.summary}</p>
                    {p.skillsUsed.length > 0 && (
                      <p className="text-xs text-indigo-300 mt-1">
                        Stack: {p.skillsUsed.join(' · ')}
                      </p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setProjects(projects.filter((x) => x.id !== p.id))}
                    className="text-slate-500 hover:text-rose-400 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}

          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="grid sm:grid-cols-2 gap-2">
              <input
                type="text"
                value={projTitle}
                onChange={(e) => setProjTitle(e.target.value)}
                placeholder="Project title"
                className="px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
              />
              <input
                type="text"
                value={projSkills}
                onChange={(e) => setProjSkills(e.target.value)}
                placeholder="Skills used (comma separated)"
                className="px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
              />
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={projSummary}
                onChange={(e) => setProjSummary(e.target.value)}
                placeholder="Brief architecture or outcome summary"
                className="flex-1 px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
              />
              <button
                type="button"
                onClick={addProject}
                className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg cursor-pointer"
              >
                Add
              </button>
            </div>
          </div>
        </section>
      </div>
    </form>
  );
}
