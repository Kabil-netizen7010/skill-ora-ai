import React, { useEffect, useRef, useState } from 'react';
import { Bot, Send, Trash2, User } from 'lucide-react';
import { useSkillora } from '../context/SkilloraContext.tsx';

const QUICK_PROMPTS = [
  'What should I learn today?',
  'Why am I weak in my lowest-scoring or missing skill?',
  'Give me a coding exercise tailored to my target career.',
  'Recommend a portfolio project based on my current skills.',
  'What happens if I change my career goal?',
];

export function MentorPage() {
  const {
    profile,
    matches,
    roadmap,
    mentorMessages,
    sendMentorMessage,
    clearMentorChat,
    busyAction,
  } = useSkillora();

  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mentorMessages.length]);

  if (!profile) return null;

  const targetMatch = matches.find((m) => m.career === profile.targetCareer);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || busyAction) return;
    const msg = input.trim();
    setInput('');
    await sendMentorMessage(msg).catch(() => {});
  };

  const handleQuickPrompt = async (prompt: string) => {
    if (busyAction) return;
    await sendMentorMessage(prompt).catch(() => {});
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            AI Mentor (Agent 5)
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Context-aware guidance grounded in your {profile.targetCareer} target ({targetMatch?.compatibilityScore ?? 0}% match) and {roadmap ? `${roadmap.modules.length}-module roadmap` : 'skill profile'}.
          </p>
        </div>
        {mentorMessages.length > 0 && (
          <button
            type="button"
            onClick={() => void clearMentorChat()}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-400 hover:text-rose-300 border border-slate-800 rounded-lg cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Conversation</span>
          </button>
        )}
      </div>

      {/* Quick Contextual Starters */}
      <div className="flex flex-wrap gap-2">
        {QUICK_PROMPTS.map((q) => (
          <button
            key={q}
            type="button"
            disabled={Boolean(busyAction)}
            onClick={() => void handleQuickPrompt(q)}
            className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-[#0D1322] hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Chat Thread Container */}
      <div className="rounded-xl border border-slate-800 bg-[#0D1322] flex flex-col h-[540px]">
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {mentorMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-3">
              <Bot className="w-10 h-10 text-indigo-400" />
              <h2 className="text-lg font-semibold text-white">
                Ask anything about your skills or roadmap
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                Agent 5 reads your live verified assessments, missing competencies, and active roadmap modules before answering. Click any prompt above or ask your own question below.
              </p>
            </div>
          ) : (
            mentorMessages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4 text-indigo-400" />
                    </div>
                  )}

                  <div
                    className={`max-w-[82%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                      isUser
                        ? 'bg-indigo-600 text-white'
                        : 'bg-[#070B14] border border-slate-800 text-slate-200'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                    {msg.reasoningNote && (
                      <p className="mt-2 pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                        {msg.reasoningNote}
                      </p>
                    )}
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4 text-slate-300" />
                    </div>
                  )}
                </div>
              );
            })
          )}
          <div ref={bottomRef} />
        </div>

        <form
          onSubmit={handleSend}
          className="p-4 border-t border-slate-800 bg-[#0A101E] rounded-b-xl flex items-center gap-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask your AI Mentor (e.g., Explain async/await or what should I study next?)..."
            className="flex-1 px-4 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
          />
          <button
            type="submit"
            disabled={Boolean(busyAction) || !input.trim()}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors shrink-0 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
}
