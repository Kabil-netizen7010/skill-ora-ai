import React from 'react';
import {
  ArrowRight,
  Bot,
  CheckCircle2,
  ClipboardCheck,
  Compass,
  Map as MapIcon,
  Sparkles,
} from 'lucide-react';
import { useSkillora } from '../context/SkilloraContext.tsx';

export function DashboardPage() {
  const {
    profile,
    matches,
    assessments,
    roadmap,
    activities,
    decisions,
    navigate,
    runOrchestrator,
    busyAction,
  } = useSkillora();

  if (!profile) return null;

  const targetMatch = matches.find((m) => m.career === profile.targetCareer) || matches[0];
  const verifiedSkillsCount = profile.skills.filter((s) => Boolean(s.verifiedLevel)).length;
  const totalTopics = roadmap?.modules.reduce((acc, m) => acc + m.topics.length, 0) || 0;
  const completedTopics =
    roadmap?.modules.reduce((acc, m) => acc + m.topics.filter((t) => t.completed).length, 0) || 0;
  const roadmapPct = totalTopics > 0 ? Math.round((completedTopics / totalTopics) * 100) : 0;

  const currentModule =
    roadmap?.modules.find((m) => m.status === 'in_progress') || roadmap?.modules[0] || null;
  const dailyTasks = roadmap
    ? roadmap.modules
        .flatMap((m) =>
          m.topics
            .filter((t) => !t.completed)
            .map((t) => ({ id: t.id, title: t.title, moduleTitle: m.title, skill: m.skillFocus }))
        )
        .slice(0, 4)
    : [];

  return (
    <div className="space-y-8">
      {/* Header Summary */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Welcome back, {profile.fullName}
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            {profile.education} · {profile.department} · Target Career: {profile.targetCareer}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => navigate('assessments')}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <ClipboardCheck className="w-4 h-4 text-sky-400" />
            <span>Take Skill Assessment</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('mentor')}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <Bot className="w-4 h-4" />
            <span>Ask AI Mentor</span>
          </button>
        </div>
      </div>

      {/* Career Readiness & Key Metrics Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Career Readiness Estimate</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">
            {targetMatch ? `${targetMatch.compatibilityScore}%` : '—'}
          </p>
          <p className="mt-1.5 text-xs text-slate-400">
            {targetMatch
              ? `${targetMatch.verifiedCoveragePct}% verified by assessments`
              : 'Add skills to compute readiness'}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Verified vs Self-Reported</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">
            {verifiedSkillsCount} / {profile.skills.length}
          </p>
          <p className="mt-1.5 text-xs text-slate-400">
            {assessments.length} diagnostic assessments completed
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Missing Competencies</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">
            {targetMatch ? targetMatch.missingSkills.length : 0}
          </p>
          <p className="mt-1.5 text-xs text-slate-400">
            {targetMatch && targetMatch.partialSkills.length > 0
              ? `${targetMatch.partialSkills.length} partially developed`
              : 'Aligned with core career graph'}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Roadmap Completion</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">{roadmapPct}%</p>
          <p className="mt-1.5 text-xs text-slate-400">
            {completedTopics} of {totalTopics} topics completed
          </p>
        </div>
      </div>

      {/* Main Two-Column Grid */}
      <div className="grid lg:grid-cols-12 gap-8">
        {/* Left: Active Roadmap & Daily Tasks */}
        <div className="lg:col-span-7 space-y-6">
          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <div className="flex items-center justify-between gap-4 mb-4">
              <div>
                <h2 className="text-lg font-semibold text-white">Personalized Learning Roadmap</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {roadmap
                    ? `Active plan for ${roadmap.targetCareer} · ${roadmap.modules.length} modules`
                    : 'Generate your first prerequisite-ordered roadmap with our 5 AI agents'}
                </p>
              </div>
              {roadmap && (
                <button
                  type="button"
                  onClick={() => navigate('roadmap')}
                  className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>Full Roadmap</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {!roadmap ? (
              <div className="py-8 text-center border border-dashed border-slate-800 rounded-lg px-4">
                <Sparkles className="w-8 h-8 text-indigo-400 mx-auto mb-3" />
                <p className="text-sm font-medium text-white">No active learning roadmap yet</p>
                <p className="mt-1 text-xs text-slate-400 max-w-md mx-auto">
                  Launch the Central AI Orchestrator to coordinate Skill Analyzer, Career Matching, and Learning Recommendation agents for {profile.targetCareer}.
                </p>
                <button
                  type="button"
                  disabled={Boolean(busyAction)}
                  onClick={() => void runOrchestrator().catch(() => {})}
                  className="mt-4 px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg cursor-pointer"
                >
                  Generate Personalized Roadmap
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-[#070B14] border border-slate-800/80">
                  <p className="text-xs font-medium text-indigo-300 mb-1">Orchestrator Rationale</p>
                  <p className="text-sm text-slate-300 leading-relaxed">{roadmap.adaptationReason}</p>
                </div>

                {currentModule && (
                  <div className="p-4 rounded-lg bg-[#11192E] border border-indigo-500/20">
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-400 mb-1">
                      <span>
                        Module {currentModule.order} · {currentModule.skillFocus}
                      </span>
                      <span className="capitalize">{currentModule.status.replace('_', ' ')}</span>
                    </div>
                    <h3 className="text-base font-semibold text-white">{currentModule.title}</h3>
                    <p className="mt-1 text-xs text-slate-400">
                      Practice: {currentModule.practiceExercise.title} · Mini-Project:{' '}
                      {currentModule.miniProject.title}
                    </p>
                    <button
                      type="button"
                      onClick={() => navigate('roadmap')}
                      className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
                    >
                      <MapIcon className="w-3.5 h-3.5" />
                      <span>Continue this module</span>
                    </button>
                  </div>
                )}

                <div>
                  <h3 className="text-sm font-semibold text-slate-200 mb-2.5">
                    Today's Personalized Tasks
                  </h3>
                  {dailyTasks.length === 0 ? (
                    <p className="text-xs text-slate-400">
                      All roadmap topics completed! Take an assessment or switch career goals to continue.
                    </p>
                  ) : (
                    <ul className="divide-y divide-slate-800/80 border-y border-slate-800/80">
                      {dailyTasks.map((task) => (
                        <li
                          key={task.id}
                          className="py-2.5 flex items-center justify-between gap-4 text-sm"
                        >
                          <div className="min-w-0">
                            <p className="text-slate-200 truncate">{task.title}</p>
                            <p className="text-xs text-slate-500 truncate">
                              {task.moduleTitle} · {task.skill}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => navigate('roadmap')}
                            className="text-xs font-medium text-indigo-400 hover:text-indigo-300 shrink-0 cursor-pointer"
                          >
                            Open
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Recent Activity Log */}
          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-white">Recent Learning History</h2>
              <button
                type="button"
                onClick={() => navigate('progress')}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
              >
                View Analytics
              </button>
            </div>
            {activities.length === 0 ? (
              <p className="text-sm text-slate-400">No learning activities logged yet.</p>
            ) : (
              <ul className="divide-y divide-slate-800/80">
                {activities.slice(0, 5).map((act) => (
                  <li key={act.id} className="py-3 flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 min-w-0">
                      <CheckCircle2 className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
                      <div className="min-w-0">
                        <p className="text-sm text-slate-200 truncate">{act.title}</p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {act.skillName} · {new Date(act.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Right: Career Gap Snapshot & Agent Orchestrator */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-semibold text-white">Skill Gap Snapshot</h2>
                <p className="text-xs text-slate-400 mt-0.5">Against {profile.targetCareer}</p>
              </div>
              <button
                type="button"
                onClick={() => navigate('career-matching')}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
              >
                Full Match
              </button>
            </div>

            {targetMatch && (
              <div className="space-y-4">
                <div>
                  <p className="text-xs font-medium text-slate-400 mb-2">
                    Missing Core Skills ({targetMatch.missingSkills.length})
                  </p>
                  {targetMatch.missingSkills.length === 0 ? (
                    <p className="text-xs text-emerald-300">
                      All core skills are present in your profile. Verify them with assessments!
                    </p>
                  ) : (
                    <ul className="space-y-2">
                      {targetMatch.missingSkills.map((s) => (
                        <li
                          key={s.name}
                          className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-[#070B14] border border-slate-800"
                        >
                          <span className="font-medium text-slate-200">{s.name}</span>
                          <span className="text-slate-400">Requires {s.requiredLevel}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div>
                  <p className="text-xs font-medium text-slate-400 mb-2">
                    Matching / Partial Skills ({targetMatch.matchingSkills.length + targetMatch.partialSkills.length})
                  </p>
                  <ul className="space-y-2">
                    {targetMatch.matchingSkills.map((s) => (
                      <li
                        key={s.name}
                        className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-[#070B14] border border-slate-800"
                      >
                        <span className="text-slate-200">{s.name}</span>
                        <span className={s.verified ? 'text-emerald-400' : 'text-amber-300'}>
                          {s.studentLevel} · {s.verified ? 'Verified' : 'Self-reported'}
                        </span>
                      </li>
                    ))}
                    {targetMatch.partialSkills.map((s) => (
                      <li
                        key={s.name}
                        className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-[#070B14] border border-slate-800"
                      >
                        <span className="text-slate-200">{s.name}</span>
                        <span className="text-sky-300">
                          {s.studentLevel} → {s.requiredLevel}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed pt-2 border-t border-slate-800">
                  {targetMatch.transparencyNote}
                </p>
              </div>
            )}
          </div>

          {/* Latest Multi-Agent Orchestrator Decision */}
          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold text-white">AI Agent Collaboration</h2>
              <button
                type="button"
                onClick={() => navigate('careers')}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 inline-flex items-center gap-1 cursor-pointer"
              >
                <Compass className="w-3.5 h-3.5" />
                <span>Switch Career</span>
              </button>
            </div>
            {decisions.length === 0 ? (
              <p className="text-xs text-slate-400 leading-relaxed">
                No agent orchestration runs yet. Click "Sync AI Roadmap" in the top bar or complete a skill assessment to see all five agents collaborate.
              </p>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-indigo-300 font-medium">
                  Latest Trigger: {decisions[0].triggerEvent}
                </p>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {decisions[0].orchestratorSummary}
                </p>
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  {decisions[0].agentTrace.map((step) => (
                    <div key={step.agentName} className="text-xs">
                      <span className="font-semibold text-slate-200">{step.agentName}: </span>
                      <span className="text-slate-400">{step.decisionSummary}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
