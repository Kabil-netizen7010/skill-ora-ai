import React, { useState } from 'react';
import {
  CheckSquare,
  ExternalLink,
  GitBranch,
  RefreshCw,
  Send,
  Sparkles,
  Square,
} from 'lucide-react';
import { useSkillora } from '../context/SkilloraContext.tsx';

export function RoadmapPage() {
  const {
    profile,
    roadmap,
    roadmapHistory,
    runOrchestrator,
    toggleRoadmapProgress,
    requestExerciseFeedback,
    busyAction,
    navigate,
  } = useSkillora();

  const [openExerciseModuleId, setOpenExerciseModuleId] = useState<string | null>(null);
  const [solutionDrafts, setSolutionDrafts] = useState<Record<string, string>>({});
  const [feedbackByModule, setFeedbackByModule] = useState<Record<string, string>>({});

  if (!profile) return null;

  const handleFeedback = async (moduleId: string, moduleTitle: string, prompt: string) => {
    const solution = solutionDrafts[moduleId] || '';
    const feedback = await requestExerciseFeedback({
      moduleTitle,
      exercisePrompt: prompt,
      solution,
    });
    setFeedbackByModule((prev) => ({ ...prev, [moduleId]: feedback }));
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Personalized Learning Roadmap
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Prerequisite-ordered modules, practical coding exercises, and mini-projects tailored for {profile.targetCareer}.
          </p>
        </div>
        <button
          type="button"
          disabled={Boolean(busyAction)}
          onClick={() => void runOrchestrator('Rebuild Personalized Roadmap').catch(() => {})}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${busyAction ? 'animate-spin' : ''}`} />
          <span>{roadmap ? 'Regenerate via Orchestrator' : 'Generate Roadmap'}</span>
        </button>
      </div>

      {!roadmap ? (
        <div className="rounded-xl border border-dashed border-slate-800 bg-[#0D1322] p-12 text-center space-y-4">
          <Sparkles className="w-10 h-10 text-indigo-400 mx-auto" />
          <h2 className="text-xl font-semibold text-white">No Personalized Roadmap Generated Yet</h2>
          <p className="text-sm text-slate-400 max-w-lg mx-auto">
            Let our Central AI Orchestrator coordinate Agents 1–4 to examine your skills, compute gaps for {profile.targetCareer}, and assemble your ordered curriculum.
          </p>
          <button
            type="button"
            disabled={Boolean(busyAction)}
            onClick={() => void runOrchestrator('Initial Roadmap Generation').catch(() => {})}
            className="px-6 py-3 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg cursor-pointer"
          >
            Generate Personalized Roadmap
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Orchestrator Adaptation Explanation Banner */}
          <div className="rounded-xl border border-indigo-500/30 bg-[#0D1322] p-6 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-indigo-300">
              <span>Active Career Target: {roadmap.targetCareer}</span>
              <span>Updated {new Date(roadmap.updatedAt).toLocaleString()}</span>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed">{roadmap.summary}</p>
            <div className="pt-2 border-t border-slate-800 text-xs text-slate-300">
              <span className="font-semibold text-indigo-300">Why this sequence: </span>
              {roadmap.adaptationReason}
            </div>
          </div>

          {/* Modules List */}
          <div className="space-y-6">
            {roadmap.modules.map((mod) => {
              const completedTopics = mod.topics.filter((t) => t.completed).length;
              const isExerciseOpen = openExerciseModuleId === mod.id;

              return (
                <section
                  key={mod.id}
                  className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-800">
                    <div className="space-y-1">
                      <div className="text-xs text-slate-400">
                        <span>Module {mod.order}</span>
                        <span className="mx-1.5">·</span>
                        <span>Focus: {mod.skillFocus}</span>
                        {mod.prerequisites.length > 0 && (
                          <>
                            <span className="mx-1.5">·</span>
                            <span>Prerequisites: {mod.prerequisites.join(', ')}</span>
                          </>
                        )}
                      </div>
                      <h2 className="text-xl font-semibold text-white">{mod.title}</h2>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <select
                        value={mod.status}
                        onChange={(e) =>
                          void toggleRoadmapProgress({
                            moduleId: mod.id,
                            moduleStatus: e.target.value as 'pending' | 'in_progress' | 'completed',
                          })
                        }
                        className="px-3 py-1.5 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-slate-200"
                      >
                        <option value="pending">Pending</option>
                        <option value="in_progress">In Progress</option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>
                  </div>

                  {mod.adaptiveNote && (
                    <div className="p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200">
                      {mod.adaptiveNote}
                    </div>
                  )}

                  {/* Learning Objectives */}
                  <div>
                    <h3 className="text-xs font-semibold text-slate-400 mb-2">
                      Learning Objectives
                    </h3>
                    <ul className="space-y-1 text-sm text-slate-300">
                      {mod.objectives.map((obj) => (
                        <li key={obj}>· {obj}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Topics & Subtopics */}
                  <div>
                    <div className="flex items-center justify-between mb-2.5">
                      <h3 className="text-xs font-semibold text-slate-400">
                        Topics & Subtopics ({completedTopics}/{mod.topics.length} completed)
                      </h3>
                    </div>
                    <div className="space-y-2.5">
                      {mod.topics.map((topic) => (
                        <button
                          key={topic.id}
                          type="button"
                          onClick={() =>
                            void toggleRoadmapProgress({ moduleId: mod.id, topicId: topic.id })
                          }
                          className="w-full text-left p-3.5 rounded-lg bg-[#070B14] border border-slate-800 hover:border-slate-700 flex items-start gap-3 transition-colors cursor-pointer"
                        >
                          {topic.completed ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-500 mt-0.5 shrink-0" />
                          )}
                          <div>
                            <p
                              className={`text-sm font-medium ${
                                topic.completed ? 'text-slate-400 line-through' : 'text-white'
                              }`}
                            >
                              {topic.title}
                            </p>
                            <p className="text-xs text-slate-400 mt-1">
                              {topic.subtopics.join(' · ')}
                            </p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Practice Exercise & Mini-Project */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-[#070B14] border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-sky-400">Practice Exercise</span>
                        <button
                          type="button"
                          onClick={() =>
                            void toggleRoadmapProgress({
                              moduleId: mod.id,
                              toggleExercise: true,
                            })
                          }
                          className="text-xs text-slate-300 hover:text-white inline-flex items-center gap-1 cursor-pointer"
                        >
                          {mod.practiceExercise.completed ? (
                            <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Square className="w-3.5 h-3.5 text-slate-500" />
                          )}
                          <span>{mod.practiceExercise.completed ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                      <p className="text-sm font-medium text-white">{mod.practiceExercise.title}</p>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {mod.practiceExercise.prompt}
                      </p>
                      <button
                        type="button"
                        onClick={() =>
                          setOpenExerciseModuleId(isExerciseOpen ? null : mod.id)
                        }
                        className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
                      >
                        {isExerciseOpen ? 'Hide Practice Workspace' : 'Open AI Coding Practice →'}
                      </button>

                      {isExerciseOpen && (
                        <div className="pt-2 space-y-2 border-t border-slate-800">
                          <textarea
                            rows={4}
                            value={solutionDrafts[mod.id] || ''}
                            onChange={(e) =>
                              setSolutionDrafts((prev) => ({ ...prev, [mod.id]: e.target.value }))
                            }
                            placeholder="Write your code or solution approach for AI feedback..."
                            className="w-full p-2.5 text-xs font-mono bg-[#0D1322] border border-slate-700 rounded text-slate-100"
                          />
                          <button
                            type="button"
                            disabled={Boolean(busyAction)}
                            onClick={() =>
                              void handleFeedback(
                                mod.id,
                                mod.practiceExercise.title,
                                mod.practiceExercise.prompt
                              ).catch(() => {})
                            }
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded cursor-pointer"
                          >
                            <Send className="w-3 h-3" />
                            <span>Get AI Feedback</span>
                          </button>
                          {feedbackByModule[mod.id] && (
                            <div className="p-3 rounded bg-slate-900 border border-slate-700 text-xs text-slate-200 whitespace-pre-wrap">
                              {feedbackByModule[mod.id]}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="p-4 rounded-lg bg-[#070B14] border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-indigo-300">Mini-Project</span>
                        <button
                          type="button"
                          onClick={() =>
                            void toggleRoadmapProgress({
                              moduleId: mod.id,
                              toggleMiniProject: true,
                            })
                          }
                          className="text-xs text-slate-300 hover:text-white inline-flex items-center gap-1 cursor-pointer"
                        >
                          {mod.miniProject.completed ? (
                            <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Square className="w-3.5 h-3.5 text-slate-500" />
                          )}
                          <span>{mod.miniProject.completed ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                      <p className="text-sm font-medium text-white">{mod.miniProject.title}</p>
                      <ul className="space-y-1 text-xs text-slate-400">
                        {mod.miniProject.deliverables.map((d) => (
                          <li key={d}>· {d}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Curated Resources + Assessment Gate */}
                  <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex flex-wrap items-center gap-4 text-xs">
                      {mod.resources.map((r) => (
                        <a
                          key={r.url}
                          href={r.url}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-sky-400 hover:text-sky-300"
                        >
                          <span>
                            {r.title} ({r.duration})
                          </span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ))}
                    </div>
                    {mod.assessmentRequired && (
                      <button
                        type="button"
                        onClick={() => navigate('assessments')}
                        className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        Verify {mod.skillFocus} via Assessment →
                      </button>
                    )}
                  </div>
                </section>
              );
            })}
          </div>

          {/* Preserved Career Roadmap History */}
          {roadmapHistory.length > 1 && (
            <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
              <div className="flex items-center gap-2 mb-3">
                <GitBranch className="w-4 h-4 text-slate-400" />
                <h3 className="text-base font-semibold text-white">Previous Roadmaps (Preserved)</h3>
              </div>
              <ul className="divide-y divide-slate-800/80 text-xs">
                {roadmapHistory.slice(1).map((hist) => (
                  <li key={hist.id} className="py-2.5 flex items-center justify-between text-slate-400">
                    <span>
                      {hist.targetCareer} · {hist.modules.length} modules
                    </span>
                    <span>{new Date(hist.updatedAt).toLocaleDateString()}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
