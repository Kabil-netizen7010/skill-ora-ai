import React, { useState } from 'react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { CheckCircle2, Clock, Plus } from 'lucide-react';
import { useSkillora } from '../context/SkilloraContext.tsx';
import type { LearningActivity } from '../types/skillora.ts';

export function ProgressPage() {
  const { profile, assessments, roadmap, activities, logActivity, navigate } = useSkillora();

  const [activityTitle, setActivityTitle] = useState('');
  const [activitySkill, setActivitySkill] = useState(profile?.targetCareer || 'Python');
  const [activityType, setActivityType] = useState<LearningActivity['type']>('lesson');

  if (!profile) return null;

  const totalTopics = roadmap?.modules.reduce((acc, m) => acc + m.topics.length, 0) || 0;
  const completedTopics =
    roadmap?.modules.reduce((acc, m) => acc + m.topics.filter((t) => t.completed).length, 0) || 0;
  const completedProjects =
    (roadmap?.modules.filter((m) => m.miniProject.completed).length || 0) + profile.projects.length;
  const pendingModules = roadmap?.modules.filter((m) => m.status !== 'completed') || [];

  const assessmentChartData = [...assessments]
    .reverse()
    .map((a, idx) => ({
      attempt: `#${idx + 1} ${a.skillName}`,
      score: a.score,
      date: new Date(a.createdAt).toLocaleDateString(),
    }));

  const avgScore =
    assessments.length > 0
      ? Math.round(assessments.reduce((sum, a) => sum + a.score, 0) / assessments.length)
      : 0;

  const handleManualLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activityTitle.trim()) return;
    await logActivity({
      type: activityType,
      title: activityTitle.trim(),
      skillName: activitySkill.trim() || 'General',
      status: 'completed',
    });
    setActivityTitle('');
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Progress Tracking & Milestones</h1>
        <p className="mt-1 text-sm text-slate-400">
          Monitor completed lessons, assessment score trends, mini-projects, and pending roadmap milestones.
        </p>
      </div>

      {/* Milestones KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Completed Lessons</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">
            {completedTopics} / {totalTopics}
          </p>
          <p className="mt-1 text-xs text-slate-400">Active roadmap topic mastery</p>
        </div>
        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Average Assessment Score</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">
            {assessments.length > 0 ? `${avgScore}%` : '—'}
          </p>
          <p className="mt-1 text-xs text-slate-400">
            Across {assessments.length} diagnostic attempts
          </p>
        </div>
        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Projects Completed</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">{completedProjects}</p>
          <p className="mt-1 text-xs text-slate-400">Portfolio & roadmap mini-builds</p>
        </div>
        <div className="p-5 rounded-xl border border-slate-800 bg-[#0D1322]">
          <p className="text-xs font-medium text-slate-400">Logged Activities</p>
          <p className="mt-2 text-3xl font-bold text-white tabular-nums">{activities.length}</p>
          <p className="mt-1 text-xs text-slate-400">Persistent learning events</p>
        </div>
      </div>

      {/* Assessment Score Progression Chart */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
        <h2 className="text-lg font-semibold text-white mb-1">Assessment Performance Trend</h2>
        <p className="text-xs text-slate-400 mb-4">
          Chronological scores across diagnostic quizzes and practical coding evaluations
        </p>
        {assessmentChartData.length === 0 ? (
          <div className="py-12 text-center border border-dashed border-slate-800 rounded-lg">
            <p className="text-sm text-slate-400">
              Complete at least one skill assessment to chart your verified progression.
            </p>
            <button
              type="button"
              onClick={() => navigate('assessments')}
              className="mt-3 text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
            >
              Go to Skill Assessment →
            </button>
          </div>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={assessmentChartData}>
                <defs>
                  <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366F1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366F1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="attempt" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0A101E',
                    borderColor: '#1E293B',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="score"
                  stroke="#6366F1"
                  strokeWidth={2}
                  fill="url(#scoreGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Pending Tasks */}
        <section className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4">
          <h2 className="text-lg font-semibold text-white">Pending Roadmap Modules</h2>
          {pendingModules.length === 0 ? (
            <p className="text-sm text-slate-400">
              {roadmap
                ? 'All modules in your current roadmap are completed!'
                : 'Generate a personalized roadmap to see your pending milestones.'}
            </p>
          ) : (
            <ul className="space-y-3">
              {pendingModules.map((mod) => (
                <li
                  key={mod.id}
                  className="p-3.5 rounded-lg bg-[#070B14] border border-slate-800 flex items-start justify-between gap-3"
                >
                  <div className="flex items-start gap-2.5 min-w-0">
                    <Clock className="w-4 h-4 text-sky-400 mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-white truncate">
                        {mod.order}. {mod.title}
                      </p>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {mod.topics.filter((t) => t.completed).length}/{mod.topics.length} topics ·{' '}
                        {mod.skillFocus}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigate('roadmap')}
                    className="text-xs font-medium text-indigo-400 hover:text-indigo-300 shrink-0 cursor-pointer"
                  >
                    Open
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Full Learning Activity History + Manual Logger */}
        <section className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-5">
          <h2 className="text-lg font-semibold text-white">Learning Activity Log</h2>

          <form onSubmit={handleManualLog} className="flex flex-wrap gap-2">
            <input
              type="text"
              value={activityTitle}
              onChange={(e) => setActivityTitle(e.target.value)}
              placeholder="Log a completed lesson, exercise, or project..."
              className="flex-1 min-w-[200px] px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
            />
            <input
              type="text"
              value={activitySkill}
              onChange={(e) => setActivitySkill(e.target.value)}
              placeholder="Skill"
              className="w-32 px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
            />
            <select
              value={activityType}
              onChange={(e) => setActivityType(e.target.value as LearningActivity['type'])}
              className="px-3 py-2 text-xs bg-[#070B14] border border-slate-700 rounded-lg text-white"
            >
              <option value="lesson">Lesson</option>
              <option value="exercise">Exercise</option>
              <option value="project">Project</option>
            </select>
            <button
              type="submit"
              className="inline-flex items-center gap-1 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log</span>
            </button>
          </form>

          {activities.length === 0 ? (
            <p className="text-sm text-slate-400">No learning activities recorded yet.</p>
          ) : (
            <ul className="divide-y divide-slate-800/80 max-h-80 overflow-y-auto pr-1">
              {activities.map((act) => (
                <li key={act.id} className="py-3 flex items-start justify-between gap-4">
                  <div className="flex items-start gap-2.5 min-w-0">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm text-slate-200">{act.title}</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {act.type.replace('_', ' ')} · {act.skillName}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-slate-500 tabular-nums shrink-0">
                    {new Date(act.createdAt).toLocaleDateString()}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
