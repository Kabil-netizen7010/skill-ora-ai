import React, { useMemo, useState } from 'react';
import { BookOpen, Check, ExternalLink, Search } from 'lucide-react';
import { ALL_CAREERS, CURATED_RESOURCE_LIBRARY } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';

export function ResourcesPage() {
  const { profile, logActivity } = useSkillora();
  const [search, setSearch] = useState('');
  const [careerFilter, setCareerFilter] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [loggedIds, setLoggedIds] = useState<Record<string, boolean>>({});

  const filtered = useMemo(() => {
    return CURATED_RESOURCE_LIBRARY.filter((res) => {
      const matchesQuery =
        !search.trim() ||
        res.title.toLowerCase().includes(search.toLowerCase()) ||
        res.skillName.toLowerCase().includes(search.toLowerCase()) ||
        res.description.toLowerCase().includes(search.toLowerCase());

      const matchesCareer =
        careerFilter === 'ALL' ||
        (careerFilter === 'TARGET' && profile && res.careers.includes(profile.targetCareer)) ||
        res.careers.includes(careerFilter as never);

      const matchesType = typeFilter === 'ALL' || res.type === typeFilter;
      return matchesQuery && matchesCareer && matchesType;
    });
  }, [search, careerFilter, typeFilter, profile]);

  const handleLogStudy = async (id: string, title: string, skillName: string) => {
    await logActivity({
      type: 'lesson',
      title: `Studied resource: ${title}`,
      skillName,
      status: 'completed',
    });
    setLoggedIds((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Learning Resource Library</h1>
        <p className="mt-1 text-sm text-slate-400">
          Curated engineering documentation, interactive courses, and security labs mapped to career skills.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by skill, title, or topic..."
            className="w-full pl-10 pr-4 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
          />
        </div>
        <select
          value={careerFilter}
          onChange={(e) => setCareerFilter(e.target.value)}
          className="px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
        >
          <option value="ALL">All Career Tracks</option>
          {profile && <option value="TARGET">My Target ({profile.targetCareer})</option>}
          {ALL_CAREERS.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
        >
          <option value="ALL">All Formats</option>
          <option value="Documentation">Documentation</option>
          <option value="Interactive">Interactive</option>
          <option value="Course">Course</option>
        </select>
      </div>

      {/* Results Grid */}
      {filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-10 text-center text-sm text-slate-400">
          No learning resources match your current filters.
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((res) => (
            <div
              key={res.id}
              className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="text-xs text-slate-400 mb-2">
                  <span>{res.skillName}</span>
                  <span className="mx-1.5">·</span>
                  <span>{res.type}</span>
                  <span className="mx-1.5">·</span>
                  <span>{res.duration}</span>
                </div>
                <h2 className="text-base font-semibold text-white">{res.title}</h2>
                <p className="mt-1 text-xs text-indigo-300">
                  {res.provider} · {res.level}
                </p>
                <p className="mt-2.5 text-xs text-slate-400 leading-relaxed">{res.description}</p>
              </div>

              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <a
                  href={res.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-sky-400 hover:text-sky-300"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Open Resource</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                <button
                  type="button"
                  onClick={() => void handleLogStudy(res.id, res.title, res.skillName)}
                  className={`inline-flex items-center gap-1 text-xs font-medium cursor-pointer ${
                    loggedIds[res.id]
                      ? 'text-emerald-400'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{loggedIds[res.id] ? 'Logged' : 'Log Study'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
