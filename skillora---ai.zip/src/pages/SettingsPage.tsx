import React, { useState } from 'react';
import { CheckCircle2, Download, KeyRound, LogOut, RefreshCw } from 'lucide-react';
import { ALL_CAREERS } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';
import type { CareerId } from '../types/skillora.ts';

export function SettingsPage() {
  const {
    user,
    profile,
    assessments,
    roadmap,
    activities,
    switchCareer,
    updateProfile,
    logout,
    busyAction,
  } = useSkillora();

  const [selectedCareer, setSelectedCareer] = useState<CareerId>(
    profile?.targetCareer || 'Full Stack Developer'
  );
  const [pace, setPace] = useState(profile?.learningPreferences.pace || 'Structured Weekly');
  const [weeklyHours, setWeeklyHours] = useState(profile?.learningPreferences.weeklyHours || 10);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  if (!profile || !user) return null;

  const handleSavePrefs = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);
    await updateProfile({
      learningPreferences: {
        ...profile.learningPreferences,
        pace,
        weeklyHours,
      },
    });
    setStatusMessage('Learning preferences saved.');
  };

  const handleCareerSwitch = async () => {
    setStatusMessage(null);
    await switchCareer(selectedCareer);
    setStatusMessage(
      `Career target switched to ${selectedCareer}. Prior learning history preserved and new roadmap generated.`
    );
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    setStatusMessage(null);
    try {
      const token = localStorage.getItem('skillora_session_token');
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = (await res.json()) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error || 'Could not update password.');
      setCurrentPassword('');
      setNewPassword('');
      setStatusMessage(data.message || 'Password updated successfully.');
    } catch (err) {
      setPasswordError(err instanceof Error ? err.message : 'Password update failed.');
    }
  };

  const handleExport = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      profile,
      assessments,
      activeRoadmap: roadmap,
      activities,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `skillora-portfolio-${profile.fullName.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-slate-400">
          Manage your account credentials, career goal switcher, learning cadence, and portfolio export.
        </p>
      </div>

      {statusMessage && (
        <div className="px-4 py-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-sm text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Account Summary */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-3">
        <h2 className="text-lg font-semibold text-white">Account Information</h2>
        <div className="grid sm:grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-xs text-slate-400">Student Name</p>
            <p className="text-white font-medium mt-0.5">{profile.fullName}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Email</p>
            <p className="text-white font-medium mt-0.5">{user.email}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Authentication Method</p>
            <p className="text-white font-medium mt-0.5 capitalize">{user.authProvider}</p>
          </div>
        </div>
      </section>

      {/* Career Goal Switcher */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-white">Career Goal Switcher</h2>
          <p className="text-xs text-slate-400 mt-1">
            Recalculates all skill gaps and generates a new prerequisite-ordered roadmap while preserving your existing assessment history and completed activities.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <select
            value={selectedCareer}
            onChange={(e) => setSelectedCareer(e.target.value as CareerId)}
            className="flex-1 px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
          >
            {ALL_CAREERS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <button
            type="button"
            disabled={Boolean(busyAction) || selectedCareer === profile.targetCareer}
            onClick={() => void handleCareerSwitch().catch(() => {})}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg whitespace-nowrap cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${busyAction ? 'animate-spin' : ''}`} />
            <span>Switch Career Goal</span>
          </button>
        </div>
      </section>

      {/* Learning Preferences */}
      <form
        onSubmit={handleSavePrefs}
        className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4"
      >
        <h2 className="text-lg font-semibold text-white">Learning Preferences</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Study Pace</label>
            <select
              value={pace}
              onChange={(e) => setPace(e.target.value as typeof pace)}
              className="w-full px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
            >
              <option value="Self-paced">Self-paced</option>
              <option value="Structured Weekly">Structured Weekly</option>
              <option value="Intensive">Intensive</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Weekly Study Hours ({weeklyHours} hrs)
            </label>
            <input
              type="range"
              min={2}
              max={40}
              value={weeklyHours}
              onChange={(e) => setWeeklyHours(Number(e.target.value))}
              className="w-full accent-indigo-500 mt-2"
            />
          </div>
        </div>
        <button
          type="submit"
          className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer"
        >
          Save Preferences
        </button>
      </form>

      {/* Security / Password Update */}
      {user.authProvider === 'email' && (
        <form
          onSubmit={handlePasswordChange}
          className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4"
        >
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-indigo-400" />
            <h2 className="text-lg font-semibold text-white">Change Password</h2>
          </div>
          {passwordError && (
            <p className="text-xs text-rose-300">{passwordError}</p>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Current password"
              className="px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
            />
            <input
              type="password"
              required
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="New password (min 6 chars)"
              className="px-3.5 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer"
          >
            Update Password
          </button>
        </form>
      )}

      {/* Data Export & Sign Out */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-white">Export Learning Data & Session</h2>
          <p className="text-xs text-slate-400 mt-1">
            Download your complete verified skill history, assessments, and roadmap as JSON.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleExport}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
          <button
            type="button"
            onClick={() => void logout()}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-rose-200 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-lg cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </section>
    </div>
  );
}
