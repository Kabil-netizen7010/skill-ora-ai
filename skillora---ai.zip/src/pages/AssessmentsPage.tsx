import React, { useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, ClipboardCheck, Play, Sparkles } from 'lucide-react';
import { CAREER_CATALOG, COMMON_SKILLS_SUGGESTIONS } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';
import type {
  AgentDecisionRecord,
  AssessmentQuestion,
  CareerId,
  SkillAssessmentRecord,
} from '../types/skillora.ts';

export function AssessmentsPage() {
  const {
    profile,
    assessments,
    generateAssessment,
    submitAssessment,
    busyAction,
    navigate,
  } = useSkillora();

  const candidateSkills = useMemo(() => {
    const careerSkills = profile
      ? CAREER_CATALOG[profile.targetCareer].coreSkills.map((s) => s.name)
      : [];
    const profileSkills = profile ? profile.skills.map((s) => s.name) : [];
    return Array.from(new Set([...careerSkills, ...profileSkills, ...COMMON_SKILLS_SUGGESTIONS]));
  }, [profile]);

  const [selectedSkill, setSelectedSkill] = useState<string>(candidateSkills[0] || 'Python');
  const [careerContext, setCareerContext] = useState<CareerId>(
    profile?.targetCareer || 'Full Stack Developer'
  );

  const [activeSession, setActiveSession] = useState<{
    sessionId: string;
    skillName: string;
    careerContext: CareerId;
    questions: AssessmentQuestion[];
  } | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [latestResult, setLatestResult] = useState<{
    record: SkillAssessmentRecord;
    adapted: boolean;
    decision: AgentDecisionRecord;
  } | null>(null);

  if (!profile) return null;

  const handleStart = async () => {
    setLatestResult(null);
    const session = await generateAssessment(selectedSkill, careerContext);
    setActiveSession(session);
    const initialAnswers: Record<string, string> = {};
    for (const q of session.questions) {
      if (q.type === 'practical' && q.starterCode) {
        initialAnswers[q.id] = q.starterCode;
      } else {
        initialAnswers[q.id] = '';
      }
    }
    setAnswers(initialAnswers);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSession) return;
    const result = await submitAssessment(activeSession.sessionId, answers);
    setLatestResult(result);
    setActiveSession(null);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">AI Skill Assessment</h1>
        <p className="mt-1 text-sm text-slate-400">
          Diagnostic quizzes and practical exercises evaluate real mastery and feed the Progress Evaluation Agent to adapt your roadmap.
        </p>
      </div>

      {/* Assessment Launcher */}
      {!activeSession && (
        <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-5">
          <h2 className="text-lg font-semibold text-white">Start a Diagnostic Assessment</h2>
          <div className="grid sm:grid-cols-3 gap-4 items-end">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Skill to Evaluate</label>
              <select
                value={selectedSkill}
                onChange={(e) => setSelectedSkill(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
              >
                {candidateSkills.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Career Context</label>
              <select
                value={careerContext}
                onChange={(e) => setCareerContext(e.target.value as CareerId)}
                className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
              >
                {Object.keys(CAREER_CATALOG).map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <button
                type="button"
                disabled={Boolean(busyAction)}
                onClick={() => void handleStart().catch(() => {})}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>Generate 5-Question Assessment</span>
              </button>
            </div>
          </div>
          <p className="text-xs text-slate-400">
            Includes 4 targeted conceptual questions (80%) and 1 practical coding or architectural problem (20%). Scoring below 65% automatically triggers adaptive remediation in your roadmap.
          </p>
        </section>
      )}

      {/* Active Assessment Form */}
      {activeSession && (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="rounded-xl border border-indigo-500/30 bg-[#0D1322] p-6 flex items-center justify-between gap-4">
            <div>
              <p className="text-xs text-indigo-300 font-medium">
                Active Assessment · {activeSession.careerContext}
              </p>
              <h2 className="text-xl font-bold text-white mt-0.5">{activeSession.skillName}</h2>
            </div>
            <button
              type="button"
              onClick={() => setActiveSession(null)}
              className="text-xs text-slate-400 hover:text-white cursor-pointer"
            >
              Cancel Attempt
            </button>
          </div>

          {activeSession.questions.map((q, idx) => (
            <div key={q.id} className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>
                  Question {idx + 1} of {activeSession.questions.length} · {q.conceptTested}
                </span>
                <span>{q.type === 'practical' ? 'Practical Exercise (20 pts)' : 'Multiple Choice (20 pts)'}</span>
              </div>
              <p className="text-base font-medium text-white leading-relaxed">{q.prompt}</p>

              {q.type === 'mcq' && q.options ? (
                <div className="space-y-2.5">
                  {q.options.map((opt) => {
                    const checked = answers[q.id] === opt;
                    return (
                      <label
                        key={opt}
                        className={`flex items-start gap-3 p-3.5 rounded-lg border text-sm cursor-pointer transition-colors ${
                          checked
                            ? 'bg-indigo-600/15 border-indigo-500/60 text-white'
                            : 'bg-[#070B14] border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`q-${q.id}`}
                          value={opt}
                          checked={checked}
                          onChange={() => setAnswers({ ...answers, [q.id]: opt })}
                          className="mt-0.5 accent-indigo-500"
                        />
                        <span>{opt}</span>
                      </label>
                    );
                  })}
                </div>
              ) : (
                <div className="space-y-2">
                  <textarea
                    rows={6}
                    value={answers[q.id] || ''}
                    onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                    placeholder="Write your code or technical explanation here..."
                    className="w-full p-3.5 text-sm font-mono bg-[#070B14] border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              )}
            </div>
          ))}

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={Boolean(busyAction)}
              className="px-6 py-3 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
            >
              Submit Assessment for AI Evaluation
            </button>
          </div>
        </form>
      )}

      {/* Instant Evaluation Result + Adaptive Roadmap Alert */}
      {latestResult && (
        <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <p className="text-xs text-slate-400">
                Evaluation Complete · {latestResult.record.careerContext}
              </p>
              <h2 className="text-xl font-bold text-white mt-0.5">
                {latestResult.record.skillName}: {latestResult.record.score}% · Verified Level:{' '}
                {latestResult.record.verifiedLevel}
              </h2>
            </div>
            <div className="text-sm font-semibold tabular-nums">
              {latestResult.record.passed ? (
                <span className="inline-flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  Passed (&ge; 65%)
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-amber-300">
                  <AlertTriangle className="w-4 h-4" />
                  Needs Reinforcement (&lt; 65%)
                </span>
              )}
            </div>
          </div>

          <p className="text-sm text-slate-200 leading-relaxed">{latestResult.record.explanation}</p>

          {latestResult.adapted && (
            <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/30 space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-amber-200">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Adaptive Learning Intelligence Triggered</span>
              </div>
              <p className="text-xs text-amber-100/90 leading-relaxed">
                {latestResult.decision.orchestratorSummary}
              </p>
              <button
                type="button"
                onClick={() => navigate('roadmap')}
                className="mt-1 text-xs font-semibold text-amber-300 hover:text-white underline cursor-pointer"
              >
                Inspect updated Learning Roadmap →
              </button>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-[#070B14] border border-slate-800">
              <h3 className="text-xs font-semibold text-emerald-400 mb-2">Verified Strengths</h3>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {latestResult.record.strengths.map((s) => (
                  <li key={s}>· {s}</li>
                ))}
              </ul>
            </div>
            <div className="p-4 rounded-lg bg-[#070B14] border border-slate-800">
              <h3 className="text-xs font-semibold text-amber-300 mb-2">Identified Gaps</h3>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {latestResult.record.weaknesses.map((w) => (
                  <li key={w}>· {w}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <h3 className="text-sm font-semibold text-white">Question-by-Question Breakdown</h3>
            {latestResult.record.questionResults.map((qr, idx) => (
              <div
                key={qr.questionId}
                className="p-3.5 rounded-lg bg-[#070B14] border border-slate-800 text-xs space-y-1"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium text-slate-200">
                    Q{idx + 1}: {qr.prompt}
                  </span>
                  <span className={qr.isCorrect ? 'text-emerald-400 shrink-0' : 'text-rose-400 shrink-0'}>
                    {qr.isCorrect ? 'Correct' : 'Needs Review'}
                  </span>
                </div>
                <p className="text-slate-400">Your Answer: {qr.userAnswer}</p>
                <p className="text-indigo-300">{qr.feedback}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Past Assessments Table */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
        <div className="flex items-center gap-2 mb-4">
          <ClipboardCheck className="w-4 h-4 text-indigo-400" />
          <h2 className="text-lg font-semibold text-white">Assessment History</h2>
        </div>
        {assessments.length === 0 ? (
          <p className="text-sm text-slate-400">
            No diagnostic assessments completed yet. Start one above to verify your skills.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400">
                  <th className="py-2.5 pr-4 font-medium">Skill</th>
                  <th className="py-2.5 pr-4 font-medium">Career Context</th>
                  <th className="py-2.5 pr-4 font-medium">Verified Level</th>
                  <th className="py-2.5 pr-4 font-medium text-right">Score</th>
                  <th className="py-2.5 font-medium text-right">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {assessments.map((a) => (
                  <tr key={a.id}>
                    <td className="py-3 pr-4 font-medium text-white">{a.skillName}</td>
                    <td className="py-3 pr-4 text-xs text-slate-400">{a.careerContext}</td>
                    <td className="py-3 pr-4 text-xs text-indigo-300">{a.verifiedLevel}</td>
                    <td
                      className={`py-3 pr-4 text-right font-mono tabular-nums ${
                        a.passed ? 'text-emerald-400' : 'text-amber-300'
                      }`}
                    >
                      {a.score}%
                    </td>
                    <td className="py-3 text-right text-xs text-slate-400 tabular-nums">
                      {new Date(a.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
