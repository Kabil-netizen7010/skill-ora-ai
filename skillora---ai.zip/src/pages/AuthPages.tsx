import React, { useState } from 'react';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { ALL_CAREERS, COMMON_SKILLS_SUGGESTIONS } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';
import type { CareerId, ProficiencyLevel, SkillEntry } from '../types/skillora.ts';

export function RegisterPage() {
  const { register, loginWithGoogle, navigate, busyAction, errorMessage, clearError } = useSkillora();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [education, setEducation] = useState('B.Tech / B.S. Computer Science');
  const [department, setDepartment] = useState('Computer Science & Engineering');
  const [yearOfStudy, setYearOfStudy] = useState('3rd Year');
  const [targetCareer, setTargetCareer] = useState<CareerId>('Full Stack Developer');

  const [skills, setSkills] = useState<SkillEntry[]>([
    { name: 'Python', category: 'Technical', selfReportedLevel: 'Intermediate' },
    { name: 'SQL', category: 'Technical', selfReportedLevel: 'Beginner' },
  ]);
  const [newSkillName, setNewSkillName] = useState('HTML & CSS');
  const [newSkillLevel, setNewSkillLevel] = useState<ProficiencyLevel>('Beginner');
  const [localError, setLocalError] = useState<string | null>(null);

  const addSkill = () => {
    const trimmed = newSkillName.trim();
    if (!trimmed) return;
    if (skills.some((s) => s.name.toLowerCase() === trimmed.toLowerCase())) return;
    setSkills([...skills, { name: trimmed, category: 'Technical', selfReportedLevel: newSkillLevel }]);
    setNewSkillName('');
  };

  const removeSkill = (name: string) => {
    setSkills(skills.filter((s) => s.name !== name));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();
    if (fullName.trim().length < 2) {
      setLocalError('Please enter your full name.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setLocalError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setLocalError('Password must be at least 6 characters.');
      return;
    }
    try {
      await register({
        fullName,
        email,
        password,
        education,
        department,
        yearOfStudy,
        targetCareer,
        initialSkills: skills,
      });
    } catch {
      // handled by context errorMessage
    }
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6">
      <div className="max-w-2xl w-full mx-auto">
        <button
          type="button"
          onClick={() => navigate('landing')}
          className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Skillora - AI</span>
        </button>

        <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 sm:p-8">
          <h1 className="text-2xl font-bold text-white tracking-tight">Create your student account</h1>
          <p className="mt-1.5 text-sm text-slate-400">
            Set up your academic profile, current self-reported skills, and target career to initialize your personalized roadmap.
          </p>

          {(localError || errorMessage) && (
            <div className="mt-5 px-4 py-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-sm text-rose-200">
              {localError || errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Full Name</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Aarav Sharma"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@university.edu"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Password (min 6 chars)</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Target Career Goal</label>
                <select
                  value={targetCareer}
                  onChange={(e) => setTargetCareer(e.target.value as CareerId)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                >
                  {ALL_CAREERS.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Education</label>
                <input
                  type="text"
                  value={education}
                  onChange={(e) => setEducation(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Department</label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Year / Stage</label>
                <select
                  value={yearOfStudy}
                  onChange={(e) => setYearOfStudy(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="1st Year">1st Year</option>
                  <option value="2nd Year">2nd Year</option>
                  <option value="3rd Year">3rd Year</option>
                  <option value="Final Year">Final Year</option>
                  <option value="Fresh Graduate">Fresh Graduate</option>
                  <option value="Working Professional">Working Professional</option>
                </select>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <label className="block text-xs font-medium text-slate-300 mb-2">
                Initial Self-Reported Skills (assessed & verified later)
              </label>
              <div className="flex flex-wrap gap-2 mb-3">
                {skills.map((s) => (
                  <div
                    key={s.name}
                    className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200"
                  >
                    <span>
                      {s.name} · {s.selfReportedLevel}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeSkill(s.name)}
                      className="text-slate-400 hover:text-rose-400 cursor-pointer"
                      aria-label={`Remove ${s.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  list="skill-suggestions"
                  value={newSkillName}
                  onChange={(e) => setNewSkillName(e.target.value)}
                  placeholder="Add a skill (e.g. React, Python)"
                  className="flex-1 min-w-[180px] px-3 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
                <datalist id="skill-suggestions">
                  {COMMON_SKILLS_SUGGESTIONS.map((s) => (
                    <option key={s} value={s} />
                  ))}
                </datalist>
                <select
                  value={newSkillLevel}
                  onChange={(e) => setNewSkillLevel(e.target.value as ProficiencyLevel)}
                  className="px-3 py-2 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
                <button
                  type="button"
                  onClick={addSkill}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Skill</span>
                </button>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                type="submit"
                disabled={Boolean(busyAction)}
                className="flex-1 py-2.5 px-5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
              >
                {busyAction || 'Create Student Account'}
              </button>
              <button
                type="button"
                disabled={Boolean(busyAction)}
                onClick={() => void loginWithGoogle().catch(() => {})}
                className="py-2.5 px-5 text-sm font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                Continue with Google
              </button>
            </div>
          </form>

          <p className="mt-6 text-center text-sm text-slate-400">
            Already have a student account?{' '}
            <button
              type="button"
              onClick={() => navigate('login')}
              className="text-indigo-400 hover:text-indigo-300 font-medium cursor-pointer"
            >
              Sign in
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

export function LoginPage() {
  const { login, loginWithGoogle, navigate, busyAction, errorMessage, clearError } = useSkillora();

  const [mode, setMode] = useState<'login' | 'forgot' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [recoveryCode, setRecoveryCode] = useState('');
  const [issuedCodeNotice, setIssuedCodeNotice] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [localError, setLocalError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();
    try {
      await login(email, password);
    } catch {
      // handled in context
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    setStatusMsg(null);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = (await res.json()) as {
        error?: string;
        message?: string;
        recoveryCode?: string;
      };
      if (!res.ok) throw new Error(data.error || 'Could not generate recovery code.');
      setStatusMsg(data.message || 'Recovery code generated.');
      if (data.recoveryCode) {
        setIssuedCodeNotice(data.recoveryCode);
        setRecoveryCode(data.recoveryCode);
      }
      setMode('reset');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Request failed.');
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    setStatusMsg(null);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code: recoveryCode, newPassword }),
      });
      const data = (await res.json()) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error || 'Could not reset password.');
      setStatusMsg(data.message || 'Password updated. Sign in below.');
      setIssuedCodeNotice(null);
      setPassword('');
      setMode('login');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Reset failed.');
    }
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6">
      <div className="max-w-md w-full mx-auto">
        <button
          type="button"
          onClick={() => navigate('landing')}
          className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Skillora - AI</span>
        </button>

        <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 sm:p-8">
          <h1 className="text-2xl font-bold text-white tracking-tight">
            {mode === 'login'
              ? 'Sign in to Skillora - AI'
              : mode === 'forgot'
                ? 'Recover your password'
                : 'Set a new password'}
          </h1>
          <p className="mt-1.5 text-sm text-slate-400">
            {mode === 'login'
              ? 'Access your verified skill profile, career matches, and adaptive roadmap.'
              : mode === 'forgot'
                ? 'Enter your registered email address to receive a recovery code.'
                : 'Enter the 6-digit recovery code and choose a new password.'}
          </p>

          {(localError || errorMessage) && (
            <div className="mt-5 px-4 py-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-sm text-rose-200">
              {localError || errorMessage}
            </div>
          )}

          {statusMsg && (
            <div className="mt-5 px-4 py-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-sm text-emerald-200">
              <p>{statusMsg}</p>
              {issuedCodeNotice && (
                <p className="mt-1 font-mono text-xs text-emerald-300">
                  Recovery Code: {issuedCodeNotice}
                </p>
              )}
            </div>
          )}

          {mode === 'login' && (
            <form onSubmit={handleLogin} className="mt-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@university.edu"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-medium text-slate-300">Password</label>
                  <button
                    type="button"
                    onClick={() => {
                      setLocalError(null);
                      setMode('forgot');
                    }}
                    className="text-xs text-indigo-400 hover:text-indigo-300 cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                disabled={Boolean(busyAction)}
                className="w-full py-2.5 px-5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
              >
                {busyAction || 'Sign In'}
              </button>

              <div className="relative py-2 flex items-center justify-center">
                <div className="border-t border-slate-800 w-full" />
                <span className="px-3 text-xs text-slate-500 bg-[#0D1322] shrink-0">or</span>
                <div className="border-t border-slate-800 w-full" />
              </div>

              <button
                type="button"
                disabled={Boolean(busyAction)}
                onClick={() => void loginWithGoogle().catch(() => {})}
                className="w-full py-2.5 px-5 text-sm font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                Sign in with Google
              </button>
            </form>
          )}

          {mode === 'forgot' && (
            <form onSubmit={handleForgot} className="mt-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Registered Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@university.edu"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 px-5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors cursor-pointer"
              >
                Generate Recovery Code
              </button>
              <button
                type="button"
                onClick={() => setMode('login')}
                className="w-full py-2 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Return to Sign In
              </button>
            </form>
          )}

          {mode === 'reset' && (
            <form onSubmit={handleReset} className="mt-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">6-Digit Recovery Code</label>
                <input
                  type="text"
                  required
                  value={recoveryCode}
                  onChange={(e) => setRecoveryCode(e.target.value)}
                  placeholder="123456"
                  className="w-full px-3.5 py-2.5 text-sm font-mono bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">New Password (min 6 chars)</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#070B14] border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 px-5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors cursor-pointer"
              >
                Reset Password
              </button>
              <button
                type="button"
                onClick={() => setMode('login')}
                className="w-full py-2 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Return to Sign In
              </button>
            </form>
          )}

          <p className="mt-6 text-center text-sm text-slate-400">
            New to Skillora - AI?{' '}
            <button
              type="button"
              onClick={() => navigate('register')}
              className="text-indigo-400 hover:text-indigo-300 font-medium cursor-pointer"
            >
              Create an account
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
