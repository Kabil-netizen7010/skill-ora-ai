import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Compass, Layers, RefreshCw } from 'lucide-react';
import { ALL_CAREERS, CAREER_CATALOG } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';
import type { CareerId } from '../types/skillora.ts';

export function CareerExplorerPage() {
  const { profile, matches, switchCareer, busyAction, navigate } = useSkillora();
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  if (!profile) return null;

  const handleSelectCareer = async (careerId: CareerId) => {
    await switchCareer(careerId);
    navigate('roadmap');
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Career Explorer</h1>
        <p className="mt-1 text-sm text-slate-400">
          Inspect core competencies, prerequisites, and live compatibility across six technical careers. Switching your target preserves all prior learning history.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ALL_CAREERS.map((careerId) => {
          const def = CAREER_CATALOG[careerId];
          const match = matches.find((m) => m.career === careerId);
          const isCurrent = profile.targetCareer === careerId;

          return (
            <div
              key={careerId}
              className={`rounded-xl border bg-[#0D1322] overflow-hidden flex flex-col justify-between ${
                isCurrent ? 'border-indigo-500/60' : 'border-slate-800'
              }`}
            >
              <div>
                <div className="h-44 w-full bg-[#070B14] border-b border-slate-800 overflow-hidden">
                  {!failedImages[careerId] ? (
                    <img
                      src={def.image}
                      alt={`${def.career} technical track visual`}
                      referrerPolicy="no-referrer"
                      onError={() => setFailedImages((prev) => ({ ...prev, [careerId]: true }))}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-indigo-950/50">
                      <Compass className="w-10 h-10 text-indigo-400" />
                    </div>
                  )}
                </div>

                <div className="p-6 space-y-4">
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                      <span>~{def.averageRampWeeks} Weeks Ramp</span>
                      <span className="font-mono tabular-nums text-indigo-300">
                        {match ? `${match.compatibilityScore}% Match` : '—'}
                      </span>
                    </div>
                    <h2 className="text-lg font-semibold text-white">{def.career}</h2>
                    <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">{def.summary}</p>
                  </div>

                  <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                    <p className="text-xs font-medium text-slate-300">Core Skill Requirements</p>
                    <ul className="space-y-1 text-xs text-slate-400">
                      {def.coreSkills.map((cs) => (
                        <li key={cs.name} className="flex items-center justify-between gap-2">
                          <span className="truncate">{cs.name}</span>
                          <span className="text-slate-500 shrink-0">{cs.minLevel}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="px-6 pb-6">
                {isCurrent ? (
                  <button
                    type="button"
                    onClick={() => navigate('career-matching')}
                    className="w-full py-2.5 px-4 text-xs font-semibold text-indigo-200 bg-indigo-600/20 border border-indigo-500/40 rounded-lg inline-flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                    <span>Current Target · View Breakdown</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={Boolean(busyAction)}
                    onClick={() => void handleSelectCareer(careerId).catch(() => {})}
                    className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-800 hover:bg-indigo-600 disabled:opacity-50 rounded-lg transition-colors inline-flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Switch Goal & Rebuild Roadmap</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function CareerMatchingPage() {
  const {
    profile,
    matches,
    decisions,
    runOrchestrator,
    switchCareer,
    busyAction,
    navigate,
  } = useSkillora();

  const [selectedCareer, setSelectedCareer] = useState<CareerId>(
    profile?.targetCareer || 'Full Stack Developer'
  );

  if (!profile) return null;

  const activeMatch =
    matches.find((m) => m.career === selectedCareer) ||
    matches.find((m) => m.career === profile.targetCareer) ||
    matches[0];

  const latestDecision = decisions[0];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Career Matching Results</h1>
          <p className="mt-1 text-sm text-slate-400">
            Transparent compatibility estimates calculated from your verified assessments and self-reported competencies.
          </p>
        </div>
        <button
          type="button"
          disabled={Boolean(busyAction)}
          onClick={() => void runOrchestrator('Manual Career & Agent Orchestration').catch(() => {})}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${busyAction ? 'animate-spin' : ''}`} />
          <span>Run 5-Agent Analysis</span>
        </button>
      </div>

      {/* Career Selector Tabs */}
      <div className="flex flex-wrap gap-2">
        {matches.map((m) => {
          const selected = m.career === (activeMatch?.career || profile.targetCareer);
          return (
            <button
              key={m.career}
              type="button"
              onClick={() => setSelectedCareer(m.career)}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap cursor-pointer ${
                selected
                  ? 'bg-indigo-600 text-white border-indigo-500'
                  : 'bg-[#0D1322] text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
            >
              {m.career} · <span className="font-mono tabular-nums">{m.compatibilityScore}%</span>
            </button>
          );
        })}
      </div>

      {activeMatch && (
        <div className="space-y-6">
          {/* Primary Match Banner */}
          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="text-xs text-slate-400">
                <span>
                  {activeMatch.career === profile.targetCareer
                    ? 'Primary Target Career'
                    : 'Alternative Career Simulation'}
                </span>
                <span className="mx-1.5">·</span>
                <span>Verified Skill Weight: {activeMatch.verifiedCoveragePct}%</span>
              </div>
              <h2 className="text-2xl font-bold text-white">
                {activeMatch.career} Compatibility: {activeMatch.compatibilityScore}%
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed">{activeMatch.transparencyNote}</p>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              {activeMatch.career !== profile.targetCareer && (
                <button
                  type="button"
                  disabled={Boolean(busyAction)}
                  onClick={() => void switchCareer(activeMatch.career).catch(() => {})}
                  className="px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg cursor-pointer"
                >
                  Switch Goal to {activeMatch.career}
                </button>
              )}
              <button
                type="button"
                onClick={() => navigate('roadmap')}
                className="px-4 py-2.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer"
              >
                Open Roadmap
              </button>
            </div>
          </div>

          {/* 3-Column Gap Breakdown */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-3">
              <h3 className="text-sm font-semibold text-emerald-400">
                Existing Matching Skills ({activeMatch.matchingSkills.length})
              </h3>
              {activeMatch.matchingSkills.length === 0 ? (
                <p className="text-xs text-slate-400">No full competency matches yet.</p>
              ) : (
                <ul className="space-y-2.5 text-xs">
                  {activeMatch.matchingSkills.map((s) => (
                    <li key={s.name} className="p-3 rounded-lg bg-[#070B14] border border-slate-800">
                      <p className="font-medium text-white">{s.name}</p>
                      <p className="text-slate-400 mt-0.5">
                        Level: {s.studentLevel} (Required: {s.requiredLevel}) ·{' '}
                        {s.verified ? 'Assessment Verified' : 'Self-Reported'}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-3">
              <h3 className="text-sm font-semibold text-sky-400">
                Partially Developed ({activeMatch.partialSkills.length})
              </h3>
              {activeMatch.partialSkills.length === 0 ? (
                <p className="text-xs text-slate-400">No partial skill gaps.</p>
              ) : (
                <ul className="space-y-2.5 text-xs">
                  {activeMatch.partialSkills.map((s) => (
                    <li key={s.name} className="p-3 rounded-lg bg-[#070B14] border border-slate-800">
                      <p className="font-medium text-white">{s.name}</p>
                      <p className="text-slate-400 mt-0.5">{s.gapDetail}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-3">
              <h3 className="text-sm font-semibold text-amber-300">
                Missing Skills ({activeMatch.missingSkills.length})
              </h3>
              {activeMatch.missingSkills.length === 0 ? (
                <p className="text-xs text-slate-400">All core skills are present.</p>
              ) : (
                <ul className="space-y-2.5 text-xs">
                  {activeMatch.missingSkills.map((s) => (
                    <li key={s.name} className="p-3 rounded-lg bg-[#070B14] border border-slate-800">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-white">{s.name}</span>
                        <span className="text-slate-500 font-mono">{s.weight}% wt</span>
                      </div>
                      <p className="text-slate-400 mt-0.5">
                        Needs {s.requiredLevel}
                        {s.prerequisites.length > 0
                          ? ` · Prereq: ${s.prerequisites.join(', ')}`
                          : ''}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Recommended Improvements */}
          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <h3 className="text-base font-semibold text-white mb-3">Recommended Improvements</h3>
            {activeMatch.recommendedImprovements.length === 0 ? (
              <p className="text-sm text-emerald-300">
                Your verified profile meets all baseline core competencies for {activeMatch.career}.
              </p>
            ) : (
              <ul className="space-y-2 text-sm text-slate-300">
                {activeMatch.recommendedImprovements.map((rec) => (
                  <li key={rec}>· {rec}</li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {/* Multi-Agent Collaboration Trace */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <h2 className="text-lg font-semibold text-white">
            Multi-Agent Orchestrator Collaboration Trace
          </h2>
        </div>
        {!latestDecision ? (
          <p className="text-sm text-slate-400">
            Click "Run 5-Agent Analysis" above to watch Skill Analyzer, Career Matching, Learning Recommendation, Progress Evaluation, and the Central Orchestrator exchange structured findings.
          </p>
        ) : (
          <div className="space-y-4">
            <div className="text-xs text-indigo-300">
              Trigger: {latestDecision.triggerEvent} ·{' '}
              {new Date(latestDecision.createdAt).toLocaleString()}
            </div>
            <p className="text-sm text-slate-200">{latestDecision.orchestratorSummary}</p>
            <div className="divide-y divide-slate-800/80 border-y border-slate-800/80">
              {latestDecision.agentTrace.map((step) => (
                <div key={step.agentName} className="py-4 grid md:grid-cols-12 gap-3">
                  <div className="md:col-span-4">
                    <p className="text-sm font-semibold text-white">{step.agentName}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{step.role}</p>
                  </div>
                  <div className="md:col-span-8 space-y-1">
                    <p className="text-xs text-slate-500">Input: {step.inputSummary}</p>
                    <p className="text-sm text-slate-300">{step.decisionSummary}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
