import React from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { CAREER_CATALOG, PROFICIENCY_SCORE_MAP } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';

export function SkillAnalysisPage() {
  const { profile, assessments, matches, navigate } = useSkillora();

  if (!profile) return null;

  const targetMatch = matches.find((m) => m.career === profile.targetCareer);
  const careerDef = CAREER_CATALOG[profile.targetCareer];

  const comparisonData = careerDef.coreSkills.map((req) => {
    const found = profile.skills.find((s) => s.name.toLowerCase() === req.name.toLowerCase());
    const selfVal = found ? PROFICIENCY_SCORE_MAP[found.selfReportedLevel] * 25 : 0;
    const verifiedVal = found?.verifiedLevel ? PROFICIENCY_SCORE_MAP[found.verifiedLevel] * 25 : 0;
    const requiredVal = PROFICIENCY_SCORE_MAP[req.minLevel] * 25;
    return {
      skill: req.name.length > 16 ? `${req.name.slice(0, 15)}…` : req.name,
      fullSkill: req.name,
      Required: requiredVal,
      Verified: verifiedVal,
      SelfReported: selfVal,
    };
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">AI Skill Analysis Dashboard</h1>
          <p className="mt-1 text-sm text-slate-400">
            Compares self-reported claims against assessment-verified evidence for {profile.targetCareer}.
          </p>
        </div>
        <button
          type="button"
          onClick={() => navigate('assessments')}
          className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          Verify Another Skill
        </button>
      </div>

      {/* Charts Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
          <h2 className="text-base font-semibold text-white mb-1">
            Competency Radar: Required vs. Verified
          </h2>
          <p className="text-xs text-slate-400 mb-4">
            Target baseline against your assessment-verified mastery (0-100 scale)
          </p>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={comparisonData}>
                <PolarGrid stroke="#1E293B" />
                <PolarAngleAxis dataKey="skill" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <PolarRadiusAxis domain={[0, 100]} tick={{ fill: '#64748B', fontSize: 10 }} />
                <Radar
                  name="Role Requirement"
                  dataKey="Required"
                  stroke="#38BDF8"
                  fill="#38BDF8"
                  fillOpacity={0.18}
                />
                <Radar
                  name="Assessment Verified"
                  dataKey="Verified"
                  stroke="#6366F1"
                  fill="#6366F1"
                  fillOpacity={0.35}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0A101E',
                    borderColor: '#1E293B',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
          <h2 className="text-base font-semibold text-white mb-1">
            Self-Reported vs. Verified Evidence
          </h2>
          <p className="text-xs text-slate-400 mb-4">
            Unverified claims highlight where diagnostic verification is still needed
          </p>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="skill" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0A101E',
                    borderColor: '#1E293B',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                />
                <Bar dataKey="SelfReported" name="Self-Reported" fill="#475569" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Verified" name="Verified" fill="#6366F1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Required" name="Target Role" fill="#0284C7" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Strengths, Weaknesses & Missing Skills */}
      {targetMatch && (
        <div className="grid md:grid-cols-3 gap-6">
          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <h3 className="text-sm font-semibold text-emerald-400 mb-3">
              Verified & Matching Strengths ({targetMatch.matchingSkills.length})
            </h3>
            {targetMatch.matchingSkills.length === 0 ? (
              <p className="text-xs text-slate-400">No matching skills verified yet.</p>
            ) : (
              <ul className="space-y-2.5 text-xs">
                {targetMatch.matchingSkills.map((s) => (
                  <li key={s.name} className="pb-2 border-b border-slate-800/70">
                    <p className="font-medium text-white">{s.name}</p>
                    <p className="text-slate-400 mt-0.5">
                      {s.studentLevel} (needs {s.requiredLevel}) ·{' '}
                      {s.verified ? `Verified (${s.score ?? 'Passed'}%)` : 'Self-reported only'}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <h3 className="text-sm font-semibold text-sky-400 mb-3">
              Partially Developed Skills ({targetMatch.partialSkills.length})
            </h3>
            {targetMatch.partialSkills.length === 0 ? (
              <p className="text-xs text-slate-400">No partial skill gaps detected.</p>
            ) : (
              <ul className="space-y-2.5 text-xs">
                {targetMatch.partialSkills.map((s) => (
                  <li key={s.name} className="pb-2 border-b border-slate-800/70">
                    <p className="font-medium text-white">{s.name}</p>
                    <p className="text-slate-400 mt-0.5">{s.gapDetail}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-xl border border-slate-800 bg-[#0D1322] p-6">
            <h3 className="text-sm font-semibold text-amber-300 mb-3">
              Missing Competencies ({targetMatch.missingSkills.length})
            </h3>
            {targetMatch.missingSkills.length === 0 ? (
              <p className="text-xs text-slate-400">Zero missing core competencies.</p>
            ) : (
              <ul className="space-y-2.5 text-xs">
                {targetMatch.missingSkills.map((s) => (
                  <li key={s.name} className="pb-2 border-b border-slate-800/70">
                    <p className="font-medium text-white">{s.name}</p>
                    <p className="text-slate-400 mt-0.5">
                      Target: {s.requiredLevel}
                      {s.prerequisites.length > 0
                        ? ` · Prerequisites: ${s.prerequisites.join(', ')}`
                        : ' · Foundational'}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {/* Detailed Assessment Explanations */}
      <section className="rounded-xl border border-slate-800 bg-[#0D1322] p-6 space-y-4">
        <h2 className="text-lg font-semibold text-white">
          Evidence & AI Explanations for Every Assessment
        </h2>
        {assessments.length === 0 ? (
          <p className="text-sm text-slate-400">
            Complete a skill assessment to see evidence-backed explanations of your strengths and weaknesses.
          </p>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {assessments.map((a) => (
              <div key={a.id} className="py-4 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-base font-semibold text-white">
                    {a.skillName} · {a.verifiedLevel} ({a.score}%)
                  </h3>
                  <span className="text-xs text-slate-400">
                    {a.careerContext} · {new Date(a.createdAt).toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">{a.explanation}</p>
                <div className="text-xs text-slate-400">
                  <span className="text-emerald-400">Strengths:</span> {a.strengths.join('; ')} ·{' '}
                  <span className="text-amber-300">Weaknesses:</span> {a.weaknesses.join('; ')}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
