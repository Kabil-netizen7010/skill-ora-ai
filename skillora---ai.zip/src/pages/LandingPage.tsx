import React, { useState } from 'react';
import { ArrowRight, Check, Layers, ShieldCheck, Target, Workflow } from 'lucide-react';
import { ALL_CAREERS, CAREER_CATALOG } from '../data/careerCatalog.ts';
import { useSkillora } from '../context/SkilloraContext.tsx';

export function LandingPage() {
  const { navigate, user } = useSkillora();
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  const agents = [
    {
      num: '01.',
      name: 'Skill Analyzer',
      detail:
        'Evaluates self-reported profiles against diagnostic quiz and practical exercise performance to separate claimed familiarity from verified capability.',
    },
    {
      num: '02.',
      name: 'Career Matching Agent',
      detail:
        'Compares verified competencies against structured role requirements across six engineering tracks with transparent compatibility scoring.',
    },
    {
      num: '03.',
      name: 'Learning Recommendation Agent',
      detail:
        'Constructs prerequisite-safe roadmaps with curated resources, coding drills, and mini-projects—never recommending React before JavaScript.',
    },
    {
      num: '04.',
      name: 'Progress Evaluation Agent',
      detail:
        'Monitors assessment scores and module completions in real time, detecting weak areas and triggering adaptive remediation with clear explanations.',
    },
    {
      num: '05.',
      name: 'AI Mentor Agent',
      detail:
        'Answers daily study questions, explains missed concepts, generates practice exercises, and models career switch impacts using your live context.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-40 bg-[#070B14]/90 backdrop-blur-md border-b border-slate-800/80">
        <div className="max-w-[1280px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => navigate('landing')}
            className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            Skillora - AI
          </button>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
            <a href="#capabilities" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Capabilities
            </a>
            <a href="#agents" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Agents
            </a>
            <a href="#careers" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Careers
            </a>
            <a href="#workflow" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Workflow
            </a>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigate(user ? 'dashboard' : 'register')}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {user ? 'Open Workspace' : 'Get Started'}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-[1280px] mx-auto px-6 pt-16 pb-20 lg:pt-24 lg:pb-28">
        <div className="grid lg:grid-cols-12 gap-12 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-sm font-medium text-indigo-400 mb-4">
              Discover Your Skills · Bridge Your Gaps · Build Your Future
            </p>
            <h1 className="text-[clamp(2.25rem,4vw,3.6rem)] font-bold tracking-tight text-white leading-[1.1] text-balance">
              Evidence-based skill intelligence and adaptive roadmaps for modern tech careers.
            </h1>
            <p className="mt-6 text-base text-slate-300 leading-relaxed max-w-xl">
              Instead of recommending identical courses to every student, Skillora - AI coordinates five specialized AI agents to verify what you actually know, quantify career gaps transparently, and adapt your learning path whenever your performance or goals change.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => navigate(user ? 'dashboard' : 'register')}
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <span>{user ? 'Go to Student Dashboard' : 'Create Student Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              {!user && (
                <button
                  type="button"
                  onClick={() => navigate('login')}
                  className="px-6 py-3 text-sm font-semibold text-slate-200 hover:text-white border border-slate-700 hover:border-slate-500 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  Sign In
                </button>
              )}
            </div>

            <div className="mt-10 pt-8 border-t border-slate-800/80 grid grid-cols-3 gap-6">
              <div>
                <p className="text-2xl font-bold text-white tabular-nums">5 Agents</p>
                <p className="text-xs text-slate-400 mt-1">Central orchestrator coordination</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-white tabular-nums">6 Tracks</p>
                <p className="text-xs text-slate-400 mt-1">AI, ML, Data, Full Stack, SWE, Cyber</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-white tabular-nums">Adaptive</p>
                <p className="text-xs text-slate-400 mt-1">Auto-remediation on weak scores</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 flex">
            <div className="w-full rounded-xl overflow-hidden border border-slate-800 bg-[#0D1424] flex flex-col">
              {!heroImgFailed ? (
                <img
                  src="/src/assets/images/hero_skillora_platform_1794647879510.jpg"
                  alt="Skillora - AI interconnected skill and career intelligence architecture"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgFailed(true)}
                  className="w-full h-72 sm:h-96 lg:h-full object-cover"
                />
              ) : (
                <div className="w-full h-72 sm:h-96 lg:h-full bg-gradient-to-br from-slate-900 via-indigo-950/50 to-slate-950 flex items-center justify-center p-8">
                  <Workflow className="w-16 h-16 text-indigo-400" />
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Capabilities Section */}
      <section id="capabilities" className="border-t border-slate-800/80 bg-[#0A0F1D]">
        <div className="max-w-[1280px] mx-auto px-6 py-20">
          <div className="max-w-2xl mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight text-balance">
              Built around verified evidence, not generic course playlists
            </h2>
            <p className="mt-3 text-slate-400 text-base">
              Every recommendation in Skillora - AI traces directly to your profile, assessment responses, and target career dependencies.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 rounded-xl border border-slate-800 bg-[#0F172A]/60">
              <ShieldCheck className="w-5 h-5 text-indigo-400 mb-4" />
              <h3 className="text-lg font-semibold text-white">Self-Reported vs. Verified</h3>
              <p className="mt-2 text-sm text-slate-400 leading-relaxed">
                Claimed skills are weighted conservatively until proven through diagnostic MCQs and practical coding challenges with AI explanations.
              </p>
            </div>
            <div className="p-6 rounded-xl border border-slate-800 bg-[#0F172A]/60">
              <Layers className="w-5 h-5 text-sky-400 mb-4" />
              <h3 className="text-lg font-semibold text-white">Prerequisite-Safe Roadmaps</h3>
              <p className="mt-2 text-sm text-slate-400 leading-relaxed">
                Topics are ordered strictly by dependency graphs so foundational languages and concepts precede frameworks and system architectures.
              </p>
            </div>
            <div className="p-6 rounded-xl border border-slate-800 bg-[#0F172A]/60">
              <Target className="w-5 h-5 text-indigo-400 mb-4" />
              <h3 className="text-lg font-semibold text-white">Adaptive Goal Switching</h3>
              <p className="mt-2 text-sm text-slate-400 leading-relaxed">
                Switch your career target anytime—your verified skills and completed history stay intact while gaps and roadmaps recalculate immediately.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5-Agent Orchestration Section */}
      <section id="agents" className="border-t border-slate-800/80">
        <div className="max-w-[1280px] mx-auto px-6 py-20">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl">
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Five specialized AI agents coordinated by a Central Orchestrator
              </h2>
              <p className="mt-3 text-slate-400 text-base">
                Agents exchange structured JSON findings sequentially so career matching, roadmap ordering, and mentor guidance never contradict each other.
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-800/80 border-y border-slate-800/80">
            {agents.map((agent) => (
              <div key={agent.name} className="py-6 grid md:grid-cols-12 gap-4 items-baseline">
                <div className="md:col-span-4 flex items-baseline gap-3">
                  <span className="font-mono text-sm text-indigo-400 tabular-nums">{agent.num}</span>
                  <h3 className="text-lg font-semibold text-white">{agent.name}</h3>
                </div>
                <p className="md:col-span-8 text-sm text-slate-300 leading-relaxed">{agent.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Career Tracks Section */}
      <section id="careers" className="border-t border-slate-800/80 bg-[#0A0F1D]">
        <div className="max-w-[1280px] mx-auto px-6 py-20">
          <div className="max-w-2xl mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Supported technical career tracks
            </h2>
            <p className="mt-3 text-slate-400 text-base">
              Transparent compatibility estimates benchmark your skills against real core competencies for six high-demand roles.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ALL_CAREERS.map((careerId) => {
              const def = CAREER_CATALOG[careerId];
              return (
                <div
                  key={careerId}
                  className="rounded-xl border border-slate-800 bg-[#0F172A]/70 p-6 flex flex-col justify-between"
                >
                  <div>
                    <div className="text-xs text-slate-400 mb-2">
                      <span>{def.coreSkills.length} Core Skills</span>
                      <span className="mx-1.5">·</span>
                      <span>~{def.averageRampWeeks} Weeks Ramp</span>
                    </div>
                    <h3 className="text-lg font-semibold text-white">{def.career}</h3>
                    <p className="mt-2 text-sm text-slate-400 leading-relaxed">{def.summary}</p>
                  </div>
                  <div className="mt-5 pt-4 border-t border-slate-800/80 text-xs text-slate-300">
                    Key focus: {def.coreSkills.slice(0, 3).map((s) => s.name).join(', ')}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* End-to-End Workflow Section */}
      <section id="workflow" className="border-t border-slate-800/80">
        <div className="max-w-[1280px] mx-auto px-6 py-20">
          <div className="rounded-xl border border-slate-800 bg-gradient-to-br from-[#0F172A] to-[#111936] p-8 sm:p-12 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
            <div className="max-w-2xl">
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Start your evidence-based learning cycle
              </h2>
              <ul className="mt-5 grid sm:grid-cols-2 gap-3 text-sm text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span>Register profile & target career</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span>Take AI diagnostic assessments</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span>Review transparent career matches</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span>Follow adaptive roadmap & AI Mentor</span>
                </li>
              </ul>
            </div>
            <div className="shrink-0">
              <button
                type="button"
                onClick={() => navigate(user ? 'dashboard' : 'register')}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <span>{user ? 'Open Dashboard' : 'Get Started Now'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-800/80 py-8 px-6">
        <div className="max-w-[1280px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <span>Skillora - AI · Personalized Learning & Career Intelligence</span>
          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={() => navigate('login')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => navigate('register')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Register
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
