import React, { useState } from 'react';
import {
  Activity,
  Award,
  BookOpen,
  Bot,
  Briefcase,
  CheckCircle2,
  ClipboardCheck,
  Compass,
  LayoutDashboard,
  LogOut,
  Map as MapIcon,
  Menu,
  RefreshCw,
  Settings,
  User,
  X,
} from 'lucide-react';
import { useSkillora, type AppPage } from '../context/SkilloraContext.tsx';

const PAGE_LABELS: Record<AppPage, string> = {
  landing: 'Home',
  register: 'Register',
  login: 'Sign In',
  dashboard: 'Student Dashboard',
  profile: 'Student Profile',
  assessments: 'Skill Assessment',
  'skill-analysis': 'Skill Analysis',
  careers: 'Career Explorer',
  'career-matching': 'Career Matching Results',
  roadmap: 'Learning Roadmap',
  resources: 'Resource Library',
  progress: 'Progress Tracking',
  mentor: 'AI Mentor',
  settings: 'Settings',
};

const NAV_ITEMS: { id: AppPage; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'profile', label: 'Student Profile', icon: User },
  { id: 'assessments', label: 'Skill Assessment', icon: ClipboardCheck },
  { id: 'skill-analysis', label: 'Skill Analysis', icon: Activity },
  { id: 'careers', label: 'Career Explorer', icon: Compass },
  { id: 'career-matching', label: 'Career Matching', icon: Briefcase },
  { id: 'roadmap', label: 'Learning Roadmap', icon: MapIcon },
  { id: 'resources', label: 'Resource Library', icon: BookOpen },
  { id: 'progress', label: 'Progress Tracking', icon: Award },
  { id: 'mentor', label: 'AI Mentor', icon: Bot },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function WorkspaceLayout({ children }: { children: React.ReactNode }) {
  const {
    page,
    navigate,
    profile,
    logout,
    busyAction,
    errorMessage,
    clearError,
    runOrchestrator,
    aiConfigured,
  } = useSkillora();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (id: AppPage) => {
    navigate(id);
    setMobileOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-800/80 bg-[#0A101E]">
        <div className="h-16 flex items-center px-6 border-b border-slate-800/80">
          <button
            type="button"
            onClick={() => handleNav('dashboard')}
            className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            Skillora - AI
          </button>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto" aria-label="Primary Workspace">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = page === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  active
                    ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 border border-transparent'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800/80 space-y-3">
          {profile && (
            <div className="px-2">
              <p className="text-sm font-medium text-slate-100 truncate">{profile.fullName}</p>
              <p className="text-xs text-slate-400 truncate mt-0.5">{profile.targetCareer}</p>
            </div>
          )}
          <button
            type="button"
            onClick={() => logout()}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-sm font-medium text-slate-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70"
            onClick={() => setMobileOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative w-72 max-w-[85vw] bg-[#0A101E] border-r border-slate-800 flex flex-col h-full z-10">
            <div className="h-16 flex items-center justify-between px-5 border-b border-slate-800">
              <span className="text-lg font-bold tracking-tight text-white">Skillora - AI</span>
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                className="p-2 text-slate-400 hover:text-white"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = page === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNav(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                      active
                        ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30'
                        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 border border-transparent'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => logout()}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-sm font-medium text-slate-400 hover:text-rose-300 rounded-lg"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="h-16 sticky top-0 z-30 bg-[#070B14]/90 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-300 hover:text-white rounded-lg"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-500 hidden sm:inline">Workspace</span>
              <span className="text-slate-600 hidden sm:inline">/</span>
              <span className="font-semibold text-slate-100 truncate">{PAGE_LABELS[page]}</span>
              {profile && (
                <>
                  <span className="text-slate-600 hidden md:inline">·</span>
                  <span className="text-xs text-slate-400 hidden md:inline truncate">
                    Target: {profile.targetCareer}
                  </span>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              disabled={Boolean(busyAction)}
              onClick={() => void runOrchestrator().catch(() => {})}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${busyAction ? 'animate-spin' : ''}`} />
              <span>Sync AI Roadmap</span>
            </button>
          </div>
        </header>

        {!aiConfigured && (
          <div className="mx-4 sm:mx-8 mt-4 px-4 py-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-sm">
            AI generation requires a server-side Gemini API key configured in environment secrets. Profile tracking, skill gap calculations, and career scoring remain active.
          </div>
        )}

        {busyAction && (
          <div className="mx-4 sm:mx-8 mt-4 px-4 py-3 rounded-lg bg-indigo-500/10 border border-indigo-500/30 text-indigo-200 text-sm flex items-center gap-3">
            <RefreshCw className="w-4 h-4 animate-spin shrink-0 text-indigo-400" />
            <span>{busyAction}</span>
          </div>
        )}

        {errorMessage && (
          <div className="mx-4 sm:mx-8 mt-4 px-4 py-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-200 text-sm flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={clearError}
              className="text-xs font-medium text-rose-300 hover:text-white underline shrink-0 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        <main className="flex-1 px-4 sm:px-8 py-8 max-w-[1320px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
