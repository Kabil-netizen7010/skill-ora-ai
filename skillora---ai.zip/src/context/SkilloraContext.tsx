import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { signInWithPopup, signOut } from 'firebase/auth';
import { auth, googleAuthProvider, validateFirestoreConnection } from '../lib/firebase.ts';
import {
  syncActivityToFirestore,
  syncAssessmentToFirestore,
  syncDecisionToFirestore,
  syncMentorMessageToFirestore,
  syncProfileToFirestore,
  syncRoadmapToFirestore,
} from '../lib/firestoreSync.ts';
import type {
  AgentDecisionRecord,
  AssessmentQuestion,
  CareerId,
  CareerMatchResult,
  LearningActivity,
  LearningRoadmap,
  MentorMessage,
  SkillAssessmentRecord,
  SkillEntry,
  StudentProfile,
} from '../types/skillora.ts';

export type AppPage =
  | 'landing'
  | 'register'
  | 'login'
  | 'dashboard'
  | 'profile'
  | 'assessments'
  | 'skill-analysis'
  | 'careers'
  | 'career-matching'
  | 'roadmap'
  | 'resources'
  | 'progress'
  | 'mentor'
  | 'settings';

export interface AuthUser {
  uid: string;
  email: string;
  fullName: string;
  authProvider: string;
}

interface SkilloraContextValue {
  page: AppPage;
  navigate: (next: AppPage) => void;
  loadingAuth: boolean;
  busyAction: string | null;
  errorMessage: string | null;
  clearError: () => void;
  user: AuthUser | null;
  profile: StudentProfile | null;
  assessments: SkillAssessmentRecord[];
  roadmap: LearningRoadmap | null;
  roadmapHistory: LearningRoadmap[];
  matches: CareerMatchResult[];
  activities: LearningActivity[];
  decisions: AgentDecisionRecord[];
  mentorMessages: MentorMessage[];
  aiConfigured: boolean;
  register: (payload: {
    fullName: string;
    email: string;
    password: string;
    education: string;
    department: string;
    yearOfStudy: string;
    targetCareer: CareerId;
    initialSkills: SkillEntry[];
  }) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshWorkspace: () => Promise<void>;
  updateProfile: (patch: Partial<StudentProfile>) => Promise<void>;
  generateAssessment: (
    skillName: string,
    careerContext?: CareerId
  ) => Promise<{
    sessionId: string;
    skillName: string;
    careerContext: CareerId;
    questions: AssessmentQuestion[];
  }>;
  submitAssessment: (
    sessionId: string,
    answers: Record<string, string>
  ) => Promise<{
    record: SkillAssessmentRecord;
    adapted: boolean;
    decision: AgentDecisionRecord;
  }>;
  runOrchestrator: (triggerEvent?: string) => Promise<void>;
  switchCareer: (targetCareer: CareerId) => Promise<void>;
  toggleRoadmapProgress: (payload: {
    moduleId: string;
    topicId?: string;
    toggleExercise?: boolean;
    toggleMiniProject?: boolean;
    moduleStatus?: 'pending' | 'in_progress' | 'completed';
  }) => Promise<void>;
  requestExerciseFeedback: (payload: {
    moduleTitle: string;
    exercisePrompt: string;
    solution: string;
  }) => Promise<string>;
  logActivity: (payload: {
    type: LearningActivity['type'];
    title: string;
    skillName: string;
    status?: LearningActivity['status'];
  }) => Promise<void>;
  sendMentorMessage: (message: string) => Promise<void>;
  clearMentorChat: () => Promise<void>;
}

const TOKEN_STORAGE_KEY = 'skillora_session_token';

const ROUTE_TO_PAGE: Record<string, AppPage> = {
  '/': 'landing',
  '/register': 'register',
  '/login': 'login',
  '/dashboard': 'dashboard',
  '/profile': 'profile',
  '/assessments': 'assessments',
  '/skill-analysis': 'skill-analysis',
  '/careers': 'careers',
  '/career-matching': 'career-matching',
  '/roadmap': 'roadmap',
  '/resources': 'resources',
  '/progress': 'progress',
  '/mentor': 'mentor',
  '/settings': 'settings',
};

const PAGE_TO_ROUTE: Record<AppPage, string> = {
  landing: '/',
  register: '/register',
  login: '/login',
  dashboard: '/dashboard',
  profile: '/profile',
  assessments: '/assessments',
  'skill-analysis': '/skill-analysis',
  careers: '/careers',
  'career-matching': '/career-matching',
  roadmap: '/roadmap',
  resources: '/resources',
  progress: '/progress',
  mentor: '/mentor',
  settings: '/settings',
};

const PUBLIC_PAGES: AppPage[] = ['landing', 'register', 'login'];

const SkilloraContext = createContext<SkilloraContextValue | undefined>(undefined);

function resolveInitialPage(): AppPage {
  const path = window.location.pathname;
  return ROUTE_TO_PAGE[path] || 'landing';
}

export function SkilloraProvider({ children }: { children: React.ReactNode }) {
  const [page, setPage] = useState<AppPage>(resolveInitialPage);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem(TOKEN_STORAGE_KEY));
  const [loadingAuth, setLoadingAuth] = useState<boolean>(true);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [aiConfigured, setAiConfigured] = useState<boolean>(true);

  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [assessments, setAssessments] = useState<SkillAssessmentRecord[]>([]);
  const [roadmap, setRoadmap] = useState<LearningRoadmap | null>(null);
  const [roadmapHistory, setRoadmapHistory] = useState<LearningRoadmap[]>([]);
  const [matches, setMatches] = useState<CareerMatchResult[]>([]);
  const [activities, setActivities] = useState<LearningActivity[]>([]);
  const [decisions, setDecisions] = useState<AgentDecisionRecord[]>([]);
  const [mentorMessages, setMentorMessages] = useState<MentorMessage[]>([]);

  const clearError = useCallback(() => setErrorMessage(null), []);

  const navigate = useCallback((next: AppPage) => {
    setPage(next);
    const nextUrl = PAGE_TO_ROUTE[next] || '/';
    if (window.location.pathname !== nextUrl) {
      window.history.pushState({}, '', nextUrl);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onPopState = () => {
      setPage(resolveInitialPage());
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const apiFetch = useCallback(
    async <T,>(url: string, options: RequestInit = {}, overrideToken?: string): Promise<T> => {
      const authToken = overrideToken ?? token;
      const headers = new Headers(options.headers || {});
      if (!headers.has('Content-Type') && options.body) {
        headers.set('Content-Type', 'application/json');
      }
      if (authToken) {
        headers.set('Authorization', `Bearer ${authToken}`);
      }
      const res = await fetch(url, { ...options, headers });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
      }
      return data as T;
    },
    [token]
  );

  const loadAllWorkspaceData = useCallback(
    async (activeToken: string) => {
      const [meRes, matchRes, asmtRes, rmRes, actRes, decRes, msgRes] = await Promise.all([
        apiFetch<{ user: AuthUser; profile: StudentProfile }>('/api/auth/me', {}, activeToken),
        apiFetch<{ matches: CareerMatchResult[] }>('/api/careers/matches', {}, activeToken),
        apiFetch<{ assessments: SkillAssessmentRecord[] }>('/api/assessments', {}, activeToken),
        apiFetch<{ roadmap: LearningRoadmap | null; history: LearningRoadmap[] }>(
          '/api/roadmaps/active',
          {},
          activeToken
        ),
        apiFetch<{ activities: LearningActivity[] }>('/api/activities', {}, activeToken),
        apiFetch<{ decisions: AgentDecisionRecord[] }>('/api/agent-decisions', {}, activeToken),
        apiFetch<{ messages: MentorMessage[] }>('/api/mentor/messages', {}, activeToken),
      ]);

      setUser(meRes.user);
      setProfile(meRes.profile);
      setMatches(matchRes.matches);
      setAssessments(asmtRes.assessments);
      setRoadmap(rmRes.roadmap);
      setRoadmapHistory(rmRes.history);
      setActivities(actRes.activities);
      setDecisions(decRes.decisions);
      setMentorMessages(msgRes.messages);
    },
    [apiFetch]
  );

  useEffect(() => {
    validateFirestoreConnection();
    fetch('/api/health')
      .then((r) => r.json())
      .then((d: { aiConfigured?: boolean }) => {
        if (typeof d.aiConfigured === 'boolean') setAiConfigured(d.aiConfigured);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    let active = true;
    async function hydrate() {
      if (!token) {
        if (active) {
          setLoadingAuth(false);
          if (!PUBLIC_PAGES.includes(resolveInitialPage())) {
            navigate('login');
          }
        }
        return;
      }
      try {
        await loadAllWorkspaceData(token);
      } catch {
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        if (active) {
          setToken(null);
          setUser(null);
          setProfile(null);
          if (!PUBLIC_PAGES.includes(resolveInitialPage())) {
            navigate('login');
          }
        }
      } finally {
        if (active) setLoadingAuth(false);
      }
    }
    hydrate();
    return () => {
      active = false;
    };
  }, [token, loadAllWorkspaceData, navigate]);

  const refreshWorkspace = useCallback(async () => {
    if (!token) return;
    await loadAllWorkspaceData(token);
  }, [token, loadAllWorkspaceData]);

  const register = useCallback(
    async (payload: {
      fullName: string;
      email: string;
      password: string;
      education: string;
      department: string;
      yearOfStudy: string;
      targetCareer: CareerId;
      initialSkills: SkillEntry[];
    }) => {
      setErrorMessage(null);
      setBusyAction('Creating your student account...');
      try {
        const res = await apiFetch<{ token: string; user: AuthUser; profile: StudentProfile }>(
          '/api/auth/register',
          {
            method: 'POST',
            body: JSON.stringify(payload),
          }
        );
        localStorage.setItem(TOKEN_STORAGE_KEY, res.token);
        setToken(res.token);
        setUser(res.user);
        setProfile(res.profile);
        await loadAllWorkspaceData(res.token);
        navigate('dashboard');
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Registration failed.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch, loadAllWorkspaceData, navigate]
  );

  const login = useCallback(
    async (email: string, password: string) => {
      setErrorMessage(null);
      setBusyAction('Signing in...');
      try {
        const res = await apiFetch<{ token: string; user: AuthUser; profile: StudentProfile }>(
          '/api/auth/login',
          {
            method: 'POST',
            body: JSON.stringify({ email, password }),
          }
        );
        localStorage.setItem(TOKEN_STORAGE_KEY, res.token);
        setToken(res.token);
        setUser(res.user);
        setProfile(res.profile);
        await loadAllWorkspaceData(res.token);
        navigate('dashboard');
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Login failed.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch, loadAllWorkspaceData, navigate]
  );

  const loginWithGoogle = useCallback(async () => {
    setErrorMessage(null);
    setBusyAction('Connecting with Google...');
    try {
      const cred = await signInWithPopup(auth, googleAuthProvider);
      const fbUser = cred.user;
      const res = await apiFetch<{ token: string; user: AuthUser; profile: StudentProfile }>(
        '/api/auth/google-sync',
        {
          method: 'POST',
          body: JSON.stringify({
            uid: fbUser.uid,
            email: fbUser.email,
            fullName: fbUser.displayName || fbUser.email?.split('@')[0] || 'Student',
          }),
        }
      );
      localStorage.setItem(TOKEN_STORAGE_KEY, res.token);
      setToken(res.token);
      setUser(res.user);
      setProfile(res.profile);
      void syncProfileToFirestore(res.profile).catch(() => {});
      await loadAllWorkspaceData(res.token);
      navigate('dashboard');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed.';
      setErrorMessage(msg);
      throw err;
    } finally {
      setBusyAction(null);
    }
  }, [apiFetch, loadAllWorkspaceData, navigate]);

  const logout = useCallback(async () => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    setToken(null);
    setUser(null);
    setProfile(null);
    setAssessments([]);
    setRoadmap(null);
    setRoadmapHistory([]);
    setMatches([]);
    setActivities([]);
    setDecisions([]);
    setMentorMessages([]);
    try {
      if (auth.currentUser) {
        await signOut(auth);
      }
    } catch {
      // Ignore signout error
    }
    navigate('landing');
  }, [navigate]);

  const updateProfile = useCallback(
    async (patch: Partial<StudentProfile>) => {
      setErrorMessage(null);
      setBusyAction('Saving student profile...');
      try {
        const res = await apiFetch<{ profile: StudentProfile; matches: CareerMatchResult[] }>(
          '/api/profile',
          {
            method: 'PUT',
            body: JSON.stringify(patch),
          }
        );
        setProfile(res.profile);
        setMatches(res.matches);
        void syncProfileToFirestore(res.profile).catch(() => {});
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to update profile.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch]
  );

  const generateAssessment = useCallback(
    async (skillName: string, careerContext?: CareerId) => {
      setErrorMessage(null);
      setBusyAction(`Generating diagnostic assessment for ${skillName}...`);
      try {
        return await apiFetch<{
          sessionId: string;
          skillName: string;
          careerContext: CareerId;
          questions: AssessmentQuestion[];
        }>('/api/assessments/generate', {
          method: 'POST',
          body: JSON.stringify({ skillName, careerContext }),
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Could not generate assessment.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch]
  );

  const submitAssessment = useCallback(
    async (sessionId: string, answers: Record<string, string>) => {
      setErrorMessage(null);
      setBusyAction('Evaluating answers & running Progress Evaluation Agent...');
      try {
        const res = await apiFetch<{
          record: SkillAssessmentRecord;
          profile: StudentProfile;
          roadmap: LearningRoadmap;
          decision: AgentDecisionRecord;
          adapted: boolean;
          matches: CareerMatchResult[];
        }>('/api/assessments/submit', {
          method: 'POST',
          body: JSON.stringify({ sessionId, answers }),
        });

        setProfile(res.profile);
        setAssessments((prev) => [res.record, ...prev]);
        setRoadmap(res.roadmap);
        setDecisions((prev) => [res.decision, ...prev]);
        setMatches(res.matches);
        const acts = await apiFetch<{ activities: LearningActivity[] }>('/api/activities');
        setActivities(acts.activities);

        void syncProfileToFirestore(res.profile).catch(() => {});
        void syncAssessmentToFirestore(res.record).catch(() => {});
        void syncRoadmapToFirestore(res.roadmap).catch(() => {});
        void syncDecisionToFirestore(res.decision).catch(() => {});

        return { record: res.record, adapted: res.adapted, decision: res.decision };
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to evaluate assessment.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch]
  );

  const runOrchestrator = useCallback(
    async (triggerEvent?: string) => {
      setErrorMessage(null);
      setBusyAction('Coordinating 5 AI Agents via Central Orchestrator...');
      try {
        const res = await apiFetch<{
          roadmap: LearningRoadmap;
          decision: AgentDecisionRecord;
          matches: CareerMatchResult[];
        }>('/api/orchestrator/run', {
          method: 'POST',
          body: JSON.stringify({ triggerEvent }),
        });
        setRoadmap(res.roadmap);
        setRoadmapHistory((prev) => [res.roadmap, ...prev.filter((r) => r.id !== res.roadmap.id)]);
        setDecisions((prev) => [res.decision, ...prev]);
        setMatches(res.matches);
        const acts = await apiFetch<{ activities: LearningActivity[] }>('/api/activities');
        setActivities(acts.activities);

        void syncRoadmapToFirestore(res.roadmap).catch(() => {});
        void syncDecisionToFirestore(res.decision).catch(() => {});
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'AI Orchestrator failed.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch]
  );

  const switchCareer = useCallback(
    async (targetCareer: CareerId) => {
      setErrorMessage(null);
      setBusyAction(`Recalculating skill gaps & rebuilding roadmap for ${targetCareer}...`);
      try {
        const res = await apiFetch<{
          profile: StudentProfile;
          roadmap: LearningRoadmap;
          decision: AgentDecisionRecord;
          matches: CareerMatchResult[];
        }>('/api/careers/switch', {
          method: 'POST',
          body: JSON.stringify({ targetCareer }),
        });
        setProfile(res.profile);
        setRoadmap(res.roadmap);
        setRoadmapHistory((prev) => [res.roadmap, ...prev.filter((r) => r.id !== res.roadmap.id)]);
        setDecisions((prev) => [res.decision, ...prev]);
        setMatches(res.matches);
        const acts = await apiFetch<{ activities: LearningActivity[] }>('/api/activities');
        setActivities(acts.activities);

        void syncProfileToFirestore(res.profile).catch(() => {});
        void syncRoadmapToFirestore(res.roadmap).catch(() => {});
        void syncDecisionToFirestore(res.decision).catch(() => {});
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to switch target career.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch]
  );

  const toggleRoadmapProgress = useCallback(
    async (payload: {
      moduleId: string;
      topicId?: string;
      toggleExercise?: boolean;
      toggleMiniProject?: boolean;
      moduleStatus?: 'pending' | 'in_progress' | 'completed';
    }) => {
      if (!roadmap) return;
      setErrorMessage(null);
      try {
        const res = await apiFetch<{ roadmap: LearningRoadmap; activities: LearningActivity[] }>(
          `/api/roadmaps/${roadmap.id}/progress`,
          {
            method: 'PATCH',
            body: JSON.stringify(payload),
          }
        );
        setRoadmap(res.roadmap);
        setActivities(res.activities);
        void syncRoadmapToFirestore(res.roadmap).catch(() => {});
        if (res.activities[0]) {
          void syncActivityToFirestore(res.activities[0]).catch(() => {});
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to update progress.';
        setErrorMessage(msg);
        throw err;
      }
    },
    [apiFetch, roadmap]
  );

  const requestExerciseFeedback = useCallback(
    async (payload: { moduleTitle: string; exercisePrompt: string; solution: string }) => {
      if (!roadmap) throw new Error('No active roadmap.');
      setErrorMessage(null);
      setBusyAction('Analyzing practice submission...');
      try {
        const res = await apiFetch<{ feedback: string }>(
          `/api/roadmaps/${roadmap.id}/exercise-feedback`,
          {
            method: 'POST',
            body: JSON.stringify(payload),
          }
        );
        const acts = await apiFetch<{ activities: LearningActivity[] }>('/api/activities');
        setActivities(acts.activities);
        return res.feedback;
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to evaluate exercise.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch, roadmap]
  );

  const logActivity = useCallback(
    async (payload: {
      type: LearningActivity['type'];
      title: string;
      skillName: string;
      status?: LearningActivity['status'];
    }) => {
      setErrorMessage(null);
      try {
        const res = await apiFetch<{ activity: LearningActivity; activities: LearningActivity[] }>(
          '/api/activities',
          {
            method: 'POST',
            body: JSON.stringify(payload),
          }
        );
        setActivities(res.activities);
        void syncActivityToFirestore(res.activity).catch(() => {});
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to log activity.';
        setErrorMessage(msg);
        throw err;
      }
    },
    [apiFetch]
  );

  const sendMentorMessage = useCallback(
    async (message: string) => {
      setErrorMessage(null);
      setBusyAction('AI Mentor is analyzing your profile & roadmap...');
      try {
        const res = await apiFetch<{
          userMessage: MentorMessage;
          assistantMessage: MentorMessage;
          messages: MentorMessage[];
        }>('/api/mentor/chat', {
          method: 'POST',
          body: JSON.stringify({ message }),
        });
        setMentorMessages(res.messages);
        void syncMentorMessageToFirestore(res.userMessage).catch(() => {});
        void syncMentorMessageToFirestore(res.assistantMessage).catch(() => {});
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'AI Mentor is currently unavailable.';
        setErrorMessage(msg);
        throw err;
      } finally {
        setBusyAction(null);
      }
    },
    [apiFetch]
  );

  const clearMentorChat = useCallback(async () => {
    await apiFetch('/api/mentor/messages', { method: 'DELETE' });
    setMentorMessages([]);
  }, [apiFetch]);

  return (
    <SkilloraContext.Provider
      value={{
        page,
        navigate,
        loadingAuth,
        busyAction,
        errorMessage,
        clearError,
        user,
        profile,
        assessments,
        roadmap,
        roadmapHistory,
        matches,
        activities,
        decisions,
        mentorMessages,
        aiConfigured,
        register,
        login,
        loginWithGoogle,
        logout,
        refreshWorkspace,
        updateProfile,
        generateAssessment,
        submitAssessment,
        runOrchestrator,
        switchCareer,
        toggleRoadmapProgress,
        requestExerciseFeedback,
        logActivity,
        sendMentorMessage,
        clearMentorChat,
      }}
    >
      {children}
    </SkilloraContext.Provider>
  );
}

export function useSkillora() {
  const ctx = useContext(SkilloraContext);
  if (!ctx) throw new Error('useSkillora must be used inside SkilloraProvider');
  return ctx;
}
