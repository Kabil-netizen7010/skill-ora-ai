import {
  doc,
  getDoc,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { auth, db } from './firebase.ts';
import type {
  AgentDecisionRecord,
  LearningActivity,
  LearningRoadmap,
  MentorMessage,
  SkillAssessmentRecord,
  StudentProfile,
} from '../types/skillora.ts';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

function isFirebaseUserMatching(uid: string): boolean {
  return Boolean(auth.currentUser && auth.currentUser.uid === uid && auth.currentUser.emailVerified);
}

export async function syncProfileToFirestore(profile: StudentProfile): Promise<void> {
  if (!isFirebaseUserMatching(profile.uid)) return;
  const path = `users/${profile.uid}`;
  const ref = doc(db, 'users', profile.uid);
  try {
    const snap = await getDoc(ref);
    const payload = {
      uid: profile.uid,
      email: profile.email.slice(0, 200),
      fullName: profile.fullName.slice(0, 120),
      education: (profile.education || '').slice(0, 160),
      department: (profile.department || '').slice(0, 120),
      yearOfStudy: (profile.yearOfStudy || '').slice(0, 60),
      targetCareer: profile.targetCareer,
      careerInterests: profile.careerInterests.slice(0, 12),
      learningPreferences: profile.learningPreferences,
      skills: profile.skills.slice(0, 60),
      certifications: profile.certifications.slice(0, 30),
      projects: profile.projects.slice(0, 30),
    };
    if (!snap.exists()) {
      await setDoc(ref, {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        ...payload,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncAssessmentToFirestore(record: SkillAssessmentRecord): Promise<void> {
  if (!isFirebaseUserMatching(record.uid)) return;
  const path = `users/${record.uid}/assessments/${record.id}`;
  try {
    await setDoc(doc(db, 'users', record.uid, 'assessments', record.id), {
      id: record.id,
      uid: record.uid,
      skillName: record.skillName.slice(0, 100),
      careerContext: record.careerContext.slice(0, 100),
      score: record.score,
      passed: record.passed,
      verifiedLevel: record.verifiedLevel,
      explanation: record.explanation.slice(0, 4000),
      strengths: record.strengths.slice(0, 20),
      weaknesses: record.weaknesses.slice(0, 20),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function syncRoadmapToFirestore(roadmap: LearningRoadmap): Promise<void> {
  if (!isFirebaseUserMatching(roadmap.uid)) return;
  const path = `users/${roadmap.uid}/roadmaps/${roadmap.id}`;
  const ref = doc(db, 'users', roadmap.uid, 'roadmaps', roadmap.id);
  try {
    const snap = await getDoc(ref);
    const payload = {
      id: roadmap.id,
      uid: roadmap.uid,
      targetCareer: roadmap.targetCareer,
      summary: (roadmap.summary || '').slice(0, 4000),
      adaptationReason: (roadmap.adaptationReason || '').slice(0, 2000),
      modules: roadmap.modules.slice(0, 25),
    };
    if (!snap.exists()) {
      await setDoc(ref, {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        ...payload,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncActivityToFirestore(activity: LearningActivity): Promise<void> {
  if (!isFirebaseUserMatching(activity.uid)) return;
  const path = `users/${activity.uid}/activities/${activity.id}`;
  const ref = doc(db, 'users', activity.uid, 'activities', activity.id);
  try {
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        id: activity.id,
        uid: activity.uid,
        type: activity.type.slice(0, 60),
        title: activity.title.slice(0, 200),
        skillName: (activity.skillName || '').slice(0, 100),
        status: activity.status,
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function syncDecisionToFirestore(decision: AgentDecisionRecord): Promise<void> {
  if (!isFirebaseUserMatching(decision.uid)) return;
  const path = `users/${decision.uid}/agentDecisions/${decision.id}`;
  try {
    await setDoc(doc(db, 'users', decision.uid, 'agentDecisions', decision.id), {
      id: decision.id,
      uid: decision.uid,
      triggerEvent: decision.triggerEvent.slice(0, 160),
      orchestratorSummary: decision.orchestratorSummary.slice(0, 3000),
      agentTrace: decision.agentTrace.slice(0, 10),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function syncMentorMessageToFirestore(message: MentorMessage): Promise<void> {
  if (!isFirebaseUserMatching(message.uid)) return;
  const path = `users/${message.uid}/mentorMessages/${message.id}`;
  try {
    await setDoc(doc(db, 'users', message.uid, 'mentorMessages', message.id), {
      id: message.id,
      uid: message.uid,
      role: message.role,
      content: message.content.slice(0, 12000),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}
