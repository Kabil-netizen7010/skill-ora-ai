/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { WorkspaceLayout } from './components/WorkspaceLayout.tsx';
import { SkilloraProvider, useSkillora } from './context/SkilloraContext.tsx';
import { AssessmentsPage } from './pages/AssessmentsPage.tsx';
import { LoginPage, RegisterPage } from './pages/AuthPages.tsx';
import { CareerExplorerPage, CareerMatchingPage } from './pages/CareerPages.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { MentorPage } from './pages/MentorPage.tsx';
import { ProfilePage } from './pages/ProfilePage.tsx';
import { ProgressPage } from './pages/ProgressPage.tsx';
import { ResourcesPage } from './pages/ResourcesPage.tsx';
import { RoadmapPage } from './pages/RoadmapPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';
import { SkillAnalysisPage } from './pages/SkillAnalysisPage.tsx';

function AppRouter() {
  const { page, loadingAuth, user } = useSkillora();

  if (loadingAuth) {
    return (
      <div className="min-h-screen bg-[#070B14] text-slate-200 flex items-center justify-center">
        <div className="text-center space-y-2">
          <p className="text-lg font-semibold text-white">Skillora - AI</p>
          <p className="text-xs text-slate-400">Loading your personalized workspace...</p>
        </div>
      </div>
    );
  }

  if (page === 'landing') return <LandingPage />;
  if (page === 'register') return <RegisterPage />;
  if (page === 'login') return <LoginPage />;

  if (!user) {
    return <LoginPage />;
  }

  return (
    <WorkspaceLayout>
      {page === 'dashboard' && <DashboardPage />}
      {page === 'profile' && <ProfilePage />}
      {page === 'assessments' && <AssessmentsPage />}
      {page === 'skill-analysis' && <SkillAnalysisPage />}
      {page === 'careers' && <CareerExplorerPage />}
      {page === 'career-matching' && <CareerMatchingPage />}
      {page === 'roadmap' && <RoadmapPage />}
      {page === 'resources' && <ResourcesPage />}
      {page === 'progress' && <ProgressPage />}
      {page === 'mentor' && <MentorPage />}
      {page === 'settings' && <SettingsPage />}
    </WorkspaceLayout>
  );
}

export default function App() {
  return (
    <SkilloraProvider>
      <AppRouter />
    </SkilloraProvider>
  );
}
