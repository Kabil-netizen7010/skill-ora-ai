export type CareerId =
  | 'AI Engineer'
  | 'Machine Learning Engineer'
  | 'Data Scientist'
  | 'Full Stack Developer'
  | 'Software Developer'
  | 'Cybersecurity Analyst';

export type ProficiencyLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';

export interface SkillEntry {
  name: string;
  category: 'Technical' | 'Non-Technical';
  selfReportedLevel: ProficiencyLevel;
  verifiedLevel?: ProficiencyLevel;
  verifiedScore?: number;
  lastAssessedAt?: string;
  evidence?: string;
}

export interface CertificationEntry {
  id: string;
  title: string;
  issuer: string;
  year: string;
}

export interface ProjectEntry {
  id: string;
  title: string;
  summary: string;
  skillsUsed: string[];
  link?: string;
  validated?: boolean;
}

export interface LearningPreferences {
  pace: 'Self-paced' | 'Structured Weekly' | 'Intensive';
  style: 'Hands-on Projects' | 'Conceptual + Theory' | 'Balanced';
  weeklyHours: number;
}

export interface StudentProfile {
  uid: string;
  email: string;
  fullName: string;
  education: string;
  department: string;
  yearOfStudy: string;
  targetCareer: CareerId;
  careerInterests: string[];
  learningPreferences: LearningPreferences;
  skills: SkillEntry[];
  certifications: CertificationEntry[];
  projects: ProjectEntry[];
  createdAt: string;
  updatedAt: string;
}

export interface CareerSkillRequirement {
  name: string;
  minLevel: ProficiencyLevel;
  weight: number;
  prerequisites: string[];
}

export interface CareerDefinition {
  career: CareerId;
  summary: string;
  image: string;
  averageRampWeeks: number;
  coreSkills: CareerSkillRequirement[];
  optionalSkills: string[];
  dayToDayFocus: string[];
}

export interface CareerMatchSkillItem {
  name: string;
  studentLevel: string;
  requiredLevel: string;
  verified: boolean;
  score?: number;
}

export interface CareerPartialSkillItem {
  name: string;
  studentLevel: string;
  requiredLevel: string;
  gapDetail: string;
}

export interface CareerMissingSkillItem {
  name: string;
  requiredLevel: string;
  weight: number;
  prerequisites: string[];
}

export interface CareerMatchResult {
  career: CareerId;
  compatibilityScore: number;
  verifiedCoveragePct: number;
  transparencyNote: string;
  matchingSkills: CareerMatchSkillItem[];
  partialSkills: CareerPartialSkillItem[];
  missingSkills: CareerMissingSkillItem[];
  recommendedImprovements: string[];
}

export interface AssessmentQuestion {
  id: string;
  prompt: string;
  type: 'mcq' | 'practical';
  options?: string[];
  starterCode?: string;
  conceptTested: string;
}

export interface AssessmentSubmissionQuestionResult {
  questionId: string;
  prompt: string;
  userAnswer: string;
  isCorrect: boolean;
  feedback: string;
}

export interface SkillAssessmentRecord {
  id: string;
  uid: string;
  skillName: string;
  careerContext: string;
  score: number;
  passed: boolean;
  verifiedLevel: ProficiencyLevel;
  explanation: string;
  strengths: string[];
  weaknesses: string[];
  questionResults: AssessmentSubmissionQuestionResult[];
  createdAt: string;
}

export interface RoadmapTopic {
  id: string;
  title: string;
  subtopics: string[];
  completed: boolean;
}

export interface RoadmapResource {
  title: string;
  type: 'Documentation' | 'Course' | 'Interactive' | 'Paper';
  url: string;
  duration: string;
}

export interface RoadmapModule {
  id: string;
  order: number;
  title: string;
  skillFocus: string;
  prerequisites: string[];
  objectives: string[];
  topics: RoadmapTopic[];
  resources: RoadmapResource[];
  practiceExercise: {
    title: string;
    prompt: string;
    completed: boolean;
  };
  miniProject: {
    title: string;
    deliverables: string[];
    completed: boolean;
  };
  assessmentRequired: boolean;
  status: 'pending' | 'in_progress' | 'completed';
  adaptiveNote?: string;
}

export interface LearningRoadmap {
  id: string;
  uid: string;
  targetCareer: CareerId;
  summary: string;
  adaptationReason: string;
  modules: RoadmapModule[];
  createdAt: string;
  updatedAt: string;
}

export interface AgentTraceStep {
  agentName:
    | 'Skill Analyzer'
    | 'Career Matching Agent'
    | 'Learning Recommendation Agent'
    | 'Progress Evaluation Agent'
    | 'AI Mentor Agent'
    | 'Central AI Orchestrator';
  role: string;
  inputSummary: string;
  decisionSummary: string;
  structuredOutput: Record<string, unknown>;
  timestamp: string;
}

export interface AgentDecisionRecord {
  id: string;
  uid: string;
  triggerEvent: string;
  orchestratorSummary: string;
  agentTrace: AgentTraceStep[];
  createdAt: string;
}

export interface LearningActivity {
  id: string;
  uid: string;
  type: 'lesson' | 'assessment' | 'project' | 'exercise' | 'roadmap_adaptation' | 'career_switch';
  title: string;
  skillName: string;
  status: 'pending' | 'in_progress' | 'completed';
  createdAt: string;
}

export interface MentorMessage {
  id: string;
  uid: string;
  role: 'user' | 'assistant';
  content: string;
  reasoningNote?: string;
  createdAt: string;
}

export interface CuratedResource {
  id: string;
  title: string;
  provider: string;
  type: 'Documentation' | 'Course' | 'Interactive' | 'Paper';
  skillName: string;
  careers: CareerId[];
  level: ProficiencyLevel;
  duration: string;
  url: string;
  description: string;
}
