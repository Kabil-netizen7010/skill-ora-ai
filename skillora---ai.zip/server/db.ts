import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type {
  AgentDecisionRecord,
  LearningActivity,
  LearningRoadmap,
  MentorMessage,
  SkillAssessmentRecord,
  StudentProfile,
} from '../src/types/skillora.ts';

const dbPath = path.resolve(process.cwd(), 'skillora.db');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    uid TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT,
    full_name TEXT NOT NULL,
    auth_provider TEXT NOT NULL DEFAULT 'email',
    reset_token TEXT,
    reset_expires INTEGER,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS profiles (
    uid TEXT PRIMARY KEY REFERENCES users(uid) ON DELETE CASCADE,
    data_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS assessments (
    id TEXT PRIMARY KEY,
    uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
    skill_name TEXT NOT NULL,
    score INTEGER NOT NULL,
    passed INTEGER NOT NULL,
    data_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS roadmaps (
    id TEXT PRIMARY KEY,
    uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
    target_career TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    data_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS activities (
    id TEXT PRIMARY KEY,
    uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    skill_name TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS agent_decisions (
    id TEXT PRIMARY KEY,
    uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
    trigger_event TEXT NOT NULL,
    data_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS mentor_messages (
    id TEXT PRIMARY KEY,
    uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    reasoning_note TEXT,
    created_at TEXT NOT NULL
  );
`);

function getSessionSecret(): string {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16) {
    return process.env.SESSION_SECRET;
  }
  const secretFile = path.resolve(process.cwd(), '.skillora-session-secret');
  if (fs.existsSync(secretFile)) {
    return fs.readFileSync(secretFile, 'utf8').trim();
  }
  const generated = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(secretFile, generated, 'utf8');
  return generated;
}

const SESSION_SECRET = getSessionSecret();

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, originalHex] = parts;
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  const originalBuf = Buffer.from(originalHex, 'hex');
  if (derivedBuf.length !== originalBuf.length) return false;
  return crypto.timingSafeEqual(derivedBuf, originalBuf);
}

export interface SessionPayload {
  uid: string;
  email: string;
  exp: number;
}

export function signSessionToken(uid: string, email: string): string {
  const payload: SessionPayload = {
    uid,
    email,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
    if (!parsed.uid || !parsed.exp || parsed.exp < Date.now()) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export interface UserRow {
  uid: string;
  email: string;
  password_hash: string | null;
  full_name: string;
  auth_provider: string;
  reset_token: string | null;
  reset_expires: number | null;
  created_at: string;
}

export function findUserByEmail(email: string): UserRow | undefined {
  return db.prepare('SELECT * FROM users WHERE lower(email) = lower(?)').get(email.trim()) as UserRow | undefined;
}

export function findUserByUid(uid: string): UserRow | undefined {
  return db.prepare('SELECT * FROM users WHERE uid = ?').get(uid) as UserRow | undefined;
}

export function createUserAccount(params: {
  uid: string;
  email: string;
  passwordHash: string | null;
  fullName: string;
  authProvider: 'email' | 'google';
}): UserRow {
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO users (uid, email, password_hash, full_name, auth_provider, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(params.uid, params.email.trim().toLowerCase(), params.passwordHash, params.fullName.trim(), params.authProvider, now);
  return findUserByUid(params.uid)!;
}

export function setPasswordResetToken(email: string): string | null {
  const user = findUserByEmail(email);
  if (!user) return null;
  const code = crypto.randomInt(100000, 999999).toString();
  const expires = Date.now() + 1000 * 60 * 20;
  db.prepare('UPDATE users SET reset_token = ?, reset_expires = ? WHERE uid = ?').run(code, expires, user.uid);
  return code;
}

export function resetUserPassword(email: string, code: string, newPassword: string): boolean {
  const user = findUserByEmail(email);
  if (!user || !user.reset_token || !user.reset_expires) return false;
  if (user.reset_token !== code.trim() || user.reset_expires < Date.now()) return false;
  const hash = hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE uid = ?').run(
    hash,
    user.uid
  );
  return true;
}

export function updateUserPassword(uid: string, newPassword: string): void {
  const hash = hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ? WHERE uid = ?').run(hash, uid);
}

export function saveProfile(profile: StudentProfile): StudentProfile {
  const updated = { ...profile, updatedAt: new Date().toISOString() };
  db.prepare(
    `INSERT INTO profiles (uid, data_json, updated_at)
     VALUES (?, ?, ?)
     ON CONFLICT(uid) DO UPDATE SET data_json = excluded.data_json, updated_at = excluded.updated_at`
  ).run(updated.uid, JSON.stringify(updated), updated.updatedAt);
  db.prepare('UPDATE users SET full_name = ? WHERE uid = ?').run(updated.fullName, updated.uid);
  return updated;
}

export function getProfile(uid: string): StudentProfile | null {
  const row = db.prepare('SELECT data_json FROM profiles WHERE uid = ?').get(uid) as { data_json: string } | undefined;
  if (!row) return null;
  return JSON.parse(row.data_json) as StudentProfile;
}

export function insertAssessment(record: SkillAssessmentRecord): void {
  db.prepare(
    `INSERT INTO assessments (id, uid, skill_name, score, passed, data_json, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    record.id,
    record.uid,
    record.skillName,
    record.score,
    record.passed ? 1 : 0,
    JSON.stringify(record),
    record.createdAt
  );
}

export function listAssessments(uid: string): SkillAssessmentRecord[] {
  const rows = db
    .prepare('SELECT data_json FROM assessments WHERE uid = ? ORDER BY created_at DESC')
    .all(uid) as { data_json: string }[];
  return rows.map((r) => JSON.parse(r.data_json) as SkillAssessmentRecord);
}

export function saveRoadmap(roadmap: LearningRoadmap, setActive = true): LearningRoadmap {
  if (setActive) {
    db.prepare('UPDATE roadmaps SET is_active = 0 WHERE uid = ?').run(roadmap.uid);
  }
  db.prepare(
    `INSERT INTO roadmaps (id, uid, target_career, is_active, data_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET
       target_career = excluded.target_career,
       is_active = excluded.is_active,
       data_json = excluded.data_json,
       updated_at = excluded.updated_at`
  ).run(
    roadmap.id,
    roadmap.uid,
    roadmap.targetCareer,
    setActive ? 1 : 0,
    JSON.stringify(roadmap),
    roadmap.createdAt,
    roadmap.updatedAt
  );
  return roadmap;
}

export function getActiveRoadmap(uid: string): LearningRoadmap | null {
  const row = db
    .prepare('SELECT data_json FROM roadmaps WHERE uid = ? AND is_active = 1 ORDER BY updated_at DESC LIMIT 1')
    .get(uid) as { data_json: string } | undefined;
  if (!row) return null;
  return JSON.parse(row.data_json) as LearningRoadmap;
}

export function listRoadmaps(uid: string): LearningRoadmap[] {
  const rows = db
    .prepare('SELECT data_json FROM roadmaps WHERE uid = ? ORDER BY updated_at DESC')
    .all(uid) as { data_json: string }[];
  return rows.map((r) => JSON.parse(r.data_json) as LearningRoadmap);
}

export function addActivity(activity: LearningActivity): void {
  db.prepare(
    `INSERT INTO activities (id, uid, type, title, skill_name, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET status = excluded.status, title = excluded.title`
  ).run(
    activity.id,
    activity.uid,
    activity.type,
    activity.title,
    activity.skillName,
    activity.status,
    activity.createdAt
  );
}

export function listActivities(uid: string): LearningActivity[] {
  return db
    .prepare('SELECT id, uid, type, title, skill_name as skillName, status, created_at as createdAt FROM activities WHERE uid = ? ORDER BY created_at DESC LIMIT 100')
    .all(uid) as LearningActivity[];
}

export function saveAgentDecision(decision: AgentDecisionRecord): void {
  db.prepare(
    `INSERT INTO agent_decisions (id, uid, trigger_event, data_json, created_at)
     VALUES (?, ?, ?, ?, ?)`
  ).run(decision.id, decision.uid, decision.triggerEvent, JSON.stringify(decision), decision.createdAt);
}

export function listAgentDecisions(uid: string): AgentDecisionRecord[] {
  const rows = db
    .prepare('SELECT data_json FROM agent_decisions WHERE uid = ? ORDER BY created_at DESC LIMIT 30')
    .all(uid) as { data_json: string }[];
  return rows.map((r) => JSON.parse(r.data_json) as AgentDecisionRecord);
}

export function addMentorMessage(msg: MentorMessage): void {
  db.prepare(
    `INSERT INTO mentor_messages (id, uid, role, content, reasoning_note, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(msg.id, msg.uid, msg.role, msg.content, msg.reasoningNote || null, msg.createdAt);
}

export function listMentorMessages(uid: string): MentorMessage[] {
  return db
    .prepare('SELECT id, uid, role, content, reasoning_note as reasoningNote, created_at as createdAt FROM mentor_messages WHERE uid = ? ORDER BY created_at ASC LIMIT 80')
    .all(uid) as MentorMessage[];
}

export function clearMentorMessages(uid: string): void {
  db.prepare('DELETE FROM mentor_messages WHERE uid = ?').run(uid);
}
