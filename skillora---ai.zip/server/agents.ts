import crypto from 'node:crypto';
import {
  ALL_CAREERS,
  CAREER_CATALOG,
  CURATED_RESOURCE_LIBRARY,
  PROFICIENCY_SCORE_MAP,
} from '../src/data/careerCatalog.ts';
import type {
  AgentDecisionRecord,
  AgentTraceStep,
  AssessmentQuestion,
  CareerId,
  CareerMatchResult,
  LearningActivity,
  LearningRoadmap,
  MentorMessage,
  ProficiencyLevel,
  RoadmapModule,
  SkillAssessmentRecord,
  StudentProfile,
} from '../src/types/skillora.ts';
import {
  generateStructuredJson,
  generateTextResponse,
  Type,
} from './gemini.ts';

function levelValue(level?: ProficiencyLevel): number {
  if (!level) return 0;
  return PROFICIENCY_SCORE_MAP[level] ?? 1;
}

export function computeCareerMatch(
  profile: StudentProfile,
  assessments: SkillAssessmentRecord[],
  careerId: CareerId
): CareerMatchResult {
  const def = CAREER_CATALOG[careerId];
  const latestAssessments = new Map<string, SkillAssessmentRecord>();
  for (const a of assessments) {
    const key = a.skillName.toLowerCase();
    if (!latestAssessments.has(key)) {
      latestAssessments.set(key, a);
    }
  }

  let totalWeight = 0;
  let earnedWeight = 0;
  let verifiedWeight = 0;

  const matchingSkills: CareerMatchResult['matchingSkills'] = [];
  const partialSkills: CareerMatchResult['partialSkills'] = [];
  const missingSkills: CareerMatchResult['missingSkills'] = [];
  const recommendedImprovements: string[] = [];

  for (const reqSkill of def.coreSkills) {
    totalWeight += reqSkill.weight;
    const reqVal = levelValue(reqSkill.minLevel);

    const profileSkill = profile.skills.find(
      (s) => s.name.toLowerCase() === reqSkill.name.toLowerCase()
    );
    const assessment = latestAssessments.get(reqSkill.name.toLowerCase());

    const effectiveLevel = profileSkill?.verifiedLevel || profileSkill?.selfReportedLevel;
    const isVerified = Boolean(profileSkill?.verifiedLevel || assessment);
    const confidenceFactor = isVerified ? 1.0 : 0.72;

    if (!effectiveLevel) {
      missingSkills.push({
        name: reqSkill.name,
        requiredLevel: reqSkill.minLevel,
        weight: reqSkill.weight,
        prerequisites: reqSkill.prerequisites,
      });
      recommendedImprovements.push(
        `Learn ${reqSkill.name} to ${reqSkill.minLevel} level${reqSkill.prerequisites.length ? ` (after ${reqSkill.prerequisites.join(', ')})` : ''}.`
      );
      continue;
    }

    const studentVal = levelValue(effectiveLevel);
    if (studentVal >= reqVal) {
      earnedWeight += reqSkill.weight * confidenceFactor;
      if (isVerified) verifiedWeight += reqSkill.weight;
      matchingSkills.push({
        name: reqSkill.name,
        studentLevel: effectiveLevel,
        requiredLevel: reqSkill.minLevel,
        verified: isVerified,
        score: assessment?.score ?? profileSkill?.verifiedScore,
      });
      if (!isVerified) {
        recommendedImprovements.push(
          `Complete a diagnostic assessment in ${reqSkill.name} to verify your self-reported ${effectiveLevel} rating.`
        );
      }
    } else {
      const ratio = studentVal / reqVal;
      earnedWeight += reqSkill.weight * ratio * confidenceFactor;
      if (isVerified) verifiedWeight += reqSkill.weight * ratio;
      partialSkills.push({
        name: reqSkill.name,
        studentLevel: effectiveLevel,
        requiredLevel: reqSkill.minLevel,
        gapDetail: `Currently ${effectiveLevel}${isVerified ? ' (verified)' : ' (self-reported)'}; target role expects ${reqSkill.minLevel}.`,
      });
      recommendedImprovements.push(
        `Advance ${reqSkill.name} from ${effectiveLevel} to ${reqSkill.minLevel}.`
      );
    }
  }

  const compatibilityScore = Math.round((earnedWeight / Math.max(totalWeight, 1)) * 100);
  const verifiedCoveragePct = Math.round((verifiedWeight / Math.max(totalWeight, 1)) * 100);

  return {
    career: careerId,
    compatibilityScore,
    verifiedCoveragePct,
    transparencyNote:
      'Transparent estimate weighted by core skill requirements (verified assessments count 100%, unverified self-reports count 72%). Not an employment guarantee.',
    matchingSkills,
    partialSkills,
    missingSkills,
    recommendedImprovements,
  };
}

export function computeAllCareerMatches(
  profile: StudentProfile,
  assessments: SkillAssessmentRecord[]
): CareerMatchResult[] {
  return ALL_CAREERS.map((career) => computeCareerMatch(profile, assessments, career)).sort(
    (a, b) => b.compatibilityScore - a.compatibilityScore
  );
}

function sortModulesByPrerequisites(modules: RoadmapModule[]): RoadmapModule[] {
  const remaining = [...modules];
  const ordered: RoadmapModule[] = [];
  const satisfied = new Set<string>();

  while (remaining.length > 0) {
    let pickedIdx = remaining.findIndex((mod) =>
      mod.prerequisites.every((p) => {
        const lower = p.toLowerCase();
        const isInRemaining = remaining.some((r) => r.skillFocus.toLowerCase() === lower);
        return !isInRemaining || satisfied.has(lower);
      })
    );
    if (pickedIdx === -1) {
      pickedIdx = 0;
    }
    const [picked] = remaining.splice(pickedIdx, 1);
    satisfied.add(picked.skillFocus.toLowerCase());
    ordered.push({ ...picked, order: ordered.length + 1 });
  }
  return ordered;
}

// ============================================================================
// AGENT 1: SKILL ANALYZER
// ============================================================================
interface SkillAnalyzerOutput {
  verifiedStrengths: string[];
  selfReportedUnverified: string[];
  weaknessesAndGaps: string[];
  evidenceSummary: string;
  priorityFocusOrder: string[];
}

async function runSkillAnalyzerAgent(
  profile: StudentProfile,
  assessments: SkillAssessmentRecord[]
): Promise<{ output: SkillAnalyzerOutput; trace: AgentTraceStep }> {
  const systemInstruction = `You are AGENT 1: SKILL ANALYZER inside Skillora - AI.
Analyze the student's profile, self-reported skills, assessment results, certifications, and projects.
Strictly distinguish between self-reported skills and assessment-verified skills.
Provide concise, evidence-backed observations with zero fabricated metrics.`;

  const prompt = JSON.stringify({
    student: {
      name: profile.fullName,
      education: profile.education,
      department: profile.department,
      yearOfStudy: profile.yearOfStudy,
      targetCareer: profile.targetCareer,
    },
    skills: profile.skills,
    certifications: profile.certifications,
    projects: profile.projects,
    assessments: assessments.slice(0, 12).map((a) => ({
      skillName: a.skillName,
      score: a.score,
      passed: a.passed,
      verifiedLevel: a.verifiedLevel,
      strengths: a.strengths,
      weaknesses: a.weaknesses,
    })),
  });

  const output = await generateStructuredJson<SkillAnalyzerOutput>({
    systemInstruction,
    prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        verifiedStrengths: { type: Type.ARRAY, items: { type: Type.STRING } },
        selfReportedUnverified: { type: Type.ARRAY, items: { type: Type.STRING } },
        weaknessesAndGaps: { type: Type.ARRAY, items: { type: Type.STRING } },
        evidenceSummary: { type: Type.STRING },
        priorityFocusOrder: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: [
        'verifiedStrengths',
        'selfReportedUnverified',
        'weaknessesAndGaps',
        'evidenceSummary',
        'priorityFocusOrder',
      ],
    },
  });

  return {
    output,
    trace: {
      agentName: 'Skill Analyzer',
      role: 'Evaluates profile evidence, assessment scores, and self-reported vs verified discrepancies.',
      inputSummary: `${profile.skills.length} skills, ${assessments.length} assessments, ${profile.projects.length} projects`,
      decisionSummary: output.evidenceSummary,
      structuredOutput: output as unknown as Record<string, unknown>,
      timestamp: new Date().toISOString(),
    },
  };
}

// ============================================================================
// AGENT 2: CAREER MATCHING AGENT
// ============================================================================
interface CareerMatchingAgentOutput {
  readinessInterpretation: string;
  criticalMissingCompetencies: string[];
  quickWinSkills: string[];
  alternativeBestFitCareer: string;
}

async function runCareerMatchingAgent(
  profile: StudentProfile,
  skillAnalysis: SkillAnalyzerOutput,
  targetMatch: CareerMatchResult,
  allMatches: CareerMatchResult[]
): Promise<{ output: CareerMatchingAgentOutput; trace: AgentTraceStep }> {
  const systemInstruction = `You are AGENT 2: CAREER MATCHING AGENT inside Skillora - AI.
Take Agent 1's skill analysis and the transparent compatibility scores for the target career and peer careers.
Explain the compatibility estimate honestly (never promise employment), pinpoint critical missing competencies, and identify quick wins.`;

  const prompt = JSON.stringify({
    targetCareer: profile.targetCareer,
    targetMatch,
    topMatches: allMatches.slice(0, 3).map((m) => ({
      career: m.career,
      compatibilityScore: m.compatibilityScore,
      missingCount: m.missingSkills.length,
    })),
    agent1Analysis: skillAnalysis,
  });

  const output = await generateStructuredJson<CareerMatchingAgentOutput>({
    systemInstruction,
    prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        readinessInterpretation: { type: Type.STRING },
        criticalMissingCompetencies: { type: Type.ARRAY, items: { type: Type.STRING } },
        quickWinSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
        alternativeBestFitCareer: { type: Type.STRING },
      },
      required: [
        'readinessInterpretation',
        'criticalMissingCompetencies',
        'quickWinSkills',
        'alternativeBestFitCareer',
      ],
    },
  });

  return {
    output,
    trace: {
      agentName: 'Career Matching Agent',
      role: 'Maps verified and self-reported skills against target career competency weights.',
      inputSummary: `Target: ${profile.targetCareer} (${targetMatch.compatibilityScore}% compatibility)`,
      decisionSummary: output.readinessInterpretation,
      structuredOutput: output as unknown as Record<string, unknown>,
      timestamp: new Date().toISOString(),
    },
  };
}

// ============================================================================
// AGENT 3: LEARNING RECOMMENDATION AGENT
// ============================================================================
interface GeneratedModuleRaw {
  title: string;
  skillFocus: string;
  prerequisites: string[];
  objectives: string[];
  topics: { title: string; subtopics: string[] }[];
  practiceExerciseTitle: string;
  practiceExercisePrompt: string;
  miniProjectTitle: string;
  miniProjectDeliverables: string[];
  assessmentRequired: boolean;
}

interface RecommendationAgentOutput {
  roadmapSummary: string;
  modules: GeneratedModuleRaw[];
}

async function runLearningRecommendationAgent(
  profile: StudentProfile,
  skillAnalysis: SkillAnalyzerOutput,
  careerMatchAnalysis: CareerMatchingAgentOutput,
  targetMatch: CareerMatchResult,
  remedialDirective?: string
): Promise<{ modules: RoadmapModule[]; summary: string; trace: AgentTraceStep }> {
  const careerDef = CAREER_CATALOG[profile.targetCareer];
  const systemInstruction = `You are AGENT 3: LEARNING RECOMMENDATION AGENT inside Skillora - AI.
Design a prerequisite-safe, personalized learning roadmap of 4 to 6 modules tailored to the learner's gaps, target career, and preferences.
CRITICAL PREREQUISITE RULE: Never schedule an advanced topic before its prerequisites (e.g. HTML & CSS before JavaScript; JavaScript before React or Node.js; Python & Math before Machine Learning / PyTorch; Networking before Web Security / Threat Detection).
Do not include skills the learner has already verified at or above the required level unless remedial reinforcement is requested.`;

  const prompt = JSON.stringify({
    targetCareer: profile.targetCareer,
    learningPreferences: profile.learningPreferences,
    careerCoreSkills: careerDef.coreSkills,
    missingSkills: targetMatch.missingSkills,
    partialSkills: targetMatch.partialSkills,
    agent1PriorityOrder: skillAnalysis.priorityFocusOrder,
    agent2CriticalMissing: careerMatchAnalysis.criticalMissingCompetencies,
    remedialDirective: remedialDirective || 'None',
  });

  const raw = await generateStructuredJson<RecommendationAgentOutput>({
    systemInstruction,
    prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        roadmapSummary: { type: Type.STRING },
        modules: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              skillFocus: { type: Type.STRING },
              prerequisites: { type: Type.ARRAY, items: { type: Type.STRING } },
              objectives: { type: Type.ARRAY, items: { type: Type.STRING } },
              topics: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    subtopics: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['title', 'subtopics'],
                },
              },
              practiceExerciseTitle: { type: Type.STRING },
              practiceExercisePrompt: { type: Type.STRING },
              miniProjectTitle: { type: Type.STRING },
              miniProjectDeliverables: { type: Type.ARRAY, items: { type: Type.STRING } },
              assessmentRequired: { type: Type.BOOLEAN },
            },
            required: [
              'title',
              'skillFocus',
              'prerequisites',
              'objectives',
              'topics',
              'practiceExerciseTitle',
              'practiceExercisePrompt',
              'miniProjectTitle',
              'miniProjectDeliverables',
              'assessmentRequired',
            ],
          },
        },
      },
      required: ['roadmapSummary', 'modules'],
    },
  });

  const hydrated: RoadmapModule[] = raw.modules.slice(0, 6).map((m, idx) => {
    const matchedResources = CURATED_RESOURCE_LIBRARY.filter(
      (r) =>
        r.skillName.toLowerCase().includes(m.skillFocus.toLowerCase()) ||
        m.skillFocus.toLowerCase().includes(r.skillName.toLowerCase()) ||
        r.careers.includes(profile.targetCareer)
    ).slice(0, 2);

    return {
      id: `mod-${crypto.randomUUID().slice(0, 8)}`,
      order: idx + 1,
      title: m.title,
      skillFocus: m.skillFocus,
      prerequisites: m.prerequisites,
      objectives: m.objectives,
      topics: m.topics.map((t, tIdx) => ({
        id: `top-${idx}-${tIdx}-${crypto.randomUUID().slice(0, 4)}`,
        title: t.title,
        subtopics: t.subtopics,
        completed: false,
      })),
      resources: matchedResources.map((r) => ({
        title: r.title,
        type: r.type,
        url: r.url,
        duration: r.duration,
      })),
      practiceExercise: {
        title: m.practiceExerciseTitle,
        prompt: m.practiceExercisePrompt,
        completed: false,
      },
      miniProject: {
        title: m.miniProjectTitle,
        deliverables: m.miniProjectDeliverables,
        completed: false,
      },
      assessmentRequired: m.assessmentRequired,
      status: idx === 0 ? 'in_progress' : 'pending',
    };
  });

  const orderedModules = sortModulesByPrerequisites(hydrated);

  return {
    modules: orderedModules,
    summary: raw.roadmapSummary,
    trace: {
      agentName: 'Learning Recommendation Agent',
      role: 'Sequences prerequisite-safe modules, practice exercises, and mini-projects.',
      inputSummary: `Missing: ${targetMatch.missingSkills.map((s) => s.name).join(', ') || 'None'}; Partial: ${targetMatch.partialSkills.map((s) => s.name).join(', ') || 'None'}`,
      decisionSummary: `Generated ${orderedModules.length} ordered modules prioritizing foundational prerequisites.`,
      structuredOutput: {
        moduleTitles: orderedModules.map((m) => `${m.order}. ${m.title} (${m.skillFocus})`),
      },
      timestamp: new Date().toISOString(),
    },
  };
}

// ============================================================================
// AGENT 4: PROGRESS EVALUATION AGENT
// ============================================================================
interface ProgressEvaluationOutput {
  needsRoadmapAdaptation: boolean;
  evaluationSummary: string;
  adaptationReason: string;
  remedialSkillFocus: string;
  remedialExerciseTitle: string;
  remedialExercisePrompt: string;
  remedialTopics: string[];
}

async function runProgressEvaluationAgent(params: {
  profile: StudentProfile;
  latestAssessment?: SkillAssessmentRecord;
  activities: LearningActivity[];
  currentRoadmap: LearningRoadmap | null;
}): Promise<{ output: ProgressEvaluationOutput; trace: AgentTraceStep }> {
  const systemInstruction = `You are AGENT 4: PROGRESS EVALUATION AGENT inside Skillora - AI.
Monitor assessment results and learning activity completions.
If a learner scores below 65% on a skill assessment, you MUST trigger a roadmap adaptation (needsRoadmapAdaptation = true), recommend targeted remedial practice BEFORE dependent advanced topics, and clearly explain why the recommendation changed.
If performance is >= 65%, validate mastery and keep progression smooth unless activities show stagnation.`;

  const prompt = JSON.stringify({
    targetCareer: params.profile.targetCareer,
    latestAssessment: params.latestAssessment
      ? {
          skillName: params.latestAssessment.skillName,
          score: params.latestAssessment.score,
          passed: params.latestAssessment.passed,
          weaknesses: params.latestAssessment.weaknesses,
        }
      : null,
    completedActivitiesCount: params.activities.filter((a) => a.status === 'completed').length,
    currentModules: params.currentRoadmap?.modules.map((m) => ({
      order: m.order,
      title: m.title,
      skillFocus: m.skillFocus,
      status: m.status,
    })),
  });

  const output = await generateStructuredJson<ProgressEvaluationOutput>({
    systemInstruction,
    prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        needsRoadmapAdaptation: { type: Type.BOOLEAN },
        evaluationSummary: { type: Type.STRING },
        adaptationReason: { type: Type.STRING },
        remedialSkillFocus: { type: Type.STRING },
        remedialExerciseTitle: { type: Type.STRING },
        remedialExercisePrompt: { type: Type.STRING },
        remedialTopics: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: [
        'needsRoadmapAdaptation',
        'evaluationSummary',
        'adaptationReason',
        'remedialSkillFocus',
        'remedialExerciseTitle',
        'remedialExercisePrompt',
        'remedialTopics',
      ],
    },
  });

  // Enforce deterministic guardrail: < 65% ALWAYS triggers adaptation
  if (params.latestAssessment && params.latestAssessment.score < 65) {
    output.needsRoadmapAdaptation = true;
    if (!output.remedialSkillFocus) {
      output.remedialSkillFocus = params.latestAssessment.skillName;
    }
  }

  return {
    output,
    trace: {
      agentName: 'Progress Evaluation Agent',
      role: 'Monitors assessment scores, detects weak topics, and triggers adaptive roadmap updates.',
      inputSummary: params.latestAssessment
        ? `${params.latestAssessment.skillName}: ${params.latestAssessment.score}%`
        : `${params.activities.length} logged activities`,
      decisionSummary: output.evaluationSummary,
      structuredOutput: output as unknown as Record<string, unknown>,
      timestamp: new Date().toISOString(),
    },
  };
}

// ============================================================================
// CENTRAL AI ORCHESTRATOR
// ============================================================================
export async function orchestrateFullPipeline(params: {
  profile: StudentProfile;
  assessments: SkillAssessmentRecord[];
  activities: LearningActivity[];
  triggerEvent: string;
  remedialDirective?: string;
}): Promise<{
  roadmap: LearningRoadmap;
  decision: AgentDecisionRecord;
  matches: CareerMatchResult[];
}> {
  const allMatches = computeAllCareerMatches(params.profile, params.assessments);
  const targetMatch =
    allMatches.find((m) => m.career === params.profile.targetCareer) || allMatches[0];

  // Step 1: Agent 1 analyzes profile & evidence
  const agent1 = await runSkillAnalyzerAgent(params.profile, params.assessments);

  // Step 2: Agent 2 aligns Agent 1's findings with career requirements
  const agent2 = await runCareerMatchingAgent(
    params.profile,
    agent1.output,
    targetMatch,
    allMatches
  );

  // Step 3: Agent 3 generates prerequisite-ordered roadmap from Agent 1 + Agent 2
  const agent3 = await runLearningRecommendationAgent(
    params.profile,
    agent1.output,
    agent2.output,
    targetMatch,
    params.remedialDirective
  );

  // Step 4: Agent 4 validates progression alignment
  const agent4 = await runProgressEvaluationAgent({
    profile: params.profile,
    latestAssessment: params.assessments[0],
    activities: params.activities,
    currentRoadmap: null,
  });

  const now = new Date().toISOString();
  const roadmap: LearningRoadmap = {
    id: `rm-${crypto.randomUUID().slice(0, 8)}`,
    uid: params.profile.uid,
    targetCareer: params.profile.targetCareer,
    summary: agent3.summary,
    adaptationReason:
      params.remedialDirective ||
      `Initial personalized roadmap synthesized by the Central AI Orchestrator for ${params.profile.targetCareer} (${targetMatch.compatibilityScore}% baseline readiness).`,
    modules: agent3.modules,
    createdAt: now,
    updatedAt: now,
  };

  const orchestratorStep: AgentTraceStep = {
    agentName: 'Central AI Orchestrator',
    role: 'Coordinates Agents 1-4, resolves prerequisite conflicts, and publishes the unified learning plan.',
    inputSummary: `Trigger: ${params.triggerEvent}`,
    decisionSummary: `Verified prerequisite ordering across ${roadmap.modules.length} modules for ${params.profile.targetCareer}. ${agent4.output.needsRoadmapAdaptation ? 'Applied adaptive remedial prioritization.' : 'Progression aligned with target competencies.'}`,
    structuredOutput: {
      compatibilityScore: targetMatch.compatibilityScore,
      moduleCount: roadmap.modules.length,
      prerequisiteOrderEnforced: true,
    },
    timestamp: now,
  };

  const decision: AgentDecisionRecord = {
    id: `dec-${crypto.randomUUID().slice(0, 8)}`,
    uid: params.profile.uid,
    triggerEvent: params.triggerEvent,
    orchestratorSummary: `Coordinated Skill Analyzer, Career Matching, Learning Recommendation, and Progress Evaluation agents to produce a ${roadmap.modules.length}-module roadmap for ${params.profile.targetCareer}.`,
    agentTrace: [agent1.trace, agent2.trace, agent3.trace, agent4.trace, orchestratorStep],
    createdAt: now,
  };

  return { roadmap, decision, matches: allMatches };
}

export async function orchestrateAdaptiveAssessment(params: {
  profile: StudentProfile;
  assessment: SkillAssessmentRecord;
  allAssessments: SkillAssessmentRecord[];
  activities: LearningActivity[];
  currentRoadmap: LearningRoadmap | null;
}): Promise<{
  updatedRoadmap: LearningRoadmap;
  decision: AgentDecisionRecord;
  adapted: boolean;
}> {
  const agent1 = await runSkillAnalyzerAgent(params.profile, params.allAssessments);
  const agent4 = await runProgressEvaluationAgent({
    profile: params.profile,
    latestAssessment: params.assessment,
    activities: params.activities,
    currentRoadmap: params.currentRoadmap,
  });

  const now = new Date().toISOString();

  if (!params.currentRoadmap) {
    const full = await orchestrateFullPipeline({
      profile: params.profile,
      assessments: params.allAssessments,
      activities: params.activities,
      triggerEvent: `Post-assessment synthesis (${params.assessment.skillName}: ${params.assessment.score}%)`,
      remedialDirective: agent4.output.needsRoadmapAdaptation
        ? agent4.output.adaptationReason
        : undefined,
    });
    return {
      updatedRoadmap: full.roadmap,
      decision: full.decision,
      adapted: agent4.output.needsRoadmapAdaptation,
    };
  }

  let updatedModules = [...params.currentRoadmap.modules];
  let adapted = false;
  let adaptationReason = params.currentRoadmap.adaptationReason;

  if (agent4.output.needsRoadmapAdaptation) {
    adapted = true;
    const focusSkill = agent4.output.remedialSkillFocus || params.assessment.skillName;
    const matchedResources = CURATED_RESOURCE_LIBRARY.filter(
      (r) =>
        r.skillName.toLowerCase().includes(focusSkill.toLowerCase()) ||
        focusSkill.toLowerCase().includes(r.skillName.toLowerCase())
    ).slice(0, 2);

    const remedialModule: RoadmapModule = {
      id: `mod-rem-${crypto.randomUUID().slice(0, 6)}`,
      order: 1,
      title: `Adaptive Reinforcement: ${focusSkill} Foundations`,
      skillFocus: focusSkill,
      prerequisites: [],
      objectives: [
        `Address assessment gaps identified in ${focusSkill} (scored ${params.assessment.score}%).`,
        ...params.assessment.weaknesses.slice(0, 2),
      ],
      topics: [
        {
          id: `top-rem-${crypto.randomUUID().slice(0, 4)}`,
          title: `Targeted Remediation for ${focusSkill}`,
          subtopics:
            agent4.output.remedialTopics.length > 0
              ? agent4.output.remedialTopics
              : params.assessment.weaknesses,
          completed: false,
        },
      ],
      resources: matchedResources.map((r) => ({
        title: r.title,
        type: r.type,
        url: r.url,
        duration: r.duration,
      })),
      practiceExercise: {
        title: agent4.output.remedialExerciseTitle || `${focusSkill} Diagnostic Drill`,
        prompt:
          agent4.output.remedialExercisePrompt ||
          `Complete targeted coding and conceptual drills covering: ${params.assessment.weaknesses.join(', ')}`,
        completed: false,
      },
      miniProject: {
        title: `${focusSkill} Verification Mini-Build`,
        deliverables: [
          `Implement a clean standalone solution demonstrating ${focusSkill} fundamentals.`,
          `Retake the ${focusSkill} diagnostic assessment and score >= 70%.`,
        ],
        completed: false,
      },
      assessmentRequired: true,
      status: 'in_progress',
      adaptiveNote: `Inserted by Progress Evaluation Agent because ${params.assessment.skillName} assessment scored ${params.assessment.score}% (< 65% threshold). Dependent advanced modules are sequenced after this reinforcement.`,
    };

    // Place remedial module at the top (before dependent modules) and re-number
    updatedModules = [
      remedialModule,
      ...updatedModules.filter((m) => !m.id.startsWith('mod-rem-') || m.skillFocus.toLowerCase() !== focusSkill.toLowerCase()),
    ].map((m, idx) => ({
      ...m,
      order: idx + 1,
      status: idx === 0 ? 'in_progress' : m.status === 'completed' ? 'completed' : 'pending',
    }));

    adaptationReason = `Roadmap adapted after ${params.assessment.skillName} assessment (${params.assessment.score}%): ${agent4.output.adaptationReason}`;
  } else {
    // Passed assessment -> mark matching module assessment/skill progress if applicable
    updatedModules = updatedModules.map((m) =>
      m.skillFocus.toLowerCase() === params.assessment.skillName.toLowerCase() &&
      m.status !== 'completed'
        ? {
            ...m,
            adaptiveNote: `Verified ${params.assessment.skillName} at ${params.assessment.verifiedLevel} (${params.assessment.score}%). Ready for dependent topics.`,
          }
        : m
    );
    adaptationReason = `Assessment passed in ${params.assessment.skillName} (${params.assessment.score}% -> ${params.assessment.verifiedLevel}). Existing roadmap sequence confirmed.`;
  }

  const updatedRoadmap: LearningRoadmap = {
    ...params.currentRoadmap,
    modules: updatedModules,
    adaptationReason,
    updatedAt: now,
  };

  const orchestratorStep: AgentTraceStep = {
    agentName: 'Central AI Orchestrator',
    role: 'Applies Progress Evaluation Agent directives without creating prerequisite conflicts.',
    inputSummary: `Assessment: ${params.assessment.skillName} (${params.assessment.score}%)`,
    decisionSummary: adapted
      ? `Inserted adaptive reinforcement module for ${params.assessment.skillName} ahead of dependent topics.`
      : `Confirmed mastery in ${params.assessment.skillName}; roadmap remains aligned.`,
    structuredOutput: {
      adapted,
      score: params.assessment.score,
      updatedModuleCount: updatedModules.length,
    },
    timestamp: now,
  };

  const decision: AgentDecisionRecord = {
    id: `dec-${crypto.randomUUID().slice(0, 8)}`,
    uid: params.profile.uid,
    triggerEvent: `Assessment Evaluated: ${params.assessment.skillName} (${params.assessment.score}%)`,
    orchestratorSummary: adaptationReason,
    agentTrace: [agent1.trace, agent4.trace, orchestratorStep],
    createdAt: now,
  };

  return { updatedRoadmap, decision, adapted };
}

// ============================================================================
// ASSESSMENT GENERATOR & EVALUATOR
// ============================================================================
interface GeneratedAssessmentPayload {
  questions: {
    id: string;
    prompt: string;
    type: 'mcq' | 'practical';
    options: string[];
    correctAnswer: string;
    starterCode: string;
    conceptTested: string;
  }[];
}

export async function generateSkillAssessment(params: {
  skillName: string;
  careerContext: CareerId;
  currentLevel: string;
}): Promise<{
  publicQuestions: AssessmentQuestion[];
  answerKey: Map<string, { correctAnswer: string; conceptTested: string; prompt: string; type: 'mcq' | 'practical' }>;
}> {
  const systemInstruction = `You are a technical skill assessment designer for Skillora - AI.
Create exactly 5 high-signal diagnostic questions for the requested skill in the context of the target career:
- Questions 1-4 MUST have type "mcq" with exactly 4 distinct options and 1 unambiguous correctAnswer string matching one option verbatim.
- Question 5 MUST have type "practical" (a real coding or architectural scenario prompt) with options as [] and correctAnswer containing the reference solution criteria.
Test genuine understanding rather than trivia.`;

  const prompt = `Skill: ${params.skillName}
Target Career Context: ${params.careerContext}
Learner Current Claimed Level: ${params.currentLevel}`;

  const raw = await generateStructuredJson<GeneratedAssessmentPayload>({
    systemInstruction,
    prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        questions: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              prompt: { type: Type.STRING },
              type: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.STRING },
              starterCode: { type: Type.STRING },
              conceptTested: { type: Type.STRING },
            },
            required: ['id', 'prompt', 'type', 'options', 'correctAnswer', 'starterCode', 'conceptTested'],
          },
        },
      },
      required: ['questions'],
    },
  });

  const answerKey = new Map<
    string,
    { correctAnswer: string; conceptTested: string; prompt: string; type: 'mcq' | 'practical' }
  >();

  const publicQuestions: AssessmentQuestion[] = raw.questions.slice(0, 5).map((q, idx) => {
    const qId = q.id || `q-${idx + 1}`;
    const qType: 'mcq' | 'practical' = idx === 4 || q.type === 'practical' ? 'practical' : 'mcq';
    answerKey.set(qId, {
      correctAnswer: q.correctAnswer,
      conceptTested: q.conceptTested,
      prompt: q.prompt,
      type: qType,
    });
    return {
      id: qId,
      prompt: q.prompt,
      type: qType,
      options: qType === 'mcq' ? q.options : undefined,
      starterCode: qType === 'practical' ? q.starterCode : undefined,
      conceptTested: q.conceptTested,
    };
  });

  return { publicQuestions, answerKey };
}

interface GradedEvaluationPayload {
  practicalScoreOutOf20: number;
  practicalFeedback: string;
  verifiedLevel: ProficiencyLevel;
  explanation: string;
  strengths: string[];
  weaknesses: string[];
}

export async function gradeSkillAssessment(params: {
  uid: string;
  skillName: string;
  careerContext: CareerId;
  questions: {
    id: string;
    prompt: string;
    type: 'mcq' | 'practical';
    correctAnswer: string;
    conceptTested: string;
    userAnswer: string;
  }[];
}): Promise<SkillAssessmentRecord> {
  const mcqQuestions = params.questions.filter((q) => q.type === 'mcq');
  const practicalQuestion = params.questions.find((q) => q.type === 'practical');

  let mcqCorrect = 0;
  const questionResults = params.questions.map((q) => {
    if (q.type === 'mcq') {
      const isCorrect =
        q.userAnswer.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();
      if (isCorrect) mcqCorrect += 1;
      return {
        questionId: q.id,
        prompt: q.prompt,
        userAnswer: q.userAnswer || '(No answer)',
        isCorrect,
        feedback: isCorrect
          ? `Correct on ${q.conceptTested}.`
          : `Expected "${q.correctAnswer}" for ${q.conceptTested}.`,
      };
    }
    return {
      questionId: q.id,
      prompt: q.prompt,
      userAnswer: q.userAnswer || '(No answer)',
      isCorrect: false,
      feedback: 'Evaluated by AI grader.',
    };
  });

  const mcqPoints = mcqQuestions.length > 0 ? Math.round((mcqCorrect / mcqQuestions.length) * 80) : 0;

  const evalPayload = await generateStructuredJson<GradedEvaluationPayload>({
    systemInstruction: `You are an impartial technical evaluator for Skillora - AI.
Grade the learner's practical answer out of 20 points based on correctness, clarity, and completeness (0 if blank or irrelevant).
Combine that with their MCQ performance to explain their strengths, weaknesses, and verified proficiency level (Beginner, Intermediate, Advanced, or Expert).
Provide an honest, evidence-based explanation for the assessment result.`,
    prompt: JSON.stringify({
      skillName: params.skillName,
      careerContext: params.careerContext,
      mcqScoreOutOf80: mcqPoints,
      mcqBreakdown: questionResults.filter((_, i) => params.questions[i].type === 'mcq'),
      practicalQuestion: practicalQuestion
        ? {
            prompt: practicalQuestion.prompt,
            referenceCriteria: practicalQuestion.correctAnswer,
            studentResponse: practicalQuestion.userAnswer,
          }
        : null,
    }),
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        practicalScoreOutOf20: { type: Type.INTEGER },
        practicalFeedback: { type: Type.STRING },
        verifiedLevel: { type: Type.STRING },
        explanation: { type: Type.STRING },
        strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
        weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: [
        'practicalScoreOutOf20',
        'practicalFeedback',
        'verifiedLevel',
        'explanation',
        'strengths',
        'weaknesses',
      ],
    },
  });

  const practicalPts = Math.max(0, Math.min(20, evalPayload.practicalScoreOutOf20));
  const totalScore = Math.max(0, Math.min(100, mcqPoints + practicalPts));

  if (practicalQuestion) {
    const pResult = questionResults.find((r) => r.questionId === practicalQuestion.id);
    if (pResult) {
      pResult.isCorrect = practicalPts >= 12;
      pResult.feedback = evalPayload.practicalFeedback;
    }
  }

  let verifiedLevel: ProficiencyLevel = 'Beginner';
  if (totalScore >= 88) verifiedLevel = 'Expert';
  else if (totalScore >= 75) verifiedLevel = 'Advanced';
  else if (totalScore >= 60) verifiedLevel = 'Intermediate';

  return {
    id: `asmt-${crypto.randomUUID().slice(0, 8)}`,
    uid: params.uid,
    skillName: params.skillName,
    careerContext: params.careerContext,
    score: totalScore,
    passed: totalScore >= 65,
    verifiedLevel,
    explanation: evalPayload.explanation,
    strengths: evalPayload.strengths,
    weaknesses: evalPayload.weaknesses,
    questionResults,
    createdAt: new Date().toISOString(),
  };
}

// ============================================================================
// AGENT 5: AI MENTOR AGENT
// ============================================================================
export async function runAIMentorAgent(params: {
  profile: StudentProfile;
  assessments: SkillAssessmentRecord[];
  roadmap: LearningRoadmap | null;
  activities: LearningActivity[];
  decisions: AgentDecisionRecord[];
  history: MentorMessage[];
  userMessage: string;
}): Promise<{ reply: string; reasoningNote: string }> {
  const match = computeCareerMatch(params.profile, params.assessments, params.profile.targetCareer);
  const allMatches = computeAllCareerMatches(params.profile, params.assessments);

  const systemInstruction = `You are AGENT 5: AI MENTOR AGENT inside Skillora - AI.
You have direct access to the student's live profile, verified vs self-reported skills, career compatibility scores, skill gaps, personalized roadmap, assessment weaknesses, and recent Central AI Orchestrator decisions.
Always ground your guidance in the student's actual data below — NEVER give generic boilerplate advice.
Be concise, encouraging, practical, and technically accurate. When giving coding exercises, give concrete specs and starter code. When explaining what happens if they change career goals, compare their actual matching & missing skills across the careers below.

LIVE STUDENT CONTEXT:
- Name: ${params.profile.fullName}
- Education: ${params.profile.education} (${params.profile.department}, ${params.profile.yearOfStudy})
- Target Career: ${params.profile.targetCareer} (Compatibility: ${match.compatibilityScore}%, Verified Coverage: ${match.verifiedCoveragePct}%)
- Matching Skills: ${match.matchingSkills.map((s) => `${s.name} [${s.studentLevel}${s.verified ? ' verified' : ' self-reported'}]`).join(', ') || 'None yet'}
- Partial Skills: ${match.partialSkills.map((s) => `${s.name} (${s.studentLevel} -> ${s.requiredLevel})`).join(', ') || 'None'}
- Missing Skills: ${match.missingSkills.map((s) => `${s.name} (needs ${s.requiredLevel})`).join(', ') || 'None'}
- All Career Scores: ${allMatches.map((m) => `${m.career}: ${m.compatibilityScore}%`).join(' | ')}
- Recent Assessments: ${params.assessments.slice(0, 5).map((a) => `${a.skillName}: ${a.score}% (${a.verifiedLevel}) Weaknesses: ${a.weaknesses.join('; ')}`).join(' || ') || 'None taken yet'}
- Active Roadmap Modules: ${params.roadmap?.modules.map((m) => `${m.order}. ${m.title} [${m.status}]`).join(' | ') || 'No roadmap generated yet'}
- Latest Orchestrator Adaptation: ${params.roadmap?.adaptationReason || 'None'}
- Learning Preferences: ${params.profile.learningPreferences.pace}, ${params.profile.learningPreferences.style}, ${params.profile.learningPreferences.weeklyHours} hrs/week.`;

  const historyPayload = params.history.slice(-12).map((m) => ({
    role: m.role === 'assistant' ? ('model' as const) : ('user' as const),
    text: m.content,
  }));

  const reply = await generateTextResponse({
    systemInstruction,
    history: historyPayload,
    message: params.userMessage,
  });

  const reasoningNote = `Grounded in ${params.profile.targetCareer} (${match.compatibilityScore}% match), ${params.assessments.length} assessments, and ${params.roadmap?.modules.length ?? 0} roadmap modules.`;

  return { reply, reasoningNote };
}
