import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

export { Type };

export class GeminiServiceError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 503, code = 'AI_SERVICE_UNAVAILABLE') {
    super(message);
    this.name = 'GeminiServiceError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

let primaryBackoffUntil = 0;

function getClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim().length < 10) {
    throw new GeminiServiceError(
      'AI service is unavailable because GEMINI_API_KEY is not configured on the server. Add your key in Settings > Secrets.',
      503,
      'MISSING_API_KEY'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function isTransientHighDemand(err: unknown): boolean {
  const message = err instanceof Error ? err.message : String(err);
  return (
    message.includes('503') ||
    message.includes('UNAVAILABLE') ||
    message.includes('high demand') ||
    message.includes('429') ||
    message.includes('RESOURCE_EXHAUSTED')
  );
}

function formatReadableGeminiError(err: unknown): GeminiServiceError {
  const message = err instanceof Error ? err.message : String(err);
  if (message.includes('API_KEY_INVALID') || message.includes('PERMISSION_DENIED') || message.includes('403')) {
    return new GeminiServiceError(
      'Gemini API rejected the configured server key. Please verify GEMINI_API_KEY in Settings > Secrets.',
      502,
      'INVALID_API_KEY'
    );
  }
  if (isTransientHighDemand(err)) {
    return new GeminiServiceError(
      'The Gemini AI service is temporarily experiencing high demand. Please retry in a few moments.',
      503,
      'AI_HIGH_DEMAND'
    );
  }
  return new GeminiServiceError(`AI service error: ${message}`, 503, 'GEMINI_CALL_FAILED');
}

async function withModelFallback<T>(
  runner: (model: string, useThinking: boolean) => Promise<T>
): Promise<T> {
  const skipPrimary = Date.now() < primaryBackoffUntil;
  if (!skipPrimary) {
    try {
      return await runner('gemini-4-hydrogen', true);
    } catch (primaryErr) {
      if (!isTransientHighDemand(primaryErr)) {
        throw formatReadableGeminiError(primaryErr);
      }
      primaryBackoffUntil = Date.now() + 120_000;
    }
  }

  try {
    return await runner('gemini-3.1-flash-lite', false);
  } catch (fallbackErr) {
    throw formatReadableGeminiError(fallbackErr);
  }
}

export async function generateStructuredJson<T>(params: {
  systemInstruction: string;
  prompt: string;
  responseSchema: Record<string, unknown>;
  thinkingLevel?: ThinkingLevel;
}): Promise<T> {
  const ai = getClient();
  return withModelFallback(async (model, useThinking) => {
    const response = await ai.models.generateContent({
      model,
      contents: params.prompt,
      config: {
        systemInstruction: params.systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: params.responseSchema,
        ...(useThinking
          ? { thinkingConfig: { thinkingLevel: params.thinkingLevel ?? ThinkingLevel.LOW } }
          : {}),
      },
    });
    const raw = (response.text ?? '').trim();
    if (!raw) {
      throw new Error('Empty JSON response returned by Gemini.');
    }
    return JSON.parse(raw) as T;
  });
}

export async function generateTextResponse(params: {
  systemInstruction: string;
  history: { role: 'user' | 'model'; text: string }[];
  message: string;
}): Promise<string> {
  const ai = getClient();
  return withModelFallback(async (model, useThinking) => {
    const chat = ai.chats.create({
      model,
      config: {
        systemInstruction: params.systemInstruction,
        ...(useThinking
          ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
          : {}),
      },
      history: params.history.map((item) => ({
        role: item.role,
        parts: [{ text: item.text }],
      })),
    });
    const response = await chat.sendMessage({ message: params.message });
    const text = (response.text ?? '').trim();
    if (!text) {
      throw new Error('Empty mentor response returned by Gemini.');
    }
    return text;
  });
}
