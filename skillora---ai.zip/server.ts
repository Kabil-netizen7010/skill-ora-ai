import crypto from 'node:crypto';
import path from 'node:path';
import dotenv from 'dotenv';
import express, { type NextFunction, type Request, type Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { ALL_CAREERS, CAREER_CATALOG, CURATED_RESOURCE_LIBRARY } from './src/data/careerCatalog.ts';
import type {
  CareerId,
  LearningActivity,
  MentorMessage,
  SkillEntry,
  StudentProfile,
} from './src/types/skillora.ts';
import {
  computeAllCareerMatches,
  generateSkillAssessment,
  gradeSkillAssessment,
  orchestrateAdaptiveAssessment,
  orchestrateFullPipeline,
  runAIMentorAgent,
} from './server/agents.ts';
import {
  addActivity,
  addMentorMessage,
  clearMentorMessages,
  createUserAccount,
  findUserByEmail,
  findUserByUid,
  getActiveRoadmap,
  getProfile,
  hashPassword,
  insertAssessment,
  listActivities,
  listAgentDecisions,
  listAssessments,
  listMentorMessages,
  listRoadmaps,
  resetUserPassword,
  saveAgentDecision,
  saveProfile,
  saveRoadmap,
  setPasswordResetToken,
  signSessionToken,
  updateUserPassword,
  verifyPassword,
  verifySessionToken,
} from './server/db.ts';
import { GeminiServiceError, generateTextResponse } from './server/gemini.ts';

dotenv.config();

interface AuthRequest extends Request {
  authUser?: {
    uid: string;
    email: string;
  };
}

interface PendingAssessmentSession {
  uid: string;
  skillName: string;
  careerContext: CareerId;
  answerKey: Map<
    string,
    { correctAnswer: string; conceptTested: string; prompt: string; type: 'mcq' | 'practical' }
  >;
  createdAt: number;
}

const pendingAssessments = new Map<string, PendingAssessmentSession>();

function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }
  const token = header.slice('Bearer '.length).trim();
  const payload = verifySessionToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    return;
  }
  const user = findUserByUid(payload.uid);
  if (!user) {
    res.status(401).json({ error: 'Account not found.' });
    return;
  }
  req.authUser = { uid: user.uid, email: user.email };
  next();
}

function buildDefaultProfile(params: {
  uid: string;
  email: string;
  fullName: string;
  education?: string;
  department?: string;
  yearOfStudy?: string;
  targetCareer?: CareerId;
  skills?: SkillEntry[];
}): StudentProfile {
  const now = new Date().toISOString();
  const targetCareer: CareerId =
    params.targetCareer && ALL_CAREERS.includes(params.targetCareer)
      ? params.targetCareer
      : 'Full Stack Developer';

  return {
    uid: params.uid,
    email: params.email,
    fullName: params.fullName,
    education: params.education || 'B.Tech / B.S. Undergraduate',
    department: params.department || 'Computer Science & Engineering',
    yearOfStudy: params.yearOfStudy || '3rd Year',
    targetCareer,
    careerInterests: [targetCareer],
    learningPreferences: {
      pace: 'Structured Weekly',
      style: 'Hands-on Projects',
      weeklyHours: 10,
    },
    skills:
      params.skills && params.skills.length > 0
        ? params.skills
        : [
            { name: 'Python', category: 'Technical', selfReportedLevel: 'Intermediate' },
            { name: 'SQL', category: 'Technical', selfReportedLevel: 'Beginner' },
          ],
    certifications: [],
    projects: [],
    createdAt: now,
    updatedAt: now,
  };
}

function handleError(res: Response, err: unknown, fallbackMsg: string) {
  if (err instanceof GeminiServiceError) {
    res.status(err.statusCode).json({ error: err.message, code: err.code });
    return;
  }
  console.error(fallbackMsg, err);
  const message = err instanceof Error ? err.message : fallbackMsg;
  res.status(500).json({ error: message || fallbackMsg });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      aiConfigured: Boolean(
        process.env.GEMINI_API_KEY &&
          process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY' &&
          process.env.GEMINI_API_KEY.trim().length > 10
      ),
    });
  });

  // ============================================================================
  // AUTHENTICATION ROUTES
  // ============================================================================
  app.post('/api/auth/register', (req, res) => {
    try {
      const {
        fullName,
        email,
        password,
        education,
        department,
        yearOfStudy,
        targetCareer,
        initialSkills,
      } = req.body as {
        fullName?: string;
        email?: string;
        password?: string;
        education?: string;
        department?: string;
        yearOfStudy?: string;
        targetCareer?: CareerId;
        initialSkills?: SkillEntry[];
      };

      if (!fullName || fullName.trim().length < 2) {
        res.status(400).json({ error: 'Please enter your full name (at least 2 characters).' });
        return;
      }
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
        res.status(400).json({ error: 'Please enter a valid email address.' });
        return;
      }
      if (!password || password.length < 6) {
        res.status(400).json({ error: 'Password must be at least 6 characters long.' });
        return;
      }

      const existing = findUserByEmail(email);
      if (existing) {
        res.status(409).json({ error: 'An account with this email already exists. Please sign in.' });
        return;
      }

      const uid = `usr_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
      const user = createUserAccount({
        uid,
        email,
        passwordHash: hashPassword(password),
        fullName,
        authProvider: 'email',
      });

      const profile = saveProfile(
        buildDefaultProfile({
          uid: user.uid,
          email: user.email,
          fullName: user.full_name,
          education,
          department,
          yearOfStudy,
          targetCareer,
          skills: Array.isArray(initialSkills) ? initialSkills : undefined,
        })
      );

      addActivity({
        id: `act-${crypto.randomUUID().slice(0, 8)}`,
        uid: user.uid,
        type: 'lesson',
        title: `Created Skillora student account targeting ${profile.targetCareer}`,
        skillName: profile.targetCareer,
        status: 'completed',
        createdAt: new Date().toISOString(),
      });

      const token = signSessionToken(user.uid, user.email);
      res.status(201).json({
        token,
        user: {
          uid: user.uid,
          email: user.email,
          fullName: user.full_name,
          authProvider: user.auth_provider,
        },
        profile,
      });
    } catch (err) {
      handleError(res, err, 'Failed to register student account.');
    }
  });

  app.post('/api/auth/login', (req, res) => {
    try {
      const { email, password } = req.body as { email?: string; password?: string };
      if (!email || !password) {
        res.status(400).json({ error: 'Email and password are required.' });
        return;
      }
      const user = findUserByEmail(email);
      if (!user || !user.password_hash) {
        res.status(401).json({ error: 'Invalid email or password.' });
        return;
      }
      if (!verifyPassword(password, user.password_hash)) {
        res.status(401).json({ error: 'Invalid email or password.' });
        return;
      }

      let profile = getProfile(user.uid);
      if (!profile) {
        profile = saveProfile(
          buildDefaultProfile({
            uid: user.uid,
            email: user.email,
            fullName: user.full_name,
          })
        );
      }

      const token = signSessionToken(user.uid, user.email);
      res.json({
        token,
        user: {
          uid: user.uid,
          email: user.email,
          fullName: user.full_name,
          authProvider: user.auth_provider,
        },
        profile,
      });
    } catch (err) {
      handleError(res, err, 'Login failed.');
    }
  });

  app.post('/api/auth/forgot-password', (req, res) => {
    try {
      const { email } = req.body as { email?: string };
      if (!email || !email.trim()) {
        res.status(400).json({ error: 'Please provide your registered email address.' });
        return;
      }
      const code = setPasswordResetToken(email);
      if (!code) {
        res.status(404).json({ error: 'No student account found for that email address.' });
        return;
      }
      res.json({
        message:
          'A 6-digit password recovery code has been generated and is valid for 20 minutes.',
        recoveryCode: code,
      });
    } catch (err) {
      handleError(res, err, 'Failed to initiate password reset.');
    }
  });

  app.post('/api/auth/reset-password', (req, res) => {
    try {
      const { email, code, newPassword } = req.body as {
        email?: string;
        code?: string;
        newPassword?: string;
      };
      if (!email || !code || !newPassword || newPassword.length < 6) {
        res.status(400).json({
          error: 'Valid email, 6-digit recovery code, and new password (min 6 chars) are required.',
        });
        return;
      }
      const ok = resetUserPassword(email, code, newPassword);
      if (!ok) {
        res.status(400).json({ error: 'Invalid or expired recovery code.' });
        return;
      }
      res.json({ message: 'Password updated successfully. You can now sign in.' });
    } catch (err) {
      handleError(res, err, 'Failed to reset password.');
    }
  });

  app.post('/api/auth/google-sync', async (req, res) => {
    try {
      const { uid, email, fullName } = req.body as {
        uid?: string;
        email?: string;
        fullName?: string;
      };
      if (!uid || !email) {
        res.status(400).json({ error: 'Missing Google user identity fields.' });
        return;
      }

      let user = findUserByUid(uid) || findUserByEmail(email);
      if (!user) {
        user = createUserAccount({
          uid,
          email,
          passwordHash: null,
          fullName: fullName || email.split('@')[0],
          authProvider: 'google',
        });
      }

      let profile = getProfile(user.uid);
      if (!profile) {
        profile = saveProfile(
          buildDefaultProfile({
            uid: user.uid,
            email: user.email,
            fullName: user.full_name,
          })
        );
      }

      const token = signSessionToken(user.uid, user.email);
      res.json({
        token,
        user: {
          uid: user.uid,
          email: user.email,
          fullName: user.full_name,
          authProvider: user.auth_provider,
        },
        profile,
      });
    } catch (err) {
      handleError(res, err, 'Failed to sync Google account.');
    }
  });

  app.get('/api/auth/me', requireAuth, (req: AuthRequest, res) => {
    const uid = req.authUser!.uid;
    const user = findUserByUid(uid)!;
    const profile =
      getProfile(uid) ||
      saveProfile(
        buildDefaultProfile({
          uid: user.uid,
          email: user.email,
          fullName: user.full_name,
        })
      );
    res.json({
      user: {
        uid: user.uid,
        email: user.email,
        fullName: user.full_name,
        authProvider: user.auth_provider,
      },
      profile,
    });
  });

  app.post('/api/auth/change-password', requireAuth, (req: AuthRequest, res) => {
    try {
      const { currentPassword, newPassword } = req.body as {
        currentPassword?: string;
        newPassword?: string;
      };
      if (!newPassword || newPassword.length < 6) {
        res.status(400).json({ error: 'New password must be at least 6 characters.' });
        return;
      }
      const user = findUserByUid(req.authUser!.uid)!;
      if (user.password_hash) {
        if (!currentPassword || !verifyPassword(currentPassword, user.password_hash)) {
          res.status(400).json({ error: 'Current password is incorrect.' });
          return;
        }
      }
      updateUserPassword(user.uid, newPassword);
      res.json({ message: 'Password changed successfully.' });
    } catch (err) {
      handleError(res, err, 'Failed to update password.');
    }
  });

  // ============================================================================
  // PROFILE ROUTES
  // ============================================================================
  app.get('/api/profile', requireAuth, (req: AuthRequest, res) => {
    const profile = getProfile(req.authUser!.uid);
    if (!profile) {
      res.status(404).json({ error: 'Profile not found.' });
      return;
    }
    res.json({ profile });
  });

  app.put('/api/profile', requireAuth, (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const existing = getProfile(uid);
      if (!existing) {
        res.status(404).json({ error: 'Profile not found.' });
        return;
      }
      const incoming = req.body as Partial<StudentProfile>;
      if (incoming.fullName !== undefined && incoming.fullName.trim().length < 2) {
        res.status(400).json({ error: 'Full name must be at least 2 characters.' });
        return;
      }
      if (incoming.targetCareer && !ALL_CAREERS.includes(incoming.targetCareer)) {
        res.status(400).json({ error: 'Unsupported target career.' });
        return;
      }

      const merged: StudentProfile = {
        ...existing,
        ...incoming,
        uid: existing.uid,
        email: existing.email,
        createdAt: existing.createdAt,
        updatedAt: new Date().toISOString(),
      };

      const saved = saveProfile(merged);
      const assessments = listAssessments(uid);
      const matches = computeAllCareerMatches(saved, assessments);
      res.json({ profile: saved, matches });
    } catch (err) {
      handleError(res, err, 'Failed to update student profile.');
    }
  });

  // ============================================================================
  // SKILL ASSESSMENTS ROUTES
  // ============================================================================
  app.get('/api/assessments', requireAuth, (req: AuthRequest, res) => {
    const assessments = listAssessments(req.authUser!.uid);
    res.json({ assessments });
  });

  app.post('/api/assessments/generate', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const { skillName, careerContext } = req.body as {
        skillName?: string;
        careerContext?: CareerId;
      };
      if (!skillName || !skillName.trim()) {
        res.status(400).json({ error: 'Please select a skill to assess.' });
        return;
      }
      const profile = getProfile(uid);
      if (!profile) {
        res.status(404).json({ error: 'Student profile not found.' });
        return;
      }

      const resolvedCareer =
        careerContext && ALL_CAREERS.includes(careerContext) ? careerContext : profile.targetCareer;
      const existingSkill = profile.skills.find(
        (s) => s.name.toLowerCase() === skillName.trim().toLowerCase()
      );
      const currentLevel = existingSkill?.verifiedLevel || existingSkill?.selfReportedLevel || 'Beginner';

      const { publicQuestions, answerKey } = await generateSkillAssessment({
        skillName: skillName.trim(),
        careerContext: resolvedCareer,
        currentLevel,
      });

      const sessionId = `asess_${crypto.randomUUID().slice(0, 12)}`;
      pendingAssessments.set(sessionId, {
        uid,
        skillName: skillName.trim(),
        careerContext: resolvedCareer,
        answerKey,
        createdAt: Date.now(),
      });

      res.json({
        sessionId,
        skillName: skillName.trim(),
        careerContext: resolvedCareer,
        questions: publicQuestions,
      });
    } catch (err) {
      handleError(res, err, 'Failed to generate skill assessment.');
    }
  });

  app.post('/api/assessments/submit', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const { sessionId, answers } = req.body as {
        sessionId?: string;
        answers?: Record<string, string>;
      };

      if (!sessionId || !answers) {
        res.status(400).json({ error: 'Assessment session ID and answers are required.' });
        return;
      }
      const session = pendingAssessments.get(sessionId);
      if (!session || session.uid !== uid) {
        res.status(404).json({ error: 'Assessment session expired or not found. Please start a new attempt.' });
        return;
      }

      const profile = getProfile(uid);
      if (!profile) {
        res.status(404).json({ error: 'Student profile not found.' });
        return;
      }

      const questionsForGrading = Array.from(session.answerKey.entries()).map(([id, meta]) => ({
        id,
        prompt: meta.prompt,
        type: meta.type,
        correctAnswer: meta.correctAnswer,
        conceptTested: meta.conceptTested,
        userAnswer: answers[id] || '',
      }));

      const record = await gradeSkillAssessment({
        uid,
        skillName: session.skillName,
        careerContext: session.careerContext,
        questions: questionsForGrading,
      });

      pendingAssessments.delete(sessionId);
      insertAssessment(record);

      // Update verified skill status on profile
      const idx = profile.skills.findIndex(
        (s) => s.name.toLowerCase() === session.skillName.toLowerCase()
      );
      const updatedSkills = [...profile.skills];
      if (idx >= 0) {
        updatedSkills[idx] = {
          ...updatedSkills[idx],
          verifiedLevel: record.verifiedLevel,
          verifiedScore: record.score,
          lastAssessedAt: record.createdAt,
          evidence: `Diagnostic assessment scored ${record.score}%`,
        };
      } else {
        updatedSkills.push({
          name: session.skillName,
          category: 'Technical',
          selfReportedLevel: record.verifiedLevel,
          verifiedLevel: record.verifiedLevel,
          verifiedScore: record.score,
          lastAssessedAt: record.createdAt,
          evidence: `Diagnostic assessment scored ${record.score}%`,
        });
      }

      const updatedProfile = saveProfile({ ...profile, skills: updatedSkills });

      addActivity({
        id: `act-${crypto.randomUUID().slice(0, 8)}`,
        uid,
        type: 'assessment',
        title: `Completed ${record.skillName} assessment (${record.score}% - ${record.verifiedLevel})`,
        skillName: record.skillName,
        status: 'completed',
        createdAt: record.createdAt,
      });

      // Trigger Agent 4 + Central AI Orchestrator for adaptive roadmap check
      const allAssessments = listAssessments(uid);
      const activities = listActivities(uid);
      const currentRoadmap = getActiveRoadmap(uid);

      const adaptiveResult = await orchestrateAdaptiveAssessment({
        profile: updatedProfile,
        assessment: record,
        allAssessments,
        activities,
        currentRoadmap,
      });

      saveRoadmap(adaptiveResult.updatedRoadmap, true);
      saveAgentDecision(adaptiveResult.decision);

      if (adaptiveResult.adapted) {
        addActivity({
          id: `act-${crypto.randomUUID().slice(0, 8)}`,
          uid,
          type: 'roadmap_adaptation',
          title: `Roadmap adapted: added reinforcement for ${record.skillName} after ${record.score}% score`,
          skillName: record.skillName,
          status: 'in_progress',
          createdAt: new Date().toISOString(),
        });
      }

      const matches = computeAllCareerMatches(updatedProfile, allAssessments);

      res.json({
        record,
        profile: updatedProfile,
        roadmap: adaptiveResult.updatedRoadmap,
        decision: adaptiveResult.decision,
        adapted: adaptiveResult.adapted,
        matches,
      });
    } catch (err) {
      handleError(res, err, 'Failed to evaluate skill assessment.');
    }
  });

  // ============================================================================
  // CAREER MATCHING & ORCHESTRATOR ROUTES
  // ============================================================================
  app.get('/api/careers/matches', requireAuth, (req: AuthRequest, res) => {
    const uid = req.authUser!.uid;
    const profile = getProfile(uid);
    if (!profile) {
      res.status(404).json({ error: 'Profile not found.' });
      return;
    }
    const assessments = listAssessments(uid);
    const matches = computeAllCareerMatches(profile, assessments);
    res.json({ matches, catalog: CAREER_CATALOG });
  });

  app.post('/api/orchestrator/run', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const profile = getProfile(uid);
      if (!profile) {
        res.status(404).json({ error: 'Profile not found.' });
        return;
      }
      const assessments = listAssessments(uid);
      const activities = listActivities(uid);
      const triggerEvent =
        (req.body as { triggerEvent?: string })?.triggerEvent ||
        `Full 5-Agent Orchestration for ${profile.targetCareer}`;

      const result = await orchestrateFullPipeline({
        profile,
        assessments,
        activities,
        triggerEvent,
      });

      saveRoadmap(result.roadmap, true);
      saveAgentDecision(result.decision);
      addActivity({
        id: `act-${crypto.randomUUID().slice(0, 8)}`,
        uid,
        type: 'roadmap_adaptation',
        title: `Generated ${result.roadmap.modules.length}-module personalized roadmap for ${profile.targetCareer}`,
        skillName: profile.targetCareer,
        status: 'completed',
        createdAt: new Date().toISOString(),
      });

      res.json({
        roadmap: result.roadmap,
        decision: result.decision,
        matches: result.matches,
      });
    } catch (err) {
      handleError(res, err, 'Multi-agent orchestrator failed.');
    }
  });

  app.post('/api/careers/switch', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const { targetCareer } = req.body as { targetCareer?: CareerId };
      if (!targetCareer || !ALL_CAREERS.includes(targetCareer)) {
        res.status(400).json({ error: 'Please select a valid target career path.' });
        return;
      }
      const profile = getProfile(uid);
      if (!profile) {
        res.status(404).json({ error: 'Profile not found.' });
        return;
      }

      const previousCareer = profile.targetCareer;
      const updatedInterests = Array.from(new Set([...profile.careerInterests, targetCareer]));
      const updatedProfile = saveProfile({
        ...profile,
        targetCareer,
        careerInterests: updatedInterests,
      });

      addActivity({
        id: `act-${crypto.randomUUID().slice(0, 8)}`,
        uid,
        type: 'career_switch',
        title: `Switched career goal from ${previousCareer} to ${targetCareer} (prior history preserved)`,
        skillName: targetCareer,
        status: 'completed',
        createdAt: new Date().toISOString(),
      });

      const assessments = listAssessments(uid);
      const activities = listActivities(uid);
      const result = await orchestrateFullPipeline({
        profile: updatedProfile,
        assessments,
        activities,
        triggerEvent: `Career Goal Switch: ${previousCareer} -> ${targetCareer}`,
      });

      saveRoadmap(result.roadmap, true);
      saveAgentDecision(result.decision);

      res.json({
        profile: updatedProfile,
        roadmap: result.roadmap,
        decision: result.decision,
        matches: result.matches,
      });
    } catch (err) {
      handleError(res, err, 'Failed to switch career goal and rebuild roadmap.');
    }
  });

  app.get('/api/agent-decisions', requireAuth, (req: AuthRequest, res) => {
    const decisions = listAgentDecisions(req.authUser!.uid);
    res.json({ decisions });
  });

  // ============================================================================
  // ROADMAP, RESOURCES & PROGRESS ROUTES
  // ============================================================================
  app.get('/api/roadmaps/active', requireAuth, (req: AuthRequest, res) => {
    const uid = req.authUser!.uid;
    const roadmap = getActiveRoadmap(uid);
    const history = listRoadmaps(uid);
    res.json({ roadmap, history });
  });

  app.patch('/api/roadmaps/:id/progress', requireAuth, (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const roadmap = getActiveRoadmap(uid);
      if (!roadmap || roadmap.id !== req.params.id) {
        res.status(404).json({ error: 'Active roadmap not found.' });
        return;
      }

      const {
        moduleId,
        topicId,
        toggleExercise,
        toggleMiniProject,
        moduleStatus,
      } = req.body as {
        moduleId: string;
        topicId?: string;
        toggleExercise?: boolean;
        toggleMiniProject?: boolean;
        moduleStatus?: 'pending' | 'in_progress' | 'completed';
      };

      let activityTitle = '';
      let activityType: LearningActivity['type'] = 'lesson';
      let skillName: string = roadmap.targetCareer;

      const updatedModules = roadmap.modules.map((mod) => {
        if (mod.id !== moduleId) return mod;
        skillName = mod.skillFocus;
        const nextMod = { ...mod };

        if (topicId) {
          nextMod.topics = mod.topics.map((t) => {
            if (t.id !== topicId) return t;
            const nextDone = !t.completed;
            if (nextDone) activityTitle = `Completed lesson topic: ${t.title}`;
            return { ...t, completed: nextDone };
          });
        }
        if (toggleExercise) {
          const nextDone = !mod.practiceExercise.completed;
          nextMod.practiceExercise = { ...mod.practiceExercise, completed: nextDone };
          activityType = 'exercise';
          if (nextDone) activityTitle = `Completed practice exercise: ${mod.practiceExercise.title}`;
        }
        if (toggleMiniProject) {
          const nextDone = !mod.miniProject.completed;
          nextMod.miniProject = { ...mod.miniProject, completed: nextDone };
          activityType = 'project';
          if (nextDone) activityTitle = `Completed mini-project: ${mod.miniProject.title}`;
        }

        const allTopicsDone = nextMod.topics.every((t) => t.completed);
        if (moduleStatus) {
          nextMod.status = moduleStatus;
          if (moduleStatus === 'completed') {
            activityTitle = `Completed roadmap module: ${mod.title}`;
          }
        } else if (
          allTopicsDone &&
          nextMod.practiceExercise.completed &&
          nextMod.miniProject.completed
        ) {
          nextMod.status = 'completed';
        } else if (
          nextMod.topics.some((t) => t.completed) ||
          nextMod.practiceExercise.completed ||
          nextMod.miniProject.completed
        ) {
          nextMod.status = 'in_progress';
        }
        return nextMod;
      });

      const saved = saveRoadmap(
        {
          ...roadmap,
          modules: updatedModules,
          updatedAt: new Date().toISOString(),
        },
        true
      );

      if (activityTitle) {
        addActivity({
          id: `act-${crypto.randomUUID().slice(0, 8)}`,
          uid,
          type: activityType,
          title: activityTitle,
          skillName,
          status: 'completed',
          createdAt: new Date().toISOString(),
        });
      }

      res.json({ roadmap: saved, activities: listActivities(uid) });
    } catch (err) {
      handleError(res, err, 'Failed to update roadmap progress.');
    }
  });

  app.post('/api/roadmaps/:id/exercise-feedback', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const { moduleTitle, exercisePrompt, solution } = req.body as {
        moduleTitle?: string;
        exercisePrompt?: string;
        solution?: string;
      };
      if (!solution || solution.trim().length < 5) {
        res.status(400).json({ error: 'Please write your code or solution attempt before requesting feedback.' });
        return;
      }

      const profile = getProfile(uid);
      const feedback = await generateTextResponse({
        systemInstruction: `You are an expert engineering mentor evaluating a learner's practice exercise submission for Skillora - AI. Give specific, actionable feedback on correctness, edge cases, and next improvement steps.`,
        history: [],
        message: `Student Career Goal: ${profile?.targetCareer || 'Software Engineering'}
Module: ${moduleTitle}
Exercise Prompt: ${exercisePrompt}
Student Submission:
${solution}`,
      });

      addActivity({
        id: `act-${crypto.randomUUID().slice(0, 8)}`,
        uid,
        type: 'exercise',
        title: `Submitted practice solution for ${moduleTitle}`,
        skillName: moduleTitle || 'Practice',
        status: 'completed',
        createdAt: new Date().toISOString(),
      });

      res.json({ feedback });
    } catch (err) {
      handleError(res, err, 'Failed to evaluate practice exercise.');
    }
  });

  app.get('/api/activities', requireAuth, (req: AuthRequest, res) => {
    const activities = listActivities(req.authUser!.uid);
    res.json({ activities });
  });

  app.post('/api/activities', requireAuth, (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const { type, title, skillName, status } = req.body as Partial<LearningActivity>;
      if (!title || !title.trim()) {
        res.status(400).json({ error: 'Activity title is required.' });
        return;
      }
      const activity: LearningActivity = {
        id: `act-${crypto.randomUUID().slice(0, 8)}`,
        uid,
        type: type || 'lesson',
        title: title.trim(),
        skillName: skillName || 'General',
        status: status || 'completed',
        createdAt: new Date().toISOString(),
      };
      addActivity(activity);
      res.status(201).json({ activity, activities: listActivities(uid) });
    } catch (err) {
      handleError(res, err, 'Failed to log learning activity.');
    }
  });

  app.get('/api/resources', (_req, res) => {
    res.json({ resources: CURATED_RESOURCE_LIBRARY });
  });

  // ============================================================================
  // AI MENTOR ROUTES (AGENT 5)
  // ============================================================================
  app.get('/api/mentor/messages', requireAuth, (req: AuthRequest, res) => {
    const messages = listMentorMessages(req.authUser!.uid);
    res.json({ messages });
  });

  app.post('/api/mentor/chat', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.authUser!.uid;
      const { message } = req.body as { message?: string };
      if (!message || !message.trim()) {
        res.status(400).json({ error: 'Please enter a message for the AI Mentor.' });
        return;
      }

      const profile = getProfile(uid);
      if (!profile) {
        res.status(404).json({ error: 'Profile not found.' });
        return;
      }

      const assessments = listAssessments(uid);
      const roadmap = getActiveRoadmap(uid);
      const activities = listActivities(uid);
      const decisions = listAgentDecisions(uid);
      const history = listMentorMessages(uid);

      const userMsg: MentorMessage = {
        id: `msg-${crypto.randomUUID().slice(0, 8)}`,
        uid,
        role: 'user',
        content: message.trim(),
        createdAt: new Date().toISOString(),
      };

      const { reply, reasoningNote } = await runAIMentorAgent({
        profile,
        assessments,
        roadmap,
        activities,
        decisions,
        history,
        userMessage: message.trim(),
      });

      const assistantMsg: MentorMessage = {
        id: `msg-${crypto.randomUUID().slice(0, 8)}`,
        uid,
        role: 'assistant',
        content: reply,
        reasoningNote,
        createdAt: new Date().toISOString(),
      };

      addMentorMessage(userMsg);
      addMentorMessage(assistantMsg);

      res.json({
        userMessage: userMsg,
        assistantMessage: assistantMsg,
        messages: listMentorMessages(uid),
      });
    } catch (err) {
      handleError(res, err, 'AI Mentor could not generate a response.');
    }
  });

  app.delete('/api/mentor/messages', requireAuth, (req: AuthRequest, res) => {
    clearMentorMessages(req.authUser!.uid);
    res.json({ messages: [] });
  });

  // ============================================================================
  // VITE / STATIC FRONTEND SERVING
  // ============================================================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Skillora - AI server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
